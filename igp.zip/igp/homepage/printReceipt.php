<?php 
	include('../connection/config.php');

	if(isset($_GET['trans_id']))
	{
		$trans_id = $_GET['trans_id'];

		$sql="SELECT *,CONCAT(s.fname, ' ',s.mname,' ',s.lname) AS stud_name ,(SELECT concat(fname, ' ',mname,' ',lname) FROM tbl_users u WHERE t.sold_by = u.id)AS sold_by FROM tbl_transactions t LEFT JOIN tbl_students s ON s.stud_id = t.stud_id WHERE trans_id=".$trans_id." LIMIT 1";

		$query=mysqli_query($mysqli,$sql)or die(mysqli_error($mysqli));
		$row=mysqli_fetch_array($query);
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>LNU-IGP Books Store</title>
	<!-- Bootstrap 3.3.6 -->
	  <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
	  <!-- Font Awesome -->
	  <link rel="stylesheet" href="../assets/dist/css/font-awesome.min.css">
	  <!-- Theme style -->
	  
	  <link rel="stylesheet" href="../assets/dist/font-awesome/css/font-awesome.min.css">
	  <link rel="stylesheet" href="../assets/css/custom.css">
	  <link rel="stylesheet" href="../plugins/select2/select2.min.css">
	  <link rel="stylesheet" href="../assets/dist/css/AdminLTE.css">

	  <script src="../assets/js/jquery.min.js"></script>
	  <link rel="stylesheet" href="../assets/dist/css/skins/skin-blue.min.css">
	  <link rel="icon" href="../assets/image/igp-logo.jpg">
</head>
<body onload="window.print();" title="Reload this page to print">
<div class="container">
	<div style="text-align:center;width:100%;">
		<p style="margin:0;">Republic of the Philippines</p>
		<h3 style="margin:0;">LNU-IGP Books Store System</h3>
		<small >Paterno Street, Tacloban City</small>
		<br>
		<small>Philippines, 6500</small>
		<br><br>
	</div>

	<small>Date Purchased: <?=$row['date_purchased'];?></small><br>
	<small>Transaction #: <?=$row['trans_id'];?></small>
	<p><small>Student #: <?=$row['stud_no'];?></small></p>
	<p><h4>Student: <?=$row['stud_name'];?></h4></p>
	<table class="table">
		<tr>
			<th>No.</th>
			<th>TITLE</th>
			<th>DESCRIPTION</th>
			<th>QTY</th>
			<th>PRICE</th>
			<th>TOTAL</th>
		</tr>
	
	
	<?php 
	$sql = "SELECT * FROM tbl_book_purchases bp LEFT JOIN tbl_po_books po ON po.pob_id = bp.pob_id LEFT JOIN tbl_books b ON po.book_id=b.book_id WHERE bp.trans_id = ".$_GET['trans_id']." ";

		$query=mysqli_query($mysqli,$sql)or die(mysqli_error($mysqli));
		$data=array();
		$x=0;$amount_payable = 0;
		while($row2=mysqli_fetch_array($query))
		{
			$x++;
			$total = $row2['purchase_qty'] * $row2['price_sold'];
			$amount_payable += $total;
			?>
			<tr>
				<td><?=$x;?></td>
				<td><?=$row2['title'];?></td>
				<td><?=$row2['description'];?></td>
				<td><?=$row2['purchase_qty'];?></td>
				<td><?=$row2['price_sold'];?></td>
				<td><?=$total;?></td>
			</tr>

			<?php
		}


	 ?>
	 		<tr>
	 			<td colspan="5"><span class="pull-right"><b>AMOUNT PAID:</b> </span></td>
				<td ><?=$amount_payable;?></td>
			</tr>
	</table>

	<p style="margin:0;font-weight:bold;"><span>Sold By: </span></p>
	<p style="margin:0;"><?=ucfirst($row['sold_by']); ?></p>
</div>
</body>
</html>