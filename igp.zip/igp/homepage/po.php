<?php 
$layout_active = 'po';
$layout_header_txt = 'Purchase Order';
?>

<?php include '../template/header.php'; ?>

<div class="box box-primary">
	<div class="box-header">
    
	<div class="row">
		<div class="col-lg-4">
			<div class="input-group">
				<input id="search_txt" type="text" class="form-control" placeholder="Search Supplier, P.O., Year">
				<div class="input-group-btn">
				    <button onclick="getPurchaseOrders()" class="btn btn-primary btn-flat" id="search_btn"><span class="fa fa-search"></span></button>
				</div>
			</div>
		</div>
		<div class="col-lg-8">
			<span class="pull-right">
			<button type="button" id="addNewPo" class="btn btn-success btn-flat btn-sm"><i class="fa fa-plus"></i> Add New Purchase Order</button>
			</span>

		</div>
	</div>
	</div>
	<div class="box-body" style="min-height:400px;">

	<div class="table-responsive">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th width="10px">#</th>
                    <th >P.O. No</th>
                    <th>Supplier</th>
                    <th >Date</th>
                    <th >&nbsp;</th>
                    <th>Action</th>
                </tr>
            </thead>
        <tbody id="supplierList"></tbody>
        </table>
    </div><!-- /.table-responsive -->

   	</div><!--./box-body-->
</div><!--./box-->

<div id="detailModal" class="modal fade" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog modal-lg" style="width:1300px !important;">
            <div class="modal-content" >
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times</button>
                    <div style="">
                        <h4 class="modal-title">PURCHASE ORDER</h4>
                        <!-- <p>Republic of the Philippines</p>
                        <h4><b>LEYTE NORMAL UNIVERSITY</b></h4>
                        <p>Tacloban City</p> -->
                    </div>
                    
                </div>
                <div class="modal-body" style="min-height:350px;">
                    
                    <input type="hidden" id="po_id">
                    <table class="table">
                        <tr>
                            <td width="100px">Supplier</td>
                            <td><h5 style="margin:0;"><b id="name"></b></h5></td>
                            <td>P.O. No.</td>
                            <td><span id="po_no"></span></td>
                        </tr>
                        <tr>
                            <td>Address</td>
                            <td><span id="address"></span></td>
                            <td>Date</td>
                            <td><span id="date_receive"></span></td>
                        </tr>
                        
                        
                    </table>
                    <div id="first">
                    

                    <table class="table">
                            <thead>
                                    <tr style="background-color:#ddd;">
                                        <th>Stock No.</th>
                                        <th>Unit</th>
                                        <th>Description</th>
                                        <th width="100px">QTY</th>
                                        <th>Unit Cost</th>
                                        <th>Amount</th>
                                        <th>&nbsp;</th>
                                    </tr>

                                </thead>
                                <tbody id="books_poList"></tbody>
                                

                            </table>
                            <a href="" id="addNewPurchaseBook" class="btn btn-success btn-xs btn-flat"><i class="fa fa-plus"></i> Add</a>
                    </div><!--first-->

                    <div id="second" style="display:none;">
                    <form class="form-horizontal">
                        <div class="row">
                        <div class="col-lg-3">&nbsp;</div>
                         <div class="col-lg-6">

                            <input type="hidden" id="newPob_id">
                            <input type="hidden" id="sup_id">

                            <div id="msgBox"></div>

                            
                            <div class="form-group margin-bottom">
                              <label for="" class="col-sm-3 control-label">&nbsp;</label>
                              <div class="col-sm-9">
                                <h4 id="poTitle">ADD NEW BOOK</h4>
                              </div>
                            </div><!-- /.form-group -->

                            <div class="form-group margin-bottom" style="display:none;">
                              <label for="new_unit" class="col-sm-3 control-label">Unit</label>
                              <div class="col-sm-9">
                                <select id="new_unit" class="form-control">
                                    <option value="copies" class="form-control">Copies</option>
                                </select>
                              </div>
                            </div><!-- /.form-group -->

                            
                            <div class="form-group margin-bottom">
                              <label for="new_book_id" class="col-sm-3 control-label">Select Book</label>
                              <div class="col-sm-9">
                                <select id="new_book_id" class="form-control ">
                                    <option value="1" class="form-control">11</option>
                                </select>
                                    <small >If book not found, <a id="addNewBook" href="#" >Add here</a></small>
                              </div>
                            </div><!-- /.form-group -->

                            <div class="form-group margin-bottom">
                              <label for="new_qty" class="col-sm-3 control-label">Quantity</label>
                              <div class="col-sm-9">
                                <input onkeyup = "getTotalAmount()" id="new_qty" type="number" placeholder="0" class="form-control">
                              </div>
                            </div><!-- /.form-group -->

                            

                            <div class="form-group margin-bottom">
                              <label for="new_unit_cost" class="col-sm-3 control-label">Unit Cost</label>
                              <div class="col-sm-9">
                                <input onkeyup ="getTotalAmount()" id="new_unit_cost" type="text" placeholder="0.00" class="form-control">
                              </div>
                            </div><!-- /.form-group -->

                            <div class="form-group margin-bottom">
                              <label for="new_total_amount" class="col-sm-3 control-label">Total</label>
                              <div class="col-sm-9">
                                <input id="new_total_amount" type="text" disabled class="form-control">
                              </div>
                            </div><!-- /.form-group -->

                            <div class="form-group margin-bottom">
                              <label for="" class="col-sm-3 control-label">&nbsp;</label>
                              <div class="col-sm-9">
                                <button type="button" class="btn btn-sm btn-default btn-flat" id="cncelBtn" >Cancel</button> &nbsp; 
                                <button type="button" class="btn btn-sm btn-primary btn-flat" id="btnAction" onclick="">Save</button>
                              </div>
                            </div><!-- /.form-group -->

                        </div>

                            <div class="col-lg-3">&nbsp;</div>
                        </div>

                        </form>

                    </div>

                </div><!-- /.body-->
                <div class="modal-footer">
		            <input class="btn btn-default btn-flat" data-dismiss="modal" type="reset" value="Close" name="cancel"> 
		        </div><!--footer-->
            </div> 
        </div>
    </div>





    <!-- -->
    <div id="poModal" class="modal fade" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times</button>
                    <h4 class="modal-title">Title</h4>
                </div>
                <form id="myFormPO" action="" method="post" class="form-horizontal">
                <div class="modal-body">
                    <div class="row">
                         <input type="hidden" id="purchase_id">
            
                         <div class="col-lg-12">
                            <div class="form-group">
                              <label for="new_sup_id" class="col-sm-3 control-label">Select Supplier</label>
                              <div class="col-sm-9">
                                <select id="new_sup_id" class="form-control"></select>
                              </div>
                            </div><!-- /.form-group -->

                            <div class="form-group">
                              <label for="new_po_no" class="col-sm-3 control-label">P.O No</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" id="new_po_no" placeholder="P.O. Number" >
                              </div>
                            </div><!-- /.form-group -->

                            <div class="form-group">
                              <label for="new_date_receive" class="col-sm-3 control-label">Date</label>
                              <div class="col-sm-9">
                                <input id="new_date_receive" type="date" class="form-control" >
                              </div>
                            </div><!-- /.form-group -->

                          </div><!-- /.col-md-12 -->
                         </div> <!-- /.row-->
                </div><!-- /.body-->
                <div class="modal-footer">
                      <button type="button" id="btnActionPO" onclick="" class="btn btn-primary btn-flat">Update</button>
                    <input class="btn btn-default btn-flat" data-dismiss="modal" type="reset" value="cancel" name="cancel"> 
                </div><!--footer-->
              </form>
            </div> 
        </div>
    </div>





<div id="bookModal" class="modal fade" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times</button>
                    <h4 class="modal-title">Title</h4>
                </div>
                <form id="myForm2" action="" method="post" class="form-horizontal">
                <div class="modal-body">
                <small class="text-info"> <i class="fa fa-info-o"></i> Fields with asterisk(*) are required</small>
                <br><br>
                    <div class="row">
                         <input type="hidden" id="book_sup_id">
            
                         <div class="col-lg-12">

                            <div class="form-group">
                              <label for="title" class="col-sm-3 control-label">Title *</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" id="title" placeholder="Title" >
                              </div>
                            </div><!-- /.form-group -->

                            <div class="form-group">
                              <label for="description" class="col-sm-3 control-label">Description *</label>
                              <div class="col-sm-9">
                                <textarea class="form-control" id="description" placeholder="Description" cols="30" rows="3"></textarea>
                              </div>
                            </div><!-- /.form-group -->

                            <div class="form-group">
                              <label for="book_yr_lvl" class="col-sm-3 control-label">Year Level *</label>
                              <div class="col-sm-9">
                                <select id="book_yr_lvl" class="form-control">
                                    <option value="">--select--</option>
                                    <option value="Grade 1">Grade 1</option>
                                    <option value="Grade 2">Grade 2</option>
                                    <option value="Grade 3">Grade 3</option>
                                    <option value="Grade 4">Grade 4</option>
                                    <option value="Grade 5">Grade 5</option>
                                    <option value="Grade 6">Grade 6</option>
                                    <option value="Grade 7">Grade 7</option>
                                    <option value="Grade 8">Grade 8</option>
                                    <option value="Grade 9">Grade 9</option>
                                    <option value="Grade 10">Grade 10</option>
                                    <option value="Grade 11">Grade 11</option>
                                    <option value="Grade 12">Grade 12</option>
                                    <option value="1st Year">1st Year</option>
                                    <option value="2nd Year">2nd Year</option>
                                    <option value="3rd Year">3rd Year</option>
                                    <option value="4th Year">4th Year</option>
                                </select>
                              </div>
                            </div><!-- /.form-group -->

                            <div class="form-group">
                              <label for="publisher" class="col-sm-3 control-label">Publisher *</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" id="publisher" placeholder="Publisher" >
                              </div>
                            </div><!-- /.form-group -->


                          </div><!-- /.col-md-12 -->
                         </div> <!-- /.row-->
                </div><!-- /.body-->
                <div class="modal-footer">
                      <button type="button" id="btnAction2" onclick="" class="btn btn-primary btn-flat">Update</button>
                    <input class="btn btn-default btn-flat" data-dismiss="modal" type="reset" value="cancel" name="cancel"> 
                </div><!--footer-->
              </form>
            </div> 
        </div>
    </div>





<script>

var book_id_val = '';
var showButton = 'showButton';

$(document).on("click", "#btnAction", function(event){
  event.preventDefault();
});

$(document).on("click", "#addNewBook", function(event){
    
        event.preventDefault();
        $('#book_id').val('');
        $('#title').val('');
        $('#description').val('');
        $('#book_yr_lvl').val('');
        $('#company_price').val('');
        $('#lnu_price').val('');
        $('#publisher').val('');
        $('#barcode_no').val('');
        $('#status').val('used');

        $('#myForm2').attr('action', '../actions/insertNewBook.php');
        $('#bookModal').find('.modal-title').text('Add New Book');
        $('#btnAction2').attr('onclick','insertNewBook()');
        $('#btnAction2').text('Submit');
        $('#bookModal').modal('show');
    });

function insertNewBook()
    {
        var url = $('#myForm2').attr('action');
        var result = '';

        var sup_id = $('#sup_id');
        var title = $('#title');
        var description = $('#description');
        var book_yr_lvl = $('#book_yr_lvl');
        var publisher = $('#publisher');

        var titleVal = title.val().replace(/\s{2,}/g,' ');
        var descriptionVal = description.val().replace(/\s{2,}/g,' ');
        var publisherVal = publisher.val().replace(/\s{2,}/g,' ');

        if(titleVal == '' || titleVal == ' '){
          title.parent().addClass('has-error');
          title.focus();
          return false;
        }else{
          title.parent().removeClass('has-error');
        }

        if(descriptionVal == '' || descriptionVal == ' '){
          description.parent().addClass('has-error');
          description.focus();
          return false;
        }else{
          description.parent().removeClass('has-error');
        }

        if(book_yr_lvl == ''){
          book_yr_lvl.parent().addClass('has-error');
          book_yr_lvl.focus();
          return false;
        }else{
          book_yr_lvl.parent().removeClass('has-error');
        }

        if(publisherVal == '' || publisherVal == ' '){
          publisher.parent().addClass('has-error');
          publisher.focus();
          return false;
        }else{
          publisher.parent().removeClass('has-error');
        }

    var queryString = '?title='+title.val();
        queryString += '&description='+description.val();
        queryString += '&book_yr_lvl='+book_yr_lvl.val();
        queryString += '&publisher='+publisher.val();
        queryString += '&sup_id='+sup_id.val();

    
    $.ajax({
        type: 'ajax',
        method: 'get',
        url: url+queryString,
        dataType: 'json',
        success: function(response){
            if(response.msg==true)
            {
                $('#bookModal').modal('hide');
                book_id_val = response.id;
                getAllBooks(sup_id.val());
            }
            else if(response.msg=='duplicate')
            {
                alert('Duplicate Found!');
            }
            else
            {
                alert('Unable to Add New Supplier');
            }
        },
        error: function(response){
          console.log(response);
        }
      });
    }


/* purchase order */

function registerNewBook()
{
    var po_id = $('#po_id').val();
    var sup_id =$('#sup_id').val();
    var newWindow = window.open("../homepage/books.php?ref=po&po_id="+po_id+"&sup_id="+sup_id+" ","location=no,top=50,left=20px,resizable=yes, width=900,height = 600");
} 

$(document).on("click", "#addNewPo", function(event)
{
    event.preventDefault();

    $('#new_sup_id').val('');
    $('#new_date_receive').val('');
    $('#new_po_no').val('');


    $('#btnActionPO').attr('onclick','insertNewPurchaseOrder()');
    $('#btnActionPO').text('Submit');
    $('#myFormPO').attr('action', '../actions/insertNewPurchaseOrder.php');
    $('#poModal').find('.modal-title').text('Add New Purchase Order');

    getSuppliers();

    $('#poModal').modal('show');
});

function insertNewPurchaseOrder()
{
    var url = $('#myFormPO').attr('action');
    var result = '';

    var sup_id = $('#new_sup_id');
    var date_receive = $('#new_date_receive');
    var po_no = $('#new_po_no');
        

    if(sup_id.val() == ''){
        sup_id.parent().addClass('has-error');
        sup_id.focus();
        return false;
    }else{
        sup_id.parent().removeClass('has-error');
    }

    if(date_receive.val() == ''){
        date_receive.parent().addClass('has-error');
        date_receive.focus();
        return false;
    }else{
        date_receive.parent().removeClass('has-error');
    }

    if(po_no.val() == ''){
        po_no.parent().addClass('has-error');
        po_no.focus();
        return false;
    }else{
        po_no.parent().removeClass('has-error');
    }

    var queryString = '?sup_id='+sup_id.val();
        queryString += '&date_receive='+date_receive.val();
        queryString += '&po_no='+po_no.val();
    
    $.ajax({
        type: 'ajax',
        method: 'get',
        url: url+queryString,
        dataType: 'json',
        success: function(response){
            if(response.msg==true)
            {
                $('#poModal').modal('hide');
                getPurchaseOrders();
            }
            else if(response.msg=='duplicate')
            {
                alert('P.O No already exist!');
            }
            else
            {
                alert('Unable to Add New PO');
            }
        },
        error: function(response){
          console.log(response);
        }
      });
}



function getSuppliers()
{
    $.get({
        url: '../actions/getSuppliers.php',
        dataType: 'json',
        success: function(data){
            console.log(data);
            var html = '<option value="">--select supplier--</option>';
            var i;
            if(!data)
            {
                alert("Error: No data received");
            }
            else
            {
               
               var data_count = data.length;
                for(i = 0; i < data_count; i++) 
                {
                  var cntrl = '';
                  if(data[i].status=='deactivated')
                  {
                      cntrl = 'disabled';
                  }
                    html += '<option value="'+data[i].sup_id+'" '+cntrl+'>'+data[i].name+'</option>';

                }

                if(data_count==0)
                {
                    $('#new_sup_id').html('<option value="">--no supplier found--</option>');
                }
                else
                {
                    $('#new_sup_id').html(html);
                }
            }
        },
        error: function(data){
            console.log(data);
        }
        });
    }

getSuppliers();
$(document).on("click", ".editPOrder", function(event)
{
    event.preventDefault();


    $('#btnActionPO').attr('onclick','editPurchagseOrder()');
    $('#btnActionPO').text('Update');
    $('#myFormPO').attr('action', '../actions/editPurchaseOrder.php');
    $('#poModal').find('.modal-title').text('Edit Purchase Order');

    var po_id = $(this).data('po_id');
    var sup_id = $(this).data('sup_id');
    var date_receive = $(this).data('date_receive');
    var po_no = $(this).data('po_no');

    $('#purchase_id').val(po_id);
    $('#new_sup_id').val(sup_id);
    $('#new_date_receive').val(date_receive);
    $('#new_po_no').val(po_no);

    $('#poModal').modal('show');
});

function editPurchagseOrder()
{
    var url = $('#myFormPO').attr('action');
    var result = '';
    
    var po_id = $('#purchase_id');
    var sup_id = $('#new_sup_id');
    var date_receive = $('#new_date_receive');
    var po_no = $('#new_po_no');
        

    if(sup_id.val() == ''){
        sup_id.parent().addClass('has-error');
        sup_id.focus();
        return false;
    }else{
        sup_id.parent().removeClass('has-error');
    }

    if(date_receive.val() == ''){
        date_receive.parent().addClass('has-error');
        date_receive.focus();
        return false;
    }else{
        date_receive.parent().removeClass('has-error');
    }

    if(po_no.val() == ''){
        po_no.parent().addClass('has-error');
        po_no.focus();
        return false;
    }else{
        po_no.parent().removeClass('has-error');
    }

    var queryString = '?sup_id='+sup_id.val();
        queryString += '&date_receive='+date_receive.val();
        queryString += '&po_no='+po_no.val();
        queryString += '&po_id='+po_id.val();
    
    $.ajax({
        type: 'ajax',
        method: 'get',
        url: url+queryString,
        dataType: 'json',
        success: function(response){
            if(response.msg==true)
            {
                $('#poModal').modal('hide');
                getPurchaseOrders();

            }
            else if(response.msg=='duplicate')
            {
                alert('Duplicate Found!');
            }
            else
            {
                alert('Unable to update P.O.!');
            }
        },
        error: function(response){
          console.log(response);
        }
      });
}


function getTotalAmount()
{
    var totalAmount = 0, strTotal='';
    var new_qty = $('#new_qty').val();
    var new_unit_cost = $('#new_unit_cost').val();
    


    totalAmount = parseFloat(new_qty) * parseFloat(new_unit_cost);
    
    if(isNaN(totalAmount)){
        strTotal = '0.00';
        $('#btnAction').prop('disabled',true);
    }else{
        strTotal = parseFloat(totalAmount);
        strTotal = strTotal.toFixed(2);
        $('#btnAction').prop('disabled',false);
    }


    $('#new_total_amount').val(strTotal);
    
}

function showFirst()
{
    $('#first').slideUp();
    $('#second').show();
}

function showSecond()
{
    $('#second').hide();
    $('#first').slideDown();
}

function getAllBooks(sup_id)
{
    $.get({
        url: '../actions/getAllBooks.php?sup_id='+sup_id,
        dataType: 'json',
        success: function(data){
            var html = '<option value="">--select book--</option>';
            var i;


            if(!data)
            {
                alert("Error: No data received");
            }
            else
            {
               
               var data_count = data.length;
                for(i = 0; i < data_count; i++) 
                {
                    var status_txt = '';
                    if(book_id_val == data[i].book_id){
                        status_txt = 'selected';
                    }else{
                        status_txt = '';
                    }

                    var dsTxt = '';
                    if(data[i].status=='unused'){
                      dsTxt = ' disabled';
                    }else{
                      dsTxt = '';
                    }

                    html += '<option value="'+ data[i].book_id +'" '+status_txt+' '+dsTxt+'>'+ data[i].title +'</option>';
                }

                if(data_count==0)
                {
                    $('#new_book_id').html('<option value="">No books found</option>');
                }
                else
                {
                    $('#new_book_id').html(html);
                }

                book_id_val = '';
            }
        },
        error: function(data){
            console.log(data);
        }
        });
    }

// view details data
function getPobBooks(po_id)
{
    $.get({
        url: '../actions/getPoBooks.php?po_id='+po_id,
        dataType: 'json',
        success: function(data){
            console.log(data);
            var html = "";
            var i;
            if(!data)
            {
                alert("Error: No data received");
            }
            else
            {
               
               var data_count = data.length;
               var strBnt = '';
                for(i = 0; i < data_count; i++) 
                {
                    var totalAmount = 0;
                        totalAmount = parseFloat(data[i].pob_qty) * parseFloat(data[i].company_price);

                    
                    if(showButton =='showButton')
                    {

                      strBnt = '<a href="#" class="editPO_Book btn btn-primary btn-flat btn-xs " data-pob_id="'+data[i].pob_id+'" data-book_id="'+data[i].book_id+'" data-po_id="'+data[i].po_id+'" data-pob_qty="'+data[i].pob_qty+'" data-company_price="'+data[i].company_price+'" data-company_price="'+data[i].company_price+'"><i class="fa fa-edit"></i> Edit</a>&nbsp;'+
                                    '<a href="#" class="removePoBook btn btn-danger btn-flat btn-xs " data-pob_id="'+data[i].pob_id+'" data-po_id="'+data[i].po_id+'" data-title="'+data[i].title+'"><i class="fa fa-remove"></i> Remove</a>';
                    }else{
                      strBnt = '';
                    }


                    html += '<tr>'+
                                    '<td>'+ (i+1) +'</td>'+
                                    '<td>Copies</td>'+
                                    '<td>'+ data[i].title +'</td>'+
                                    '<td>'+ data[i].pob_qty +'</td>'+
                                    '<td>'+ data[i].company_price +'</td>'+
                                    '<td>'+ totalAmount +'</td>'+
                                    '<td>'+ strBnt +'</td>'+
                                '</tr>';

                    
                    
                }

                if(showButton =='')
                {
                  html += '<tr><td><small class="text-warning"><i class="fa fa-info-circle"></i> This is already deliverd.</small></td></tr>';
                }

                

                if(data_count==0)
                {
                    $('#books_poList').html('<tr><td colspan="8">0 Books Found</td></tr>');
                }
                else
                {
                    $('#books_poList').html(html);
                }
            }
        },
        error: function(data){
            console.log(data);
        }
        });

    }

    function clearPurchaseFields()
    {
        $('#new_book_id').val('');
        $('#new_qty').val('');
        /*$('#new_unit').val('');*/
        $('#new_unit_cost').val('');
        $('#new_total_amount').val('');
        $('#msgBox').html('');
    }

    // add new book to P.O.
    $(document).on("click", "#addNewPurchaseBook", function(event)
    {
        event.preventDefault();
        $('#poTitle').text('ADD NEW ');
        $('#btnAction').attr('onclick','insertNewPO_Book()');
        $('#btnAction').text('Submit');

        clearPurchaseFields();
        showFirst();
        getAllBooks($('#sup_id').val());
        $('#btnAction').prop('disabled',true);
    });

    $(document).on("click", "#cncelBtn", function(event)
    {
        event.preventDefault();
        showSecond();
    });

    

    

    $(document).on("click", ".viewDetails", function(event)
    {
        var po_no = $(this).data("po_no");
        var po_id = $(this).data("po_id");
        var address = $(this).data("address");
        var name = $(this).data("name");
        var date_receive = $(this).data("date_receive");
        var sup_id = $(this).data("sup_id");
        var delivered_date = $(this).data("delivered_date");

        if(delivered_date===null){
          showButton = 'showButton';
          $('#addNewPurchaseBook').show();
        }else{
          //alert(delivered_date);
          showButton = '';
          $('#addNewPurchaseBook').hide();
        }



        $('#po_id').val(po_id);
        $('#address').text(address);
        $('#name').text(name);
        $('#date_receive').text(date_receive);
        $('#po_no').text(po_no);
        $('#sup_id').val(sup_id);

        getPobBooks(po_id);
        getAllBooks(sup_id);

        $//('#detailModal').find('.modal-title').text('Purchase Order No. ' + po_no);
        $('#detailModal').modal('show');

    });



getPurchaseOrders();

function getPurchaseOrders()
{
	var search_txt = $('#search_txt').val();

    $.get({
        url: '../actions/getPo.php?search_txt='+search_txt,
        dataType: 'json',
        success: function(data){
        	//console.log(data);
            var html = "";
            var i;
            if(!data)
            {
                alert("Error: No data received");
            }
            else
            {
               
               var data_count = data.length;
                for(i = 0; i < data_count; i++) 
                {
                	html += '<tr>'+
                                    '<td>'+ (i+1) +'</td>'+
                                    '<td>'+ data[i].po_no +'</td>'+
                                    '<td>'+ data[i].name +'</td>'+
                                    '<td>'+ data[i].date_receive +'</td>'+
                                    '<td>'+
                                    '<a href="#" class="viewDetails" data-delivered_date="'+data[i].delivered_date+'" data-sup_id="'+data[i].sup_id+'" data-po_id="'+data[i].po_id+'" data-po_no="'+data[i].po_no+'" data-name="'+data[i].name+'" data-date_receive="'+data[i].date_receive+'" data-address="'+data[i].address+'" > Add Books</a>'
                                     +'</td>'+

                                    '<td>'+

                                    '<a href="#" class="editPOrder btn btn-primary btn-flat btn-xs " data-sup_id="'+data[i].sup_id+'" data-po_id="'+data[i].po_id+'" data-sup_id="'+data[i].sup_id+'" data-po_no="'+data[i].po_no+'" data-date_receive="'+data[i].date_receive+'" data-po_status="'+data[i].po_status+'"><i class="fa fa-edit"></i> Edit</a>&nbsp;'+

                                    '</td>'+
                                '</tr>';
                }

                if(data_count==0)
                {
                    $('#supplierList').html('<tr><td colspan="8">0 Record Found</td></tr>');
                }
                else
                {
                    $('#supplierList').html(html);
                }
            }
        },
        error: function(data){
            console.log(data);
        }
        });
    }

   

    function insertNewPO_Book()
    {
        var po_id = $('#po_id');
        var new_book_id = $('#new_book_id');
        var new_qty = $('#new_qty');
        var new_unit = $('#new_unit');
        var new_unit_cost = $('#new_unit_cost');

        if(new_book_id.val() == ''){
          new_book_id.parent().addClass('has-error');
          new_book_id.focus();
          return false;
        }else{
          new_book_id.parent().removeClass('has-error');
        }

        if(new_qty.val() == ''){
          new_qty.parent().addClass('has-error');
          new_qty.focus();
          return false;
        }else{
          new_qty.parent().removeClass('has-error');
        }

        if(new_unit.val() == ''){
          new_unit.parent().addClass('has-error');
          new_unit.focus();
          return false;
        }else{
          new_unit.parent().removeClass('has-error');
        }

        if(new_unit_cost.val() == ''){
          new_unit_cost.parent().addClass('has-error');
          new_unit_cost.focus();
          return false;
        }else{
          new_unit_cost.parent().removeClass('has-error');
        }

        $('#msgBox').html('Saving...');

    var queryString = '?po_id='+po_id.val();
        queryString += '&new_book_id='+new_book_id.val();
        queryString += '&new_unit='+new_unit.val();
        queryString += '&new_unit_cost='+new_unit_cost.val();
        queryString += '&new_qty='+new_qty.val();
        
    var url = '../actions/insertNewPO_Book.php';
    
    $.ajax({ 
        type: 'ajax',
        method: 'get',
        url: url+queryString,
        dataType: 'json',
        success: function(response){
            $('#msgBox').html('');
            
            if(response.msg==true)
            {
                clearPurchaseFields();
                showSecond();
                $('#msgBox').html('<span class="text-success"><i class="fa fa-ok"></i> Successfully added!</span>');
               
                //alert(response.msg);
            }
            else if(response.msg=='duplicate')
            {
                $('#msgBox').html('<span class="text-warning"><i class="fa fa-warning"></i> Duplicate Found</span>');
            }
            else
            {
                $('#msgBox').html('<span class="text-warning"><i class="fa fa-warning"></i> Unable to add book!</span>');
            }

            getPobBooks(po_id.val());

        },
        error: function(response){
            alert(response.responseText);
          console.log(response);
        }
      });
    }

    $(document).on("click", ".editPO_Book", function(event)
    {
        var newPob_id = $(this).data("pob_id");
        var po_id = $(this).data("po_id");
        var book_id = $(this).data("book_id");
        var new_qty = $(this).data("pob_qty");
        //var new_unit = $(this).data("new_unit");
        var new_unit_cost = $(this).data("company_price");
        $('#new_unit').val('copies');


        $('#newPob_id').val(newPob_id);
        $('#new_book_id').val(book_id);
        $('#new_qty').val(new_qty);
        $('#new_unit_cost').val(new_unit_cost);
        $('#poTitle').text('Edit ');

        $('#btnAction').attr('onclick','updatePO_Book()');
        $('#btnAction').text('Update');
        getTotalAmount();
        showFirst();



    });

    function updatePO_Book()
    {
        var pob_id = $('#newPob_id');
        var po_id = $('#po_id');
        var new_book_id = $('#new_book_id');
        var new_qty = $('#new_qty');
        //var new_unit = $('#new_unit');
        var new_unit_cost = $('#new_unit_cost');

        if(new_book_id.val() == ''){
          new_book_id.parent().addClass('has-error');
          new_book_id.focus();
          return false;
        }else{
          new_book_id.parent().removeClass('has-error');
        }

        if(new_qty.val() == ''){
          new_qty.parent().addClass('has-error');
          new_qty.focus();
          return false;
        }else{
          new_qty.parent().removeClass('has-error');
        }

        if(new_unit_cost.val() == ''){
          new_unit_cost.parent().addClass('has-error');
          new_unit_cost.focus();
          return false;
        }else{
          new_unit_cost.parent().removeClass('has-error');
        }

        $('#msgBox').html('Saving...');

    var queryString = '?pob_id='+pob_id.val();
        queryString += '&new_book_id='+new_book_id.val();
        queryString += '&new_unit_cost='+new_unit_cost.val();
        queryString += '&new_qty='+new_qty.val();
        queryString += '&po_id='+po_id.val();

        
    var url = '../actions/editPO_Book.php';
    
    $.ajax({ 
        type: 'ajax',
        method: 'get',
        url: url+queryString,
        dataType: 'json',
        success: function(response){
            $('#msgBox').html('');
            
            if(response.msg==true)
            {
                showSecond();
            }
            else if(response.msg=='duplicate')
            {
                $('#msgBox').html('<span class="text-warning"><i class="fa fa-warning"></i> Duplicate Found</span>');
            }
            else
            {
                $('#msgBox').html('<span class="text-warning"><i class="fa fa-warning"></i> Unable to update details!</span>');
            }

            getPobBooks(po_id.val());

        },
        error: function(response){
            alert('error');
          console.log(response);
        }
      });
    }



    // remove P.O. Book
    $(document).on("click", ".removePoBook", function(event){
        event.preventDefault();

        var pob_id = $(this).data("pob_id");
        var po_id = $('#po_id').val();
        var title = $(this).data("title");
        var strClear = '';

        var queryString = '?pob_id='+pob_id;

        var url = '../actions/removePoBook.php';

        var conf = confirm("This will remove "+title+", click OK to continue.");
        if(conf == true)
        {
            $.ajax({
            type: 'ajax',
            method: 'get',
            url: url+queryString,
            dataType: 'json',
            success: function(response){
                if(response.msg==true)
                {
                  getPobBooks(po_id);
                }
                else
                {
                  alert('Unable to remove!');
                }
            },
            error: function(response){
              console.log(response);
            }
          });
        }

    });
</script>

<?php include '../template/footer.php'; ?>