<?php 
$layout_active = 'books_inventory';
$layout_header_txt = 'Books Inventory';
?>

<?php include '../template/header.php'; ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="../plugins/datatables/dataTables.bootstrap.css">
    <link rel="stylesheet" href="../plugins/jQueryUI/smoothness-theme/jquery-ui-smoothness.css">
    <style>
        .filter-date { width: 110px; margin-bottom: 10px; }
        .ui-widget-shadow { display: none!important; }
        .dataTables_length { display: inline-block; margin-top: 5px; }
        .dataTables_filter { display: inline-block; margin-top: 5px; float: right; }
        .date-filter { width: 100%; height: 5px; text-align: right; }
    </style>

    <!-- Default box -->
    <div class="box">
        <!-- <div class="box-header with-border">
            <h3 class="box-title">Books Data</h3>
        </div> -->
        <div class="box-body">
            <div class="date-filter" style="display:none;">
                Start Date: <input class="filter-date" type="text" id="dateStart" name="dateStart" size="30">
                End Date: <input class="filter-date" type="text" id="dateend" name="dateend" size="30">
            </div>
            <table id="books-inventory-table" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Barcode No.</th>
                        <th>Book Title</th>
                        <th>Supplier.</th>
                        <th>Total No. of Books</th>
                        <th>On Hand</th>
                        <th>Purchased</th>
                        <?php if($_COOKIE['user_type']=='system_admin'): ?>
                        <th>Company Price</th>
                        <?php endif; ?>
                        <th>LNU Price</th>
                    </tr>
                </thead>
                <tbody>
                        
    <?php
    // Check connection
    include('../connection/config.php');
        
    $sql="SELECT *,ppp.pob_lnu_price AS lnu_price, ppp.pob_company_price AS company_price, (SELECT SUM(sold_qty) from tbl_po_books pbks WHERE pbks.book_id = b.book_id) AS sold_qty, (SELECT s.name FROM tbl_suppliers s WHERE s.sup_id = b.sup_id)AS supplier, (SELECT SUM(delivered_qty) from tbl_po_books pb WHERE pb.book_id = b.book_id) AS total_count FROM `tbl_books` b LEFT JOIN tbl_po_books ppp ON ppp.book_id=b.book_id";

    $query=mysqli_query($mysqli,$sql)or die(mysqli_error($mysqli));
    $data=array();
    while($row=mysqli_fetch_array($query))
    {
        $data[] = array('book_id' => $row['book_id'], 
                        'barcode_no' => $row['barcode_no'],
                        'title' => $row['title'],
                        'description' => $row['description'],
                        'publisher' => $row['publisher'],
                        'company_price' => $row['company_price'],
                        'lnu_price' => $row['lnu_price'],
                        'user_id' => $row['user_id'],
                        'date_added' => $row['date_added'],
                        'status' => $row['status'],
                        'total_count' => $row['total_count'],
                        'sup_id' => $row['sup_id'],
                        'supplier' => $row['supplier'],
                        'sold_qty' => $row['sold_qty']
                        );
    }
    
    mysqli_close($mysqli);
    $count = 0;
    ?>
                    <?php foreach ($data as $key): ?>
                       <tr>
                            <td><?php $count++; echo $count; ?></td>
                            <td><?=$key['barcode_no']; ?></td>
                            <td><?=$key['title']; ?></td>
                            <td><?= $key['supplier']; ?></td>
                            <td><?php if($key['total_count']==''){echo '0';}else{echo $key['total_count']; } ?></td>
                            <td><?=$key['total_count'] - $key['sold_qty']; ?></td>
                            <td><?php if($key['sold_qty']==''){echo '0';}else{echo $key['sold_qty']; } ?></td>
                            <?php if($_COOKIE['user_type']=='system_admin'): ?>
                            <td><?=$key['company_price']; ?></td>
                            <?php endif; ?>
                            <td><?=$key['lnu_price']; ?></td>
                        </tr> 
                    <?php endforeach ?>
                </tbody>
            </table>
		<div class="row">
		    <div class="col-sm-3 col-sm-offset-9">
			<h4 class=""></h4>
		    </div>
		</div>
        </div>
        <!-- /.box-body -->
    </div>
    <!-- /.box -->

    <!-- DataTables -->
    <script src="../plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="../plugins/datatables/dataTables.bootstrap.min.js"></script>
    <script src="../plugins/jQueryUI/jquery-ui.min.js"></script>
    <script src="../plugins/jQueryUI/buttons/api_sum().js"></script>

    <script src="../plugins/jQueryUI/buttons/dataTables.buttons.min.js"></script>
    <script src="../plugins/jQueryUI/buttons/buttons.flash.min.js"></script>
    <script src="../plugins/jQueryUI/buttons/jszip.min.js"></script>
    <script src="../plugins/jQueryUI/buttons/pdfmake.min.js"></script>
    <script src="../plugins/jQueryUI/buttons/vfs_fonts.js"></script>
    <script src="../plugins/jQueryUI/buttons/buttons.html5.min.js"></script>
    <script src="../plugins/jQueryUI/buttons/buttons.print.min.js"></script>

    <script>
        $(function () {
            let oTable = $("#books-inventory-table").DataTable({
                dom: 'Blfrtip',
                buttons: [
                    'excel', 'pdf', 'print'
                ],
            });

            let inv_total = 0;

            $.fn.dataTableExt.afnFiltering.push(
                function( oSettings, aData, iDataIndex ) {
                    var iFini = document.getElementById('dateStart').value;
                    var iFfin = document.getElementById('dateend').value;
                    var iStartDateCol = 3;
                    var iEndDateCol = 3;

                    iFini=iFini.substring(0,2) + iFini.substring(3,5) + iFini.substring(6,10);
                    iFfin=iFfin.substring(0,2) + iFfin.substring(3,5) + iFfin.substring(6,10);

                    var datofini=aData[iStartDateCol].substring(0,2) + aData[iStartDateCol].substring(3,5) + aData[iStartDateCol].substring(6,10);
                    var datoffin=aData[iEndDateCol].substring(0,2) + aData[iEndDateCol].substring(3,5) + aData[iEndDateCol].substring(6,10);

                    if ( iFini === "" && iFfin === "" )
                    {
                        inv_total += parseInt(aData[4]);
                        return true;
                    }
                    else if ( iFini <= datofini && iFfin === "")
                    {
                        inv_total += parseInt(aData[4]);
                        return true;
                    }
                    else if ( iFfin >= datoffin && iFini === "")
                    {
                        inv_total += parseInt(aData[4]);
                        return true;
                    }
                    else if (iFini <= datofini && iFfin >= datoffin)
                    {
                        inv_total += parseInt(aData[4]);
                        return true;
                    }
                    return false;
                }
            );

            $('#dateStart, #dateend').datepicker({
            dateFormat: 'mm/dd/yy',
            arrows: true
            });

            /* Add event listeners to the two range filtering inputs */
            $('#dateStart').keyup( function() { inv_total = 0; oTable.draw(); setTotalSales( inv_total ); } );
            $('#dateend').keyup( function() { inv_total = 0; oTable.draw(); setTotalSales( inv_total ); } );

            /* Add event listeners to the two range filtering inputs */
            $('#dateStart').change( function() { inv_total = 0; oTable.draw(); setTotalSales( inv_total ); } );
            $('#dateend').change( function() { inv_total = 0; oTable.draw(); setTotalSales( inv_total ); } );

            /* Add event listeners to the two range filtering inputs */
            $('#name').keyup( function() { inv_total = 0; oTable.draw(); setTotalSales( inv_total ); } );
            $('#name').change( function() { inv_total = 0; oTable.draw(); setTotalSales( inv_total ); } );
            setTotalSales( oTable.column(5).data().sum() );
            console.log(oTable.column(5).data().sum());
        });
        function setTotalSales(sum){
            //$("#total-sales").html("Total Sales: " + sum );
            $(".dt-button").addClass("btn btn-primary btn-sm").css("margin", "0px 5px 5px 0px");
            $(".buttons-excel").prepend("<i class='fa fa-file-excel-o'></i> ");
            $(".buttons-pdf").prepend("<i class='fa fa-file-pdf-o'></i> ");
            $(".buttons-print").prepend("<i class='fa fa-print'></i> ");
        }
    </script>

<?php include '../template/footer.php'; ?>