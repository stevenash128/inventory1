<?php 
$layout_active = 'database';
$layout_header_txt = 'Database Backup';
?>

<?php include '../template/header.php'; ?>

<div class="box box-primary" >
	<div class="box-header">
		<button onclick="backup_database()" class="btn btn-primary btn-sm btn-flat"><span class="fa fa-save"></span>&nbsp;Backup Database</button>
	</div>
	<div class="box-body" style="min-height:300px;">
	<table class="table" >
			<tr >
			<td >#</td>
			<td >Database Name</td>
			<td >&nbsp;</td>
			</tr>
			<?php
			include('../connection/config.php');

			$db_dir = 'data';
			$count = 0;
			$dir = opendir ("../".$db_dir); 
			while (false !== ($file = readdir($dir)))
			{
				if (strpos($file,'.sql',1)) 
				{ 
					$file = trim($file);
					$count++; 
					echo "<tr style='background-color:white;' class='active'>";
					echo '<td>'.$count.'</td>';
					echo '<td>'.$file.'</td>';
					echo "<td align='center'>".
							"<a href='../".$db_dir."/" . $file . "' class='btn btn-success btn-xs btn-flat'>
							<span class='glyphicon glyphicon-download-alt'></span>&nbsp;Download File</a>&nbsp;
							
						  </td>";
					echo "</tr>";
					
					}
			}

			//<button data-file='".$file."' class='restore btn btn-info btn-xs btn-flat'><span class='glyphicon glyphicon-refresh'></span> Restore</button>".

			if($count==0){
				echo '<tr class="alert-warning">'.
						'<td colspan="3">No database backup</td>';
					 '</tr>';
			}

			 
			?> 
		
			</table><!--./table-->
	</div>
</div>

<script>
	function backup_database()
	{
		var conf = confirm("This will backup the whole database.\nIf you want to continue, press OK.");
		if(conf==true)
		{
			window.location.href = "../actions/database_backup.php";
		}
	}

	$(document).on("click", ".restore", function(event)
	{
		var file = $(this).data("file");
		var conf = confirm("This will restore previous data. Records prior to data backup will be lost.\nIf you want to continue, press OK.");
		if(conf==true)
		{
			window.location.href = "../actions/restore.php?file="+file;
		}
	});
</script>
</body>
</html>

<?php include '../template/footer.php'; ?>