<?php 
$layout_active = 'purchase';
$layout_header_txt = 'Purchase a Book';
?>

<?php include '../template/header.php'; ?>

<div class="row">
	<div class="col-sm-7">
		<div class="box ">
          <div class="box-header ">
          <form id="searchForm">
          <div class="row">
              <div class="col-lg-6">
              <div class=" checkbox" style="margin-top:0;">
                      <label >
                          <input type="checkbox" value="yes" id="yesChk" checked>
                           Auto add
                      </label>
                  </div>
                <div class="input-group">

                  <input type="text" class="form-control" id="search_txt" placeholder="Enter Barcode No." autofocus>
                  <div class="input-group-btn">
                    <button id="search_btn" type="button" class="btn btn-default btn-flat" ><i class="fa fa-search"></i></button>
                  </div><!-- /btn-group -->
                </div><!-- /input-group -->
              </div><!-- /.col-lg-6 -->
              <div class="col-lg-6">
                  
              </div>
            </div><!-- /.row -->

            </form>
          
        </div>
        <!-- /.box-header -->
		<div class="box-body">
       

          <div class="table-responsive">
		  <table class="table table-bordered table-striped table-hover table-condensed">
		  	<thead>
		  		<tr style="background-color:#ddd;">
		  			<th width="10px">#</th>
                    <th>Barcode No</th>
		  			<th>Title</th>
		  			<th>Stock on Hand</th>
                    <th>Price</th>
                    <th></th>
		  		</tr>
		  	</thead>
		  	<tbody id="bookList">
			</tbody>
		  </table>
          </div>
          
          <div id="pagination_link"></div>

		  </div><!-- /.box-body -->
		</div><!-- /.box -->


		
	</div>
    <div class="col-sm-5">
        <div class="panel table-responsive">
            <div class="panel-heading bgn-blue">
            <span><i class="fa fa-shopping-cart"></i> Cart</span>
            <a href="" class="pull-right" id="clearCart"><i class="fa fa-trash"></i> Clear Items</a>
            </div>

            <div class="panel-body">
                <table class="table table-bordered">
                    <thead>
                    <tr>
                    <th colspan="6">Item</th>
                    </tr>
                    </thead>
                    <tbody id="cartItemsList"></tbody>
                    
                </table>
            </div>
            <div class="panel-footer">
                <button data-total="" id="buyItems" class="btn btn-primary btn-sm btn-flat">Buy</button>
                <span class="pull-right">Total: <b>P<span id="totalSpan">0.00</span></b></span>
            </div>
        </div>
    </div>
</div>


<!--modal itemModal-->
      <div id="paymentModal" class="modal fade" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog ">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times</button>
                    <h4 class="modal-title">Title</h4>
                </div>
                <form id="myForm" action="" method="post" class="form-horizontal">
                <div class="modal-body">
                    <div class="row">
			             <div class="col-lg-12">
                            <div class="form-group">
                                <div class="col-sm-3">&nbsp;</div>
                            </div><!-- /.form-group -->

                            <div class="form-group">
                              <label for="stud_no" class="col-sm-3 control-label">Student No</label>
                              <div class="col-sm-8">
                                <input type="number" class="form-control" id="stud_no" placeholder="Enter Student ID Number">
                              </div>
                            </div><!-- /.form-group -->

			                <div class="form-group">
			                  <label for="item" class="col-sm-3 control-label">Amount Payable</label>
			                  <div class="col-sm-8">
			                    <input type="text" class="form-control" id="amount_payable" placeholder="" disabled>
			                  </div>
			                </div><!-- /.form-group -->

                            <div class="form-group">
                              <label for="or_status" class="col-sm-3 control-label">Select Status</label>
                              <div class="col-sm-8 ">
                                <select onchange="selectORNO(this.value)" id="or_status" class="form-control">
                                    <option value="">--select--</option>
                                    <option value="cash">Cash</option>
                                    <option value="promisory">Promisory Note</option>
                                </select>
                              </div>
                            </div><!-- /.form-group -->

                            <div class="form-group">
                              <label for="or_no" class="col-sm-3 control-label">OR No</label>
                              <div class="col-sm-8 ">
                                <input type="text" class="form-control" id="or_no" placeholder="" autocomplete="off">
                              </div>
                            </div><!-- /.form-group -->

                            <!-- <div class="form-group ">
                              <label for="selling_price" class="col-sm-3 control-label">Change</label>
                              <div class="col-sm-8">
                                <input type="text" class="form-control" id="change" placeholder="" autocomplete="off" disabled>
                              </div>
                            </div>/.form-group -->

			              </div><!-- /.col-md-12 -->
			             </div> <!-- /.row-->
                </div><!-- /.body-->
                <div class="modal-footer">
	                  <button type="button" id="btnAction" onclick="" class="btn btn-primary btn-flat">Buy</button>
		            <button class="btn btn-default btn-flat" data-dismiss="modal" type="reset">Cancel</button>
		        </div><!--footer-->
	          </form>
            </div> 
        </div>
    </div>
    <!--./modal Item-->




<script>

$(function() { 
    $('#searchForm').on('submit', function(e) { 
        e.preventDefault();
        getBooks();
    });

    $("#search_txt").bind("paste", function() {
        getBooks();
    });
});

function selectORNO(val)
{
    if(val=='cash'){
        $('#or_no').prop('disabled',false);
    }else{
        $('#or_no').prop('disabled', true);
        $('#or_no').val('');
    }
}

function addToCart(book_id,title,lnu_price)
{
        var qString = '?book_id='+book_id;
            qString += '&title='+title;
            qString += '&lnu_price='+lnu_price;

            $.ajax({
            type: 'ajax',
            method: 'get',
            url: '../actions/addToCart.php'+qString,
            dataType: 'json',
            success: function(response){
                console.log(response);
                //showMsg('You have added '+ item_name + ' to cart.');
                getCartItems();
            },
            error: function(response){
                console.log(response);
                alert('Sorry, something went wrong.');
            }
    });
}

/*function addToCart(book_id,title,lnu_price)
{
        var qString = '?book_id='+book_id;
            qString += '&title='+title;
            qString += '&lnu_price='+lnu_price;

            $.ajax({
            type: 'ajax',
            method: 'get',
            url: '../actions/addToCart.php'+qString,
            dataType: 'json',
            success: function(response){
                console.log(response);
                //showMsg('You have added '+ item_name + ' to cart.');
                getCartItems();
            },
            error: function(response){
                console.log(response);
                alert('Sorry, something went wrong.');
            }
    });
}*/

//getBooks();

function getBooks()
{
    var search_txt = $('#search_txt').val();
    var search_txt = search_txt.replace(/\s{2,}/g,' ');
    if(search_txt=='' || search_txt==' '){
        $('#search_txt').focus();
        return false;
    }

    $.get({
        url: '../actions/getBooks.php?barcode_no='+search_txt,
        dataType: 'json',
        success: function(data){
            //console.log(data);
            var html = "";
            var i;
            if(!data)
            {
                alert("Error: No data received");
            }
            else
            {
               
               var data_count = data.length;
                for(i = 0; i < data_count; i++) 
                {

                    var stock_on_hand = data[i].stock_on_hand; //parseInt(data[i].total_count) - parseInt(data[i].sold_qty);
                    if(isNaN(stock_on_hand)==true){
                        stock_on_hand = 0;
                    }

                    var price = parseFloat(data[i].lnu_price);
                        price = price.toFixed(2);
                    var btnCtrl = '';

                        if(stock_on_hand > 0)
                        {
                            btnCtrl = '<a href="#" class="addToCart btn btn-success btn-flat btn-xs btn-block" data-book_id="'+data[i].book_id+'" data-barcode_no="'+data[i].barcode_no+'" data-title="'+data[i].title+'" data-title="'+data[i].title+'" data-lnu_price="'+data[i].lnu_price+'" ><i class="fa fa-plus"></i> Add to Cart</a>';

                            var yesChk =  document.getElementById("yesChk").checked;

                           if(yesChk == true)
                            {
                                addToCart(data[i].book_id,data[i].title,data[i].lnu_price);
                            }
                        }
                        else
                        {
                            btnCtrl = '<span class="text-warning">Out of Stock</span>';
                        }


                    

                    html += '<tr>'+
                                    '<td>'+ (i+1) +'</td>'+
                                    '<td>'+ data[i].barcode_no +'</td>'+
                                    '<td><a title="'+ data[i].description +'">'+ data[i].title +'<a></td>'+
                                    '<td>'+ stock_on_hand +'</td>'+
                                    '<td>P'+ price +'</td>'+
                                    '<td>'+ btnCtrl +'</td>'+
                            '</tr>';
                }

                if(data_count==0)
                {
                    $('#bookList').html('<tr><td colspan="8">No book found</td></tr>');
                }
                else
                {
                    $('#bookList').html(html);
                }

                /*if(yesChk == true)
                {
                    $('#search_txt').val('');
                    $('#search_txt').focus();
                    $('#bookList').html('');
                }*/
            }
        },
        error: function(data){
            console.log(data);
        }
        });
    }



function adjustQty(key,book_id,index)
{
    var cval = $('#in'+book_id).val();
    if(key=='add')
    {
        $('#in'+book_id).val(parseInt(cval) + 1);
    }
    else if(key=='minus')
    {
        if(cval>=2){
            $('#in'+book_id).val(parseInt(cval) - 1);
        }
    }

    var qString = '?key='+key;
        qString += '&book_id='+book_id;
        qString += '&index='+index;
        qString += '&qty='+$('#in'+book_id).val();
    
    $.ajax({
        type: 'ajax',
        method: 'get',
        url: '../actions/adjustQty.php'+qString,
        dataType: 'json',
        success: function(response){
            getCartItems();
        },
        error: function(response){
            console.log(response);
            alert('Sorry, something went wrong.');
        }
    });
}

$(document).ready(function(){

    $(document).on("click", ".addQty", function(event){
        event.preventDefault();
        var id = $(this).data("id");
        var index = $(this).data("index");
        
        adjustQty('add', id, index);
        
        
    });

    $(document).on("click", ".minusQty", function(event){
        event.preventDefault();
        var id = $(this).data("id");
        var index = $(this).data("index");
        adjustQty('minus', id, index);
    });

    $(document).on("keyup", ".item-qty", function(event){
        event.preventDefault();

        var id = $(this).data("book_id");
        var index = $(this).data("index");
        var qty = $('#in'+id).val();

        if(qty == ''){
            alert('Invalid quantity');
            $('#in'+id).val(1);
            return false;
        }else if(parseInt(qty) <= 0){
            alert('Invalid quantity');
            $('#in'+id).val(1);
            return false;
        }
        

        if(parseInt(qty)>=1)
        {
            adjustQty('and', id, index);
        }
        else
        {
            var lnth = qty.length;
            qty.slice(0,lnth-1);
            $('#in'+id).val(qty);
        }

        
    });

    /**/


    $("#amount_rendered").keyup(function(){
        var amount_payable = parseFloat($('#amount_payable').val());
        var cash = parseFloat($('#amount_rendered').val());
        var change = 0.00;
            change = cash - amount_payable;
            change = change.toFixed(2);

        $('#ar-span').fadeIn('slow');

        if(cash>=amount_payable)
        {
            $('#change').val(change);
            $('#amount_rendered').parent().removeClass('has-error');
            $('#ar-span').removeClass('text-warning fa-warning');
            $('#ar-span').addClass('text-success fa-check-circle');
        }
        else
        {
            $('#amount_rendered').parent().addClass('has-error');
            $('#ar-span').removeClass('text-success fa-check-circle');
            $('#ar-span').addClass('text-warning fa-warning');
            $('#change').val('0.00');
        }

        if(cash==''){
            $('#ar-span').fadeOut('slow');
        }

    });

    $("#buyItems").on("click", function()
    {
        event.preventDefault();
        //$('#ar-span').fadeOut();
        var amount_payable = parseFloat($('#totalSpan').text());
            amount_payable = amount_payable.toFixed(2);

        $('#amount_payable').val(amount_payable);
        $('#stud_no').val('');
        $('#or_no').val('');
        $('#or_status').val('');


        $('#myForm').attr('action','../actions/buyBoos');
        $('#paymentModal').find('.modal-title').text('Buy Items');
        $('#btnAction').attr('onclick','buyItems()');
        $('#btnAction').html('Buy');
        //$('#msgdiv').html('');
        $('#paymentModal').modal('show');
        $('#stud_no').focus();
    });

    $(document).on("click", "#clearCart", function(event){
        event.preventDefault();
        var conf = confirm("Are you sure you want to clear items on the cart?");
        if(conf==true)
        {
            $.ajax({
                type: 'ajax',
                method: 'get',
                url: '../actions/clearCart.php',
                dataType: 'json',
                success: function(response){
                    //console.log(response);
                    getCartItems();
                    showMsg('Cart succesfully cleared!');
                },
                error: function(response){
                    console.log(response);
                  alert('Sorry, something went wrong.');
                }
              });
        }
    });


    $(document).on("click", ".removeFromCart", function(event){
        event.preventDefault();
        var conf = confirm("Are you sure you want to remove items on the cart?");
        if(conf==true)
        {
            var index = $(this).data("index");
            $.ajax({
                type: 'ajax',
                method: 'get',
                url: '../actions/removeFromCart.php?index='+index,
                dataType: 'json',
                success: function(response){
                    //console.log(response);
                    getCartItems();
                    showMsg('Succesfully Removed!');
                },
                error: function(response){
                    console.log(response);
                  alert('Sorry, something went wrong.');
                }
              });
        }
    });



    $(document).on("click", ".addToCart", function(event){
        event.preventDefault();
        var book_id = $(this).data("book_id");
        var title = $(this).data("title");
        var lnu_price = $(this).data("lnu_price");
        
        if(book_id != '')
        {
          addToCart(book_id,title,lnu_price);
        }
    });

    

    

    $("#search_btn").on("click", function()
    {
    	getBooks();
    });

    $(document).on("click", ".pagination li a", function(event){
    	event.preventDefault();
    	var page = $(this).data("ci-pagination-page");
    	//alert(page);
    	getItems(page);
    });
});


getCartItems();
function getCartItems()
{
        $.ajax({
        type: 'ajax',
        method: 'get',
        url: '../actions/getCartItems.php',
        dataType: 'json',
        success: function(data){
            console.log(data);

            
            var data_count = data.length;
            var x = 0;
            var html = '';
            var total = 0;
            for(i = 0; i < data_count; i++) 
            {
                var gy = parseFloat(data[i].lnu_price);
                    gy = gy.toFixed(2);
                x++;
                html += '<tr>'+
                            '<td width="20px;">'+ x +'</td>'+
                            '<td>'+
                            '<a href="#" data-index="'+i+'"  data-book_id="'+data[i].book_id+'" data-qty="'+data[i].qty+'" class="removeFromCart text-danger"><i class="fa fa-remove"></i></a>'+
                            '</td>'+
                            '<td>'+ data[i].title +'</td>'+
                            '<td>P '+ gy +'</td>'+
                            '<td><input class="item-qty" data-book_id="'+data[i].book_id+'" data-index="'+i+'" id="in'+data[i].book_id+'" style="width:50px" type="number" min="1" value="'+ data[i].qty +'"></td>'+
                            '<td>'+
                                '<a href="#" data-id="'+data[i].book_id+'" data-index="'+i+'" class="minusQty btn btn-default btn-xs btn-flat"><i class="fa fa-minus"></i></a>'+
                                '<a href="#" data-id="'+data[i].book_id+'" data-index="'+i+'" class="addQty btn btn-success btn-xs btn-flat"><i class="fa fa-plus"></i></a>&nbsp;'+
                                
                            '</td>'+
                        '</tr>';
                total = total + (parseInt(data[i].qty) * parseFloat(data[i].lnu_price));
                //total = tota.toFixed(2);

            }
            if(data_count==0)
            {
                html = '<tr class="alert-warning"><td colspan="13">No items on cart</td></tr>';
            }

            var xc = total;
            xc = total.toFixed(2);

            $('#totalSpan').text(xc);

            $('#cartItemsList').html(html);

            if(data_count == 0)
            {
                $('#buyItems').prop('disabled',true);
            }
            else
            {
                $('#buyItems').prop('disabled',false);
            }
            

        },
        error: function(data){
            console.log(data);
            alert('Sorry, something went wrong.');
        }
    });
}

function buyItems()
{
    var stud_no = $('#stud_no');
    var or_no = $('#or_no');
    var or_status = $('#or_status');

    var stud_noVal = stud_no.val().replace(/\s{2,}/g,' ');
    var or_noVal = or_no.val().replace(/\s{2,}/g,' ');
    var or_statusVal = or_status.val().replace(/\s{2,}/g,' ');

    if(stud_noVal == '' || stud_noVal == ' '){
        stud_no.parent().addClass('has-error');
        stud_no.focus();
        return false;
    }else{
        stud_no.parent().removeClass('has-error');
    }

    if(or_statusVal == '' || or_statusVal == ' '){
        or_status.parent().addClass('has-error');
        or_status.focus();
        return false;
    }else{
        or_status.parent().removeClass('has-error');
    }

    if(or_status.val()=='cash')
    {
        if(or_noVal == '' || or_noVal == ' '){
            or_no.parent().addClass('has-error');
            or_no.focus();
            return false;
        }else{
            or_no.parent().removeClass('has-error');
        }
    }

    var amount_payable = $('#amount_payable').val();
    if(parseFloat(amount_payable)<= 0)
    {
        $('#amount_payable').focus();
        alert('You have nothing to buy!');
        return false;
    }
    //var amount_rendered = $('#amount_rendered').val();
    var or_no = $('#or_no').val();
    var stud_no = $('#stud_no').val();
    var or_status = $('#or_status').val();

    var qString = '?amount_payable='+amount_payable;
        qString += '&or_no='+or_no;
        qString += '&stud_no='+stud_no;
        qString += '&or_status='+or_status;

        

    $.ajax({
        type: 'ajax',
        method: 'get',
        url: '../actions/buyItems.php'+qString,
        dataType: 'json',
        success: function(response){

            if(response.msg==true){
                //showMsg('Transaction successfully saved!');
                
                $('#bookList').html('');
                $('#search_txt').val('');
                $('#paymentModal').modal('hide');
                getCartItems();
                alert('Transaction successfully saved!');
                printReceipt(response.id);
                
                //console.log(response.id);
                
            }
            else if(response.msg=='multiple_stud_no')
            {
                alert('Warning: Student Number appear multiple times');
            }
            else if(response.msg=='stud_no_not_found')
            {
                alert("Warning: No student with such ID number is recorded yet.\nYou may add first the student number in the students maintenance.");
            }
            else
            {
                alert("Unable to proccess transacion");
            }
            
        },
        error: function(response){
            console.log(response);
            alert('Sorry, something went wrong.');
        }
    });
}

function printReceipt(trans_id)
{
    var newWindow = window.open("printReceipt.php?trans_id="+trans_id+" ","location=no,top=50,left=20px,resizable=yes, width=500,height = 400");
}

</script>

<?php include '../template/footer.php'; ?>