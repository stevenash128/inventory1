<?php 
$layout_active = 'profile';
$layout_header_txt = 'Personal Profile';
?>

<?php include '../template/header.php'; ?>
<?php 

include('../connection/config.php');
$result = mysqli_query($mysqli,"SELECT * FROM tbl_users WHERE id = ".$_COOKIE['user_id']." ");
$rData = mysqli_fetch_array($result);

 ?>
<div class="row">

        <div class="col-md-12">
          <!-- Widget: user widget style 1 -->
          <div class="box box-widget widget-user-2">
            <!-- Add the bg color to the header using any of the bg-* classes lnu-logo.png igp-logo-2.jpeg-->
            <div class="widget-user-header bg-white">
              <div class="widget-user-image">
                <img src="../assets/image/igp-logo-2.jpeg" alt="LNU Logo" style="width:150px;height:auto;border:2px solid #ddd;margin-right:10px;padding:5px 10px 10px 10px;">
              </div>
              <!-- /.widget-user-image -->
              <h3 class="widget-user-username">
              <?=$_COOKIE['fullname'] ?>
                </h3>
              <h5 class="widget-user-desc">
              <?php 
                if(isset($_COOKIE['user_type']))
                {
                  if($_COOKIE['user_type'] == 'system_admin')
                  {
                    echo 'IGP Director';
                  }
                  elseif($_COOKIE['user_type'] == 'clerk')
                  {
                    echo 'Admin Aid';
                  }
                  elseif($_COOKIE['user_type'] == 'rel_personnel')
                  {
                    echo 'Releasing Personnel';
                  }
                }

                ?> 
               
              </h5>
            </div>
            <div class="row">
              
              <div class="col-sm-12">
                <div style="padding:0px 10px;"><h5 class="gray-me"><span class="glyphicon glyphicon-info-sign"></span>&nbsp;Informations</h5></div>
                <div class="box-footer ">
                
                <!-- Custom tabs (Charts with tabs)-->
                <div class="nav-tabs-custom ">
                  <!-- Tabs within a box -->
                  <ul class="nav nav-tabs ">
                    <li class="active"><a href="#revenue-chart" data-toggle="tab"><span class="glyphicon glyphicon-user"></span>&nbsp;Personal</a></li>
                    <li><a href="#security" data-toggle="tab"><span class="glyphicon glyphicon-lock"></span>&nbsp;Security</a></li>
                    <!-- <li><a href="#logs" data-toggle="tab"><span class="glyphicon glyphicon-list"></span>&nbsp;Logs</a></li> -->
                  </ul>
                  <div class="tab-content no-padding">
                  <br>
                    <!-- Morris chart - Sales -->
                    <div class="chart tab-pane active" id="revenue-chart" style="position: relative; min-height: 400px;">
                      <form action="../actions/editMyPersonal_info.php" class="form-horizontal" method="post">
                      
                      <div class="row">
                      
                       <div class="col-md-10">
                          <div class="form-group">
                            <label for="fname" class="col-sm-3 control-label">First Name</label>
                            <div class="col-sm-6">
                              <input value="<?=$rData['fname'];?>" type="text" class="form-control" id="fname" name="fname" placeholder="First Name" required>
                            </div>
                          </div>

                          <div class="form-group">
                            <label for="mname" class="col-sm-3 control-label">Middle Name</label>
                            <div class="col-sm-6">
                              <input value="<?=$rData['mname'];?>" type="text" class="form-control" id="mname" name="mname" placeholder="Middle Name">
                            </div>
                          </div>

                          <div class="form-group">
                            <label for="lname" class="col-sm-3 control-label">Last Name</label>
                            <div class="col-sm-6">
                              <input value="<?=$rData['lname'];?>" type="text" class="form-control" id="lname" name="lname" placeholder="Last Name" required>
                            </div>
                          </div>

                          <div class="form-group">
                            <label for="username" class="col-sm-3 control-label">Username</label>
                            <div class="col-sm-6">
                              <input value="<?=$rData['username'];?>" type="text" class="form-control " id="username" placeholder="Username" disabled>
                            </div>
                          </div>

                          <div class="form-group">
                            <label for="email" class="col-sm-3 control-label">Email</label>
                            <div class="col-sm-6">
                              <input value="<?=$rData['email'];?>" type="email" class="form-control" id="email" name="email" placeholder="Email" >
                            </div>
                          </div>
                          
                      <div class="form-group">
                            <label for="sex" class="col-sm-3 control-label">Sex</label>
                            <div class="col-sm-6">
                            <?php $sex = $rData['sex']; ?>
                              <select name="sex" id="sex" class="form-control" required>
                                <option value="">--select--</option>
                                <option <?php if($sex=='Male'){echo 'selected';} ?> value="Male">Male</option>
                                <option <?php if($sex=='Female'){echo 'selected';} ?> value="Female">Female</option>
                              </select>
                            </div>
                      </div>
                          
                  <div class="form-group">
                  <label for="" class="col-sm-3 control-label"></label>
                  <div class="col-sm-4">
                            <button type="submit" name="btnPersonal" class="btn btn-primary btn-flat btn-sm">Update</button>
                          </div>
                  </div>
                          
                        </div>
                        <!-- /.col-md-12 -->
                        
                       </div> <!-- /.row-->
                       </form>
                    </div>

                    <div class="chart tab-pane" id="security" style="position: relative; height: 300px;">
                      <form action="../actions/editMySecurityDetails.php" class="form-horizontal" method="post">
                      <div class="row">
                      
                       <div class="col-md-10">
                          <div class="form-group">
                            <label for="curPass" class="col-sm-3 control-label">Current Password</label>
                            <div class="col-sm-6">
                              <input type="password" class="form-control" id="curPass" name="curPass" placeholder="Enter Current Password" required>
                            </div>
                          </div>

                          <div class="form-group">
                            <label for="newPass" class="col-sm-3 control-label">New Password</label>
                            <div class="col-sm-6">
                              <input type="password" class="form-control" id="newPass" name="newPass" placeholder="Enter New Password" required>
                            </div>
                          </div>

                          <div class="form-group">
                            <label for="confPass" class="col-sm-3 control-label">Confirm New Password</label>
                            <div class="col-sm-6">
                              <input type="password" class="form-control" id="confPass" name="confPass" placeholder="Confirm New Password" required>
                            </div>
                          </div>

                          <div class="form-group">
                          <label for="" class="col-sm-3 control-label"></label>
                          <div class="col-sm-4">

                          <button type="submit" name="securityBtn" class="btn btn-primary btn-flat btn-sm">Submit</button>
                          </div>
                          </div>
                          
                        </div>
                        <!-- /.col-md-12 -->
                        
                       </div> <!-- /.row-->
                       </form>
                    </div>
                    <!-- /.nav-tabs-custom -->

                    <div class="chart tab-pane" id="logs" style="position: relative; height: 300px;">
                      <ul class="nav nav-stacked">
                        <li><a href="#">Patients Added<span class="pull-right badge bg-blue">31</span></a></li>
                        <li><a href="#">Patients Records Added <span class="pull-right badge bg-aqua">5</span></a></li>
                        <li><a href="#">Number of Logins<span class="pull-right badge bg-green">12</span></a></li>
                      </ul>

                      <ul class="timeline">
                      <!-- timeline time label -->
                      <li class="time-label">
                          <span class="bg-red">
                              10 Feb. 2014
                          </span>
                      </li>
                      <!-- /.timeline-label -->

                      <!-- timeline item -->
                      <li>
                          <!-- timeline icon -->
                          <i class="glyphicon glyphicon-envelope bg-blue"></i>
                          <div class="timeline-item">
                              <span class="time"><i class="glyphicon glyphicon-time"></i> 12:05</span>

                              <h3 class="timeline-header"><a href="#">Support Team</a> ...</h3>

                              <div class="timeline-body">
                                  ...
                                  Content goes here
                              </div>

                              <div class="timeline-footer">
                                  <a class="btn btn-primary btn-xs">...</a>
                              </div>
                          </div>
                      </li>
                      <!-- END timeline item -->

                     

                  </ul>
                    </div>
                    <!-- /.nav-tabs-custom -->

                  </div>
                </div>
                <!-- /.nav-tabs-custom -->
                  
                </div>
              </div>
            </div>
            
          </div>
          <!-- /.widget-user -->
        </div>
        <!-- /.col -->
</div>
<!-- /.row -->

<?php include '../template/footer.php'; ?>