<?php
$layout_active = 'home';
$layout_header_txt = 'Home';
$year = strftime("%Y",$_SERVER['REQUEST_TIME']);



include("../connection/config.php");

$query = "SELECT count(*) as count FROM tbl_users WHERE active = 'yes'";
$res = mysqli_query($mysqli,$query);
$row = mysqli_fetch_array($res);
$users_count = $row['count'];

$query2 = "SELECT count(*) as count FROM tbl_books WHERE status = 'used'";
$res2 = mysqli_query($mysqli,$query2);
$row2 = mysqli_fetch_array($res2);
$books_count = $row2['count'];
	
$query3 = "SELECT count(*) as count FROM tbl_suppliers WHERE status = 'active'";
$res3 = mysqli_query($mysqli,$query3);
$row3 = mysqli_fetch_array($res3);
$sup_count = $row3['count'];

?>

<?php include '../template/header.php'; ?>

	<div>
    <?php if ($_COOKIE['user_type']!='rel_personnel'): ?>
      
    
		<div class="row">
        <div class="col-md-4 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-green"><i class="fa fa-users"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Active Users</span>
              <span class="info-box-number"><?=$users_count;?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- ./col -->
        <div class="col-md-4 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="fa fa-book"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Used Books</span>
              <span class="info-box-number"><?=$books_count;?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- ./col -->
        <div class="col-md-4 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-truck"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Active Suppliers</span>
              <span class="info-box-number"><?=$sup_count;?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- ./col -->
      </div>
      <!-- /.row -->
	</div>
  <?php endif ?>

<!-- <div class="row">
  <div class="col-sm-6">
    <div class="box">
      <div class="box-header">
        <span>To be Deliverd Books</span>
      </div>
      <div class="box-body" style="min-height:410px;">
        
         <table class="table">
            <tr>
              <th>#</th>
              <th>Description</th>
              <th>To be delivered</th>
            </tr>
          </table>
      </div>
    </div>
    
  </div> -->
    <div class="nav-tabs-custom" >

        <!-- Tabs within a box -->
        <ul class="nav nav-tabs pull-right ui-sortable-handle">
            <!-- <li ><a href="#sales-chart" data-toggle="tab" aria-expanded="true">Donut</a></li> -->
            <li class="active"><a href="#top-selling" data-toggle="tab" aria-expanded="false">Top Selling</a></li>
            <li class="pull-left header"><i class="fa fa-inbox"></i> Books</li>
        </ul>
        <div class="tab-content no-padding" style="min-height:410px;">
          <!-- Morris chart - Sales -->
          <div class="chart tab-pane active" id="top-selling" >
            <!-- <h3>Top Selling Books</h3> -->
            Select year
            <select id="year" class="inputClass">
            <?php include '../custom/year.php'; ?>
          </select>
          <br><br>
          <div id="topBooks"></div>
            <?php //include '../actions/getHomeData.php'; ?>
        </div>
          <div class="chart tab-pane " id="sales-chart" >
                    
          </div>
        </div>
</div>




<script>
	var year = '<?=$year;?>';
	getTop(year);
	function getTop(year)
	{
		$.ajax({
            type: 'ajax',
            method: 'get',
            url: '../actions/getHomeData.php?year='+year,
            success: function(response)
            {
                $('#topBooks').html(response);
            },
            error: function(response)
            {
              console.log(response);
            }
          });
	}

	$(function() { 
	    $('#year').on('change', function(e) { 
	        e.preventDefault();
	        var year_txt = $('#year').val();
	        getTop(year_txt);
	    });

	});
</script>
<?php 
include '../template/footer.php'; 
	
?>