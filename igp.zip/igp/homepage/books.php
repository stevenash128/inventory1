<?php 
$layout_active = 'books';
$layout_header_txt = 'Books';
?>

<?php include '../template/header.php'; ?>

<div class="box box-primary">
	<div class="box-header">
    
	<div class="row">
		<div class="col-lg-4">
			<div class="input-group">
				<input id="search_txt" type="text" class="form-control" placeholder="Search Books">
				<div class="input-group-btn">
				    <button onclick="getBooks()" class="btn btn-primary btn-flat" id="search_btn"><span class="fa fa-search"></span></button>
				</div>
			</div>
		</div>
		<!-- <div class="col-lg-8">
            <span class="pull-right">
            <button type="button" id="addNewBook" class="btn btn-success btn-flat btn-sm"><i class="fa fa-plus"></i> Add New Book</button>
            </span>
        
        </div> -->
	</div>
	</div>
	<div class="box-body" style="min-height:400px;">

	<div class="table-responsive">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th width="10px">#</th>
                    <th>Barcode</th>
                    <th >Title</th>
                    <th >Description</th>
                    <th >Grade Level</th>
                    <th >Publisher</th>
                    <th>Supplier</th>
                    <th>Total No.</th>
                    <th>Sold Quantity</th>
                    <th>Stock on Hand</th>
                    <th>Company Price</th>
                    <th>LNU Price</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
        <tbody id="bookList"></tbody>
        </table>
    </div><!-- /.table-responsive -->

   	</div><!--./box-body-->
</div><!--./box-->


<div id="bookModal" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times</button>
                    <h4 class="modal-title">Title</h4>
                </div>
                <form id="myForm" action="" method="post" class="form-horizontal">
                <div class="modal-body">
                <small class="text-info"> <i class="fa fa-info-o"></i> Fields with asterisk(*) are required</small>
                <br><br>
                    <div class="row">
                         <input type="hidden" id="book_id">
            
			             <div class="col-lg-12">

                            <div class="form-group">
                              <label for="sup_id" class="col-sm-3 control-label">Select Supplier *</label>
                              <div class="col-sm-9">
                                <select id="sup_id" class="form-control"></select>
                              </div>
                            </div><!-- /.form-group -->

                            <div class="form-group">
                              <label for="barcode_no" class="col-sm-3 control-label">Barcode</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" id="barcode_no" placeholder="Barcode" >
                              </div>
                            </div><!-- /.form-group -->

			                <div class="form-group">
			                  <label for="title" class="col-sm-3 control-label">Title *</label>
			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" id="title" placeholder="Title" >
			                  </div>
			                </div><!-- /.form-group -->

			                <div class="form-group">
			                  <label for="description" class="col-sm-3 control-label">Description *</label>
			                  <div class="col-sm-9">
                                <textarea class="form-control" id="description" placeholder="Description" cols="30" rows="3"></textarea>
			                  </div>
			                </div><!-- /.form-group -->

                            <div class="form-group">
                              <label for="book_yr_lvl" class="col-sm-3 control-label">Year Level</label>
                              <div class="col-sm-9">
                                <select id="book_yr_lvl" class="form-control">
                                    <option value="">--select--</option>
                                    <option value="Grade 1">Grade 1</option>
                                    <option value="Grade 2">Grade 2</option>
                                    <option value="Grade 3">Grade 3</option>
                                    <option value="Grade 4">Grade 4</option>
                                    <option value="Grade 5">Grade 5</option>
                                    <option value="Grade 6">Grade 6</option>
                                    <option value="Grade 7">Grade 7</option>
                                    <option value="Grade 8">Grade 8</option>
                                    <option value="Grade 9">Grade 9</option>
                                    <option value="Grade 10">Grade 10</option>
                                    <option value="Grade 11">Grade 11</option>
                                    <option value="Grade 12">Grade 12</option>
                                    <option value="1st Year">1st Year</option>
                                    <option value="2nd Year">2nd Year</option>
                                    <option value="3rd Year">3rd Year</option>
                                    <option value="4th Year">4th Year</option>
                                </select>
                              </div>
                            </div><!-- /.form-group -->

                            <div class="form-group">
                              <label for="publisher" class="col-sm-3 control-label">Publisher *</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" id="publisher" placeholder="Publisher" >
                              </div>
                            </div><!-- /.form-group -->


                            <!-- <div class="form-group">
                              <label for="company_price" class="col-sm-3 control-label">Company Price</label>
                              <div class="col-sm-9">
                                <input type="number" class="form-control" id="company_price" placeholder="Company Price" >
                              </div>
                            </div>/.form-group
                            
                            <div class="form-group">
                              <label for="lnu_price" class="col-sm-3 control-label">LNU Price</label>
                              <div class="col-sm-9">
                                <input type="number" class="form-control" id="lnu_price" placeholder="LNU Price" >
                              </div>
                            </div>/.form-group -->

                            <div class="form-group">
                              <label for="status" class="col-sm-3 control-label">Status *</label>
                              <div class="col-sm-9">
                              <select id="status" class="form-control">
                                  <option value="used">Used</option>
                                  <option value="unused">Unused</option>
                              </select>
                              </div>
                            </div><!-- /.form-group -->

			              </div><!-- /.col-md-12 -->
			             </div> <!-- /.row-->
                </div><!-- /.body-->
                <div class="modal-footer">
	                  <button type="button" id="btnAction" onclick="" class="btn btn-primary btn-flat">Update</button>
		            <input class="btn btn-default btn-flat" data-dismiss="modal" type="reset" value="cancel" name="cancel"> 
		        </div><!--footer-->
	          </form>
            </div> 
        </div>
    </div>


<script>
/*var sup_id_val = '';
    $(function () {
     sup_id_val = parseInt('<?php if(isset($_GET['sup_id'])){echo $_GET['sup_id']; }else{echo '';} ?>');

    if(sup_id_val !='')
    {
        //$('#sup_id').val(sup_id_val);
        $('#sup_id').prop('disabled',true);
        $('#bookModal').modal('show');
    }
    else
    {
        $('#sup_id').val('');
        $('#sup_id').prop('disabled',false);
    }
    });*/

    

	$(document).on("click", "#addNewBook", function(event){
    
        event.preventDefault();
        $('#book_id').val('');
        $('#sup_id').val('');
        $('#title').val('');
        $('#description').val('');
        $('#book_yr_lvl').val('');
        //$('#company_price').val('');
        //$('#lnu_price').val('');
        $('#publisher').val('');
        $('#barcode_no').val('');
        $('#status').val('used');

        $('#myForm').attr('action', '../actions/insertNewBook.php');
        $('#bookModal').find('.modal-title').text('Add New Book');
        $('#btnAction').attr('onclick','insertNewBook()');
        $('#btnAction').text('Submit');
        $('#bookModal').modal('show');
    });


getBooks();

function getBooks()
{
	var search_txt = $('#search_txt').val();

    $.get({
        url: '../actions/getBooks.php?search_txt='+search_txt,
        dataType: 'json',
        success: function(data){
        	console.log(data);
            var html = "";
            var i;
            if(!data)
            {
                alert("Error: No data received");
            }
            else
            {
               
               var data_count = data.length;
                for(i = 0; i < data_count; i++) 
                {
                	var status_txt = '';
                	var stock_on_hand = parseInt(data[i].total_count) - parseInt(data[i].sold_qty);
                    if(isNaN(stock_on_hand)==true){
                        stock_on_hand = 0;
                    }

                    var cmprice = '0', lnPrice = '0';

                    if(data[i].company_price===null){
                        cmprice = '0';
                    }else{
                        cmprice = data[i].company_price;
                    }
                    if(data[i].lnu_price===null){
                        lnPrice = '0';
                    }else{
                        lnPrice = data[i].lnu_price;
                    }

                    console.log(data[i].company_price);

                	html += '<tr>'+
                                    '<td>'+ (i+1) +'</td>'+
                                    '<td>'+ data[i].barcode_no +'</td>'+
                                    '<td>'+ data[i].title +'</td>'+
                                    '<td>'+ data[i].description +'</td>'+
                                    '<td>'+ data[i].book_yr_lvl +'</td>'+
                                    '<td>'+ data[i].publisher +'</td>'+
                                    '<td>'+ data[i].supplier +'</td>'+
                                    '<td>'+ Number(data[i].total_count) +'</td>'+
                                    '<td>'+ Number(data[i].sold_qty) +'</td>'+
                                    '<td>'+ parseInt(stock_on_hand) +'</td>'+
                                    '<td>'+ cmprice +'</td>'+
                                    '<td>'+ lnPrice +'</td>'+
                                    '<td>'+ data[i].status +'</td>'+
                                    '<td>'+

                                    '<a href="#" class="editBook btn btn-primary btn-flat btn-xs " data-sup_id="'+data[i].sup_id+'" data-barcode_no="'+data[i].barcode_no+'" data-book_id="'+data[i].book_id+'" data-title="'+data[i].title+'" data-description="'+data[i].description+'" data-book_yr_lvl="'+data[i].book_yr_lvl+'" data-publisher="'+data[i].publisher+'" data-company_price="'+data[i].company_price+'" data-lnu_price="'+data[i].lnu_price+'"  data-status="'+data[i].status+'"    ><i class="fa fa-edit"></i> Edit</a>&nbsp;'+

                                    '</td>'+
                                '</tr>';
                }

                if(data_count==0)
                {
                    $('#bookList').html('<tr><td colspan="8">0 Record Found</td></tr>');
                }
                else
                {
                    $('#bookList').html(html);
                }
            }
        },
        error: function(data){
            console.log(data);
        }
        });
    }

    function insertNewBook()
    {
    	var url = $('#myForm').attr('action');
    	var result = '';

        var sup_id = $('#sup_id');
        var barcode_no = $('#barcode_no');
	    var title = $('#title');
	    var description = $('#description');
        var book_yr_lvl = $('#book_yr_lvl');
        var publisher = $('#publisher');
	    var company_price = $('#company_price');
        var lnu_price = $('#lnu_price');
        var status = $('#status');

	    var supVal = sup_id.val().replace(/\s{2,}/g,' ');
        var titleVal = title.val().replace(/\s{2,}/g,' ');
        var descriptionVal = description.val().replace(/\s{2,}/g,' ');
        var publisherVal = publisher.val().replace(/\s{2,}/g,' ');

        if(supVal == '' || supVal == ' '){
          sup_id.parent().addClass('has-error');
          sup_id.focus();
          return false;
        }else{
          sup_id.parent().removeClass('has-error');
        }

	    if(titleVal == '' || titleVal == ' '){
	      title.parent().addClass('has-error');
	      title.focus();
	      return false;
	    }else{
	      title.parent().removeClass('has-error');
	    }

	    if(descriptionVal == '' || descriptionVal == ' '){
	      description.parent().addClass('has-error');
	      description.focus();
	      return false;
	    }else{
	      description.parent().removeClass('has-error');
	    }

        if(book_yr_lvl == ''){
          book_yr_lvl.parent().addClass('has-error');
          book_yr_lvl.focus();
          return false;
        }else{
          book_yr_lvl.parent().removeClass('has-error');
        }

        if(publisherVal == '' || publisherVal == ' '){
          publisher.parent().addClass('has-error');
          publisher.focus();
          return false;
        }else{
          publisher.parent().removeClass('has-error');
        }

	    /*if(company_price.val() == ''){
	      company_price.parent().addClass('has-error');
	      company_price.focus();
	      return false;
	    }else{
	      company_price.parent().removeClass('has-error');
	    }

        if(lnu_price.val() == ''){
          lnu_price.parent().addClass('has-error');
          lnu_price.focus();
          return false;
        }else{
          lnu_price.parent().removeClass('has-error');
        }*/

        if(status.val() == ''){
          status.parent().addClass('has-error');
          status.focus();
          return false;
        }else{
          status.parent().removeClass('has-error');
        }

    
    var queryString = '?title='+title.val();
        queryString += '&description='+description.val();
        queryString += '&book_yr_lvl='+book_yr_lvl.val();
        queryString += '&publisher='+publisher.val();
        //queryString += '&company_price='+company_price.val();
        //queryString += '&lnu_price='+lnu_price.val();
        queryString += '&status='+status.val();
        queryString += '&barcode_no='+barcode_no.val();
        queryString += '&sup_id='+sup_id.val();

    
    $.ajax({
        type: 'ajax',
        method: 'get',
        url: url+queryString,
        dataType: 'json',
        success: function(response){
            if(response.msg==true)
            {
            	$('#bookModal').modal('hide');
              	getBooks();
            }
            else if(response.msg=='duplicate')
            {
            	alert('Duplicate Found!');
            }
            else
            {
              	alert('Unable to Add New Supplier');
            }
        },
        error: function(response){
          //alert('Error');
          console.log(response);
        }
      });
    }

    /*$(document).on("click", ".deactivate", function(event){
        event.preventDefault();

        var book_id = $(this).data("book_id");
        var name = $(this).data("name");
        var status = $(this).data("status");
        var strClear = '';

        var queryString = '?book_id='+book_id;
        	queryString += '&status='+status;

        	if(status == 'active'){
        		strClear = 'deactivate';
        	}else{
        		strClear = 'activate';
        	}

        var url = '../actions/deactivateSupplier.php';

        var conf = confirm("This will "+strClear+" "+name+", click OK to continue.");
        if(conf == true)
        {
            $.ajax({
            type: 'ajax',
            method: 'get',
            url: url+queryString,
            dataType: 'json',
            success: function(response){
                if(response.msg==true)
                {
                  getBooks();
                }
                else
                {
                  alert('Unable to deactivate supplier');
                }
            },
            error: function(response){
              alert('Error');
              console.log(response);
            }
          });
        }

    });*/

    $(document).on("click", ".editBook", function(event){
        event.preventDefault();

        var book_id = $(this).data("book_id");
        var title = $(this).data("title");
        var description = $(this).data("description");
        var book_yr_lvl = $(this).data("book_yr_lvl");
        var publisher = $(this).data("publisher");
        //var company_price = $(this).data("company_price");
        //var lnu_price = $(this).data("lnu_price");
        var status = $(this).data("status");
        var barcode_no = $(this).data("barcode_no");
        var sup_id = $(this).data("sup_id");

        $('#book_id').val(book_id);
        $('#title').val(title);
        $('#description').val(description);
        $('#book_yr_lvl').val(book_yr_lvl);
        $('#publisher').val(publisher);
        //$('#company_price').val(company_price);
        //$('#lnu_price').val(lnu_price);
        $('#status').val(status);
        $('#barcode_no').val(barcode_no);
        $('#sup_id').val(sup_id);

        $('#myForm').attr('action', '../actions/editBook.php');
        $('#bookModal').find('.modal-title').text('Edit '+ title);
        $('#btnAction').attr('onclick','updateBook()');
        $('#btnAction').text('Update');
        $('#bookModal').modal('show');

    });

    function updateBook()
    {
    	var url = $('#myForm').attr('action');

    	var book_id = $('#book_id');
        var title = $('#title');
        var description = $('#description');
        var book_yr_lvl = $('#book_yr_lvl');
        var publisher = $('#publisher');
        //var company_price = $('#company_price');
        //var lnu_price = $("#lnu_price");
        var status = $("#status");
        var barcode_no = $("#barcode_no");
        var sup_id = $("#sup_id");

        if(sup_id.val() == ''){
          sup_id.parent().addClass('has-error');
          sup_id.focus();
          return false;
        }else{
          sup_id.parent().removeClass('has-error');
        }

        if(title.val() == ''){
	      title.parent().addClass('has-error');
	      title.focus();
	      return false;
	    }else{
	      title.parent().removeClass('has-error');
	    }

	    if(description.val() == ''){
	      description.parent().addClass('has-error');
	      description.focus();
	      return false;
	    }else{
	      description.parent().removeClass('has-error');
	    }

        if(book_yr_lvl == ''){
          book_yr_lvl.parent().addClass('has-error');
          book_yr_lvl.focus();
          return false;
        }else{
          book_yr_lvl.parent().removeClass('has-error');
        }

        if(publisher.val() == ''){
          publisher.parent().addClass('has-error');
          publisher.focus();
          return false;
        }else{
          publisher.parent().removeClass('has-error');
        }

	    /*if(company_price.val() == ''){
	      company_price.parent().addClass('has-error');
	      company_price.focus();
	      return false;
	    }else{
	      company_price.parent().removeClass('has-error');
	    }

        if(lnu_price.val() == ''){
          lnu_price.parent().addClass('has-error');
          lnu_price.focus();
          return false;
        }else{
          lnu_price.parent().removeClass('has-error');
        }*/

        if(status.val() == ''){
          status.parent().addClass('has-error');
          status.focus();
          return false;
        }else{
          status.parent().removeClass('has-error');
        }

    	var queryString = '?book_id='+book_id.val();
        	queryString += '&title='+title.val();
        	queryString += '&description='+description.val();
            queryString += '&book_yr_lvl='+book_yr_lvl.val();
            queryString += '&publisher='+publisher.val();
        	//queryString += '&company_price='+company_price.val();
            //queryString += '&lnu_price='+lnu_price.val();
            queryString += '&status='+status.val();
            queryString += '&barcode_no='+barcode_no.val();
            queryString += '&sup_id='+sup_id.val();

    	$.ajax({
            type: 'ajax',
            method: 'get',
            url: url+queryString,
            dataType: 'json',
            success: function(response){
                if(response.msg==true)
                {
                  $('#bookModal').modal('hide');
                  getBooks();
                }
                else if(response.msg=='duplicate')
                {
                	alert('Duplicate found.');
                }
                else
                {
                  alert('Unable to update details');
                }
            },
            error: function(response){
              alert('Error');
              console.log(response);
            }
          });
    }

function getSuppliers()
{
    $.get({
        url: '../actions/getSuppliers.php',
        dataType: 'json',
        success: function(data){
            console.log(data);
            var html = '<option value="">--select supplier--</option>';
            var i;
            if(!data)
            {
                alert("Error: No data received");
            }
            else
            {
               
               var data_count = data.length;
                for(i = 0; i < data_count; i++) 
                {
                    var sldVal = '';
                    /*if(data[i].sup_id == sup_id_val)
                    {
                        sldVal = 'selected';
                    }else{
                        sldVal = '';
                    }*/
                    html += '<option value="'+data[i].sup_id+'" '+sldVal+'>'+data[i].name+'</option>';
                }

                if(data_count==0)
                {
                    $('#sup_id').html('<option value="">--no supplier found--</option>');
                }
                else
                {
                    $('#sup_id').html(html);
                }
            }
        },
        error: function(data){
            console.log(data);
        }
        });
    }

getSuppliers();
</script>

<?php include '../template/footer.php'; ?>