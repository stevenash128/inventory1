<?php 
$layout_active = 'per_publisher';
$layout_header_txt = 'Per Publisher';
?>

<?php include '../template/header.php'; ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="../plugins/datatables/dataTables.bootstrap.css">
    <link rel="stylesheet" href="../plugins/jQueryUI/smoothness-theme/jquery-ui-smoothness.css">
    <style>
        .filter-date { width: 110px; margin-bottom: 10px; }
        .ui-widget-shadow { display: none!important; }
        .dataTables_length { display: inline-block; margin-top: 5px; }
        .dataTables_filter { display: inline-block; margin-top: 5px; float: right; }
        .date-filter { width: 100%; height: 5px; text-align: right; }
    </style>

    <!-- Default box -->
    <div class="box">
        <div class="box-body">
            <table id="sales-inventory-table" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th class="text-center">#</th>
                        <th>ID#.</th>
                        <th>OR No.</th>
                        <th>Date</th>
                        <th>Barcode No.</th>
                        <th>Description</th>
                        <th>Quantity</th>
                        <th>Current Price</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                        
    <?php
    // Check connection
    include('../connection/config.php');

    $res1 = mysqli_query($mysqli,"SELECT DISTINCT publisher FROM tbl_books");
    while($row1 = mysqli_fetch_array($res1))
    { 
    ?>
    <tr>
        <td colspan="9"><?= $row1['publisher']; ?></td>
        <td class="hidden"></td>
        <td class="hidden"></td>
        <td class="hidden"></td>
        <td class="hidden"></td>
        <td class="hidden"></td>
        <td class="hidden"></td>
        <td class="hidden"></td>
        <td class="hidden"></td>
    </tr>

    <?php 
    $count = 0;
    $totalSale = 0;

     $sql="SELECT *,DATE_FORMAT(date_purchased,'%m-%d-%Y') AS date_purchased FROM tbl_book_purchases bp LEFT JOIN tbl_transactions t ON bp.trans_id = t.trans_id LEFT JOIN tbl_books b ON b.book_id = bp.book_id
     LEFT JOIN tbl_students s ON s.stud_id = t.stud_id
      WHERE publisher = '".$row1['publisher']."' ";

        $query=mysqli_query($mysqli,$sql)or die(mysqli_error($mysqli));
        $data=array();
        while($key=mysqli_fetch_array($query))
        {
            $totalSale += $key['purchase_qty'] * $key['price_sold'];
        ?>
            <tr>
                <td><?php $count++; echo $count; ?></td>
                <td><?=$key['stud_no']; ?></td>
                <td><?=$key['or_no']; ?></td>
                <td><?= $key['date_purchased']; ?></td>
                <td><?=$key['barcode_no']; ?></td>
                <td><?=$key['title']; ?></td>
                <td><?=$key['purchase_qty']; ?></td>
                <td> <?php echo  '&#8369; '.number_format($key['price_sold'],2); ?></td>
                <td><?=$key['or_status']; ?></td>
            </tr> 
        <?php
        }
        ?>
            <tr>
                <td colspan="7" class="text-right"><?= $row1['publisher']; ?>. Total:</td>
                <td class="hidden"></td>
                <td class="hidden"></td>
                <td class="hidden"></td>
                <td class="hidden"></td>
                <td class="hidden"></td>
                <td class="hidden"></td>
                <td><?= '&#8369; '.number_format($totalSale,2); ?></td>
                <td class="hidden"></td>
                <td class="hidden"></td>
            </tr>
        <?php


    }

   
    
    mysqli_close($mysqli);
    
    ?>
                </tbody>
            </table>
        <div class="row">
            <div class="col-sm-3 col-sm-offset-9">
            <h4 class=""></h4>
            </div>
        </div>
        </div>
        <!-- /.box-body -->
        <div class="box-footer">
            Footer
        </div>
        <!-- /.box-footer-->
    </div>
    <!-- /.box -->

    <!-- DataTables -->
    <script src="../plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="../plugins/datatables/dataTables.bootstrap.min.js"></script>
    <script src="../plugins/jQueryUI/jquery-ui.min.js"></script>
    <script src="../plugins/jQueryUI/buttons/api_sum().js"></script>

    <script src="../plugins/jQueryUI/buttons/dataTables.buttons.min.js"></script>
    <script src="../plugins/jQueryUI/buttons/buttons.flash.min.js"></script>
    <script src="../plugins/jQueryUI/buttons/jszip.min.js"></script>
    <script src="../plugins/jQueryUI/buttons/pdfmake.min.js"></script>
    <script src="../plugins/jQueryUI/buttons/vfs_fonts.js"></script>
    <script src="../plugins/jQueryUI/buttons/buttons.html5.min.js"></script>
    <script src="../plugins/jQueryUI/buttons/buttons.print.min.js"></script>

    <script>
        $(document).ready(function(){
            $("#sales-inventory-table").DataTable({
                "bSort": false,
                dom: 'Blfrtip',
                buttons: [
                    'excel', 'pdf', 'print'
                ],
            });
            
            $(".dt-button").addClass("btn btn-primary btn-sm").css("margin", "0px 5px 5px 0px");
            $(".buttons-excel").prepend("<i class='fa fa-file-excel-o'></i> ");
            $(".buttons-pdf").prepend("<i class='fa fa-file-pdf-o'></i> ");
            $(".buttons-print").prepend("<i class='fa fa-print'></i> ");
        });
    </script>

<?php include '../template/footer.php'; ?>