<?php 
$layout_active = 'studentsList';
$layout_header_txt = 'Students List';
?>

<?php include '../template/header.php'; ?>

<div class="box box-primary">
	<div class="box-header">
    
	<div class="row">
		<div class="col-lg-4">
			<div class="input-group">
				<input id="search_txt" type="text" class="form-control" placeholder="Search Student">
				<div class="input-group-btn">
				    <button onclick="getStudents()" class="btn btn-primary btn-flat" id="search_btn"><span class="fa fa-search"></span></button>
				</div>
			</div>
		</div>
	</div>
	</div>
	<div class="box-body" style="min-height:400px;">

	<div class="table-responsive">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th width="10px">#</th>
                    <th>Student No.</th>
                    <th >Name</th>
                    <th >Year Level</th>
                    <th>Status</th>
                    <th >&nbsp;</th>
                </tr>
            </thead>
        <tbody id="studentsList"></tbody>
        </table>
    </div><!-- /.table-responsive -->

   	</div><!--./box-body-->
</div><!--./box-->




<div id="studBooksModal" class="modal fade" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times</button>
                    <h4 class="modal-title">Title</h4>
                </div>
                <div class="modal-body">
                    <div id="first">
                   <table class="table">
                       <thead>
                           <tr style="background-color:#ddd;">
                               <th>#</th>
                               <th>O.R. NO</th>
                               <th>O.R. Status</th>
                               <th>Amount Payable</th>
                               <th>Sold By</th>
                               <th>Transaction Date</th>
                               <th>&nbsp;</th>
                           </tr>
                       </thead>
                       <tbody id="studTrasList"></tbody>
                   </table>
                   </div>

                   <div id="second" style="display:none;">
                   <button class="btn btn-sm btn-default" onclick="showFirst();">Back</button>
                   <br><br>
                    <table class="table">
                       <thead>
                           <tr style="background-color:#ddd;">
                               <th>#</th>
                               <th>Title</th>
                               <th>Description</th>
                               <th>Barcode No</th>
                               <th>Qty</th>
                               <th>Price</th>
                               <th></th>
                           </tr>
                       </thead>
                       <tbody id="bookPurchasesList"></tbody>
                   </table>
                   </div>
                </div><!-- /.body-->
                <div class="modal-footer">
                    <input class="btn btn-default btn-flat" data-dismiss="modal" type="reset" value="Close" name="cancel"> 
                </div><!--footer-->
            </div> 
        </div>
    </div>



<script>
    $(document).on("click", ".viewStudTransactions", function(event){
    
        event.preventDefault();
        var stud_no = $(this).data('stud_no');
        var stud_id = $(this).data('stud_id');
        var full_name = $(this).data('full_name');
        $('#studBooksModal').find('.modal-title').text(full_name+'\' Transactions');

        getStudTransactions(stud_id);
        showFirst();
        $('#studBooksModal').modal('show');

    });

    $(document).on("click", ".viewTransBooks", function(event){
    
        event.preventDefault();
        var trans_id = $(this).data('trans_id');
        
        showSecond();
        getTransBooks(trans_id);
    });

    function showFirst()
    {
        $('#first').fadeIn();
        $('#second').hide();
    }

    function showSecond()
    {
        $('#bookPurchasesList').html('');
        $('#second').fadeIn();
        $('#first').hide();
    }

    


getStudents();

function getStudents()
{
	var search_txt = $('#search_txt').val();

    $.get({
        url: '../actions/getStudents.php?search_txt='+search_txt,
        dataType: 'json',
        success: function(data){
        	console.log(data);
            var html = "";
            var i;
            if(!data)
            {
                alert("Error: No data received");
            }
            else
            {
               
               var data_count = data.length;
                for(i = 0; i < data_count; i++) 
                {
                	var status_txt = '';

                	html += '<tr>'+
                                    '<td>'+ (i+1) +'</td>'+
                                    '<td>'+ data[i].stud_no +'</td>'+
                                    '<td>'+ data[i].full_name +'</td>'+
                                    '<td>'+ data[i].yr_lvl +'</td>'+
                                    '<td>'+ data[i].stud_status +'</td>'+
                                    '<td>'+ '<a href="#" class="viewStudTransactions" data-stud_id="'+data[i].stud_id+'" data-stud_no="'+data[i].stud_no+'" data-full_name="'+data[i].full_name+'">View Book Transactions</a>'+'</td>'+
                                    '<td>'+
                                '</tr>';
                }

                if(data_count==0)
                {
                    $('#studentsList').html('<tr><td colspan="8">0 Record Found</td></tr>');
                }
                else
                {
                    $('#studentsList').html(html);
                }
            }
        },
        error: function(data){
            console.log(data);
        }
        });
    }

    
function getStudTransactions(stud_id)
{
    

    $.get({
        url: '../actions/getTransactions.php?stud_id='+stud_id,
        dataType: 'json',
        success: function(data){
            console.log(data);
            var html = "";
            var i;
            if(!data)
            {
                alert("Error: No data received");
            }
            else
            {
               
               var data_count = data.length;
                for(i = 0; i < data_count; i++) 
                {
                    var status_txt = '';

                    html += '<tr>'+
                                    '<td>'+ (i+1) +'</td>'+
                                    '<td>'+ data[i].or_no +'</td>'+
                                    '<td>'+ data[i].or_status +'</td>'+
                                    '<td>'+ data[i].amount_payable +'</td>'+
                                    '<td>'+ data[i].sold_by +'</td>'+
                                     '<td>'+ data[i].date_purchased +'</td>'+
                                     '<td>'+ 
                                     '<a href="#" class="viewTransBooks btn btn-primary btn-xs btn-flat" data-trans_id="'+data[i].trans_id+'"><i class="fa fa-eye"></i> View</a>&nbsp;&nbsp;&nbsp;'+
                                     '<a href="printReceipt.php?trans_id='+data[i].trans_id+'" target="_blank" class="btn btn-default btn-xs btn-flat" data-trans_id=""><i class="fa fa-print"></i> Print</a>'+
                                     '</td>'+
                                '</tr>';
                }

                if(data_count==0)
                {
                    $('#studTrasList').html('<tr><td colspan="8">0 Record Found</td></tr>');
                }
                else
                {
                    $('#studTrasList').html(html);
                }
            }
        },
        error: function(data){
            console.log(data);
        }
        });
    }


function getTransBooks(trans_id)
{
    $.get({
        url: '../actions/getBookPurchases.php?trans_id='+trans_id,
        dataType: 'json',
        success: function(data){
            console.log(data);
            var html = "";
            var i;
            if(!data)
            {
                alert("Error: No data received");
            }
            else
            {
               
               var data_count = data.length;
                for(i = 0; i < data_count; i++) 
                {
                    var status_txt = '';

                    html += '<tr>'+
                                    '<td>'+ (i+1) +'</td>'+
                                    '<td>'+ data[i].title +'</td>'+
                                    '<td>'+ data[i].description +'</td>'+
                                    '<td>'+ data[i].barcode_no +'</td>'+
                                    '<td>'+ data[i].purchase_qty +'</td>'+
                                     '<td>'+ data[i].price_sold +'</td>'+
                                    '<td>'+
                            '</tr>';
                }

                if(data_count==0)
                {
                    $('#bookPurchasesList').html('<tr><td colspan="8">0 Record Found</td></tr>');
                }
                else
                {
                    $('#bookPurchasesList').html(html);
                }
            }
        },
        error: function(data){
            console.log(data);
        }
        });
    }

</script>

<?php include '../template/footer.php'; ?>