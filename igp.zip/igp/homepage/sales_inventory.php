<?php 
$layout_active = 'sales_inventory';
$layout_header_txt = 'Sales Inventory';
?>

<?php include '../template/header.php'; ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="../plugins/datatables/dataTables.bootstrap.css">
    <link rel="stylesheet" href="../plugins/jQueryUI/smoothness-theme/jquery-ui-smoothness.css">
    <style>
        .filter-date { width: 110px; margin-bottom: 10px; }
        .ui-widget-shadow { display: none!important; }
        .dataTables_length { display: inline-block; margin-top: 5px; }
        .dataTables_filter { display: inline-block; margin-top: 5px; float: right; }
        .date-filter { width: 100%; height: 5px; text-align: right; }
    </style>

    <!-- Default box -->
    <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title">Sales Data Table</h3>
        </div>
        <div class="box-body">
            <div class="date-filter">
                Start Date: <input class="filter-date" type="text" id="dateStart" name="dateStart" size="30">
                End Date: <input class="filter-date" type="text" id="dateend" name="dateend" size="30">
            </div>
            <table id="sales-inventory-table" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th class="text-center">#</th>
                        <th>ID#.</th>
                        <th>OR No.</th>
                        <th>Date <small class="gray-me">(mm-dd-yyyy)</small></th>
                        <th>Barcode No.</th>
                        <th>Description</th>
                        <th>Quantity</th>
                        <th>Current Price</th>
                        <th>Status</th>
                        <th class="hidden">Total</th>
                    </tr>
                </thead>
                <tbody>
                        
    <?php
    // Check connection
    include('../connection/config.php');
        
    $sql="SELECT *,DATE_FORMAT(date_purchased,'%m-%d-%Y') AS date_purchased FROM tbl_book_purchases bp LEFT JOIN tbl_transactions t ON bp.trans_id = t.trans_id LEFT JOIN tbl_books b ON b.book_id = bp.book_id LEFT JOIN tbl_students s ON s.stud_id = t.stud_id";

        $query=mysqli_query($mysqli,$sql)or die(mysqli_error($mysqli));
        $data=array();
        while($row=mysqli_fetch_array($query))
        {
            $data[] = array('purchase_id' => $row['purchase_id'], 
                            'stud_id' => $row['stud_id'],
                            'stud_no' => $row['stud_no'],
                            'or_no' => $row['or_no'],
                            'or_status' => $row['or_status'],
                            'price_sold' => $row['price_sold'],
                            'purchase_qty' => $row['purchase_qty'],
                            'date_purchased' => $row['date_purchased'],
                            'barcode_no' => $row['barcode_no'],
                            'title' => $row['title']
                            );
        }
    
    mysqli_close($mysqli);
    $count = 0;
    $totalSale = 0;
    ?>
                    <?php foreach ($data as $key): ?>
                    <?php $totalSale += $key['purchase_qty'] * $key['price_sold']; ?>
                       <tr>
                            <td><?php $count++; echo $count; ?></td>
                            <td><?=$key['stud_no']; ?></td>
                            <td><?=$key['or_no']; ?></td>
                            <td><?= $key['date_purchased']; ?></td>
                            <td><?=$key['barcode_no']; ?></td>
                            <td><?=$key['title']; ?></td>
                            <td><?=$key['purchase_qty']; ?></td>
                            <td> <?php echo  '&#8369; '.number_format($key['price_sold'],2); ?></td>
                            <td><?=$key['or_status']; ?></td>
                            <td class="hidden"><?= $key['purchase_qty'] * $key['price_sold']; ?></td>
                        </tr> 
                    <?php endforeach ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="9" align="right"><span style="font-weight:bold;" id="totalSale">Total Sales: &#8369; <?= number_format($totalSale,2); ?></span></td>

                    </tr>
                </tfoot>
            </table>
		<div class="row">
		    <div class="col-sm-3 col-sm-offset-9">
			<h4 class=""></h4>
		    </div>
		</div>
        </div>
        <!-- /.box-body -->
        <div class="box-footer">
            Footer
        </div>
        <!-- /.box-footer-->
    </div>
    <!-- /.box -->

    <!-- DataTables -->
    <script src="../plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="../plugins/datatables/dataTables.bootstrap.min.js"></script>
    <script src="../plugins/jQueryUI/jquery-ui.min.js"></script>
    <script src="../plugins/jQueryUI/buttons/api_sum().js"></script>

    <script src="../plugins/jQueryUI/buttons/dataTables.buttons.min.js"></script>
    <script src="../plugins/jQueryUI/buttons/buttons.flash.min.js"></script>
    <script src="../plugins/jQueryUI/buttons/jszip.min.js"></script>
    <script src="../plugins/jQueryUI/buttons/pdfmake.min.js"></script>
    <script src="../plugins/jQueryUI/buttons/vfs_fonts.js"></script>
    <script src="../plugins/jQueryUI/buttons/buttons.html5.min.js"></script>
    <script src="../plugins/jQueryUI/buttons/buttons.print.min.js"></script>

    <script>
        $(function () {
            let oTable = $("#sales-inventory-table").DataTable({
                dom: 'Blfrtip',
                buttons: [
                    'excel', 'pdf', 'print'
                ],
            });

            let inv_total = 0;

            $.fn.dataTableExt.afnFiltering.push(
                function( oSettings, aData, iDataIndex ) {
                    var iFini = document.getElementById('dateStart').value;
                    var iFfin = document.getElementById('dateend').value;
                    var iStartDateCol = 3;
                    var iEndDateCol = 3;

                    iFini=iFini.substring(0,2) + iFini.substring(3,5) + iFini.substring(6,10);
                    iFfin=iFfin.substring(0,2) + iFfin.substring(3,5) + iFfin.substring(6,10);

                    var datofini=aData[iStartDateCol].substring(0,2) + aData[iStartDateCol].substring(3,5) + aData[iStartDateCol].substring(6,10);
                    var datoffin=aData[iEndDateCol].substring(0,2) + aData[iEndDateCol].substring(3,5) + aData[iEndDateCol].substring(6,10);

                    if ( iFini === "" && iFfin === "" )
                    {
                        inv_total += parseFloat(aData[9]);
                        return true;
                    }
                    else if ( iFini <= datofini && iFfin === "")
                    {
                        inv_total += parseFloat(aData[9]);
                        return true;
                    }
                    else if ( iFfin >= datoffin && iFini === "")
                    {
                        inv_total += parseFloat(aData[9]);
                        return true;
                    }
                    else if (iFini <= datofini && iFfin >= datoffin)
                    {
                        inv_total += parseFloat(aData[9]);
                        return true;
                    }
                    return false;
                }
            );

            $('#dateStart, #dateend').datepicker({
            dateFormat: 'mm/dd/yy',
            arrows: true
            });

            /* Add event listeners to the two range filtering inputs */
            $('#dateStart').keyup( function() { inv_total = 0; oTable.draw(); setTotalSales( inv_total ); } );
            $('#dateend').keyup( function() { inv_total = 0; oTable.draw(); setTotalSales( inv_total ); } );

            /* Add event listeners to the two range filtering inputs */
            $('#dateStart').change( function() { inv_total = 0; oTable.draw(); setTotalSales( inv_total ); } );
            $('#dateend').change( function() { inv_total = 0; oTable.draw(); setTotalSales( inv_total ); } );

            /* Add event listeners to the two range filtering inputs */
            $('#name').keyup( function() { inv_total = 0; oTable.draw(); setTotalSales( inv_total ); } );
            $('#name').change( function() { inv_total = 0; oTable.draw(); setTotalSales( inv_total ); } );
            setTotalSales( oTable.column(9).data().sum() );
            

             $(".dt-button").addClass("btn btn-primary btn-sm").css("margin", "0px 5px 5px 0px");
        $(".buttons-excel").prepend("<i class='fa fa-file-excel-o'></i> ");
        $(".buttons-pdf").prepend("<i class='fa fa-file-pdf-o'></i> ");
        $(".buttons-print").prepend("<i class='fa fa-print'></i> ");
        });
        function setTotalSales(sum){
            $("#totalSale").html("Total Sales: " + sum );
        }

       
    </script>

<?php include '../template/footer.php'; ?>