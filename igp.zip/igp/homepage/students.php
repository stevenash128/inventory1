<?php 
$layout_active = 'students';
$layout_header_txt = 'Students';
?>

<?php include '../template/header.php'; ?>

<div class="box box-primary">
	<div class="box-header">
    
	<div class="row">
		<div class="col-lg-4">
			<div class="input-group">
				<input id="search_txt" type="text" class="form-control" placeholder="Search Student">
				<div class="input-group-btn">
				    <button onclick="getStudents()" class="btn btn-primary btn-flat" id="search_btn"><span class="fa fa-search"></span></button>
				</div>
			</div>
		</div>
		<div class="col-lg-8">
			<span class="pull-right">
			<button type="button" id="addNewStudent" class="btn btn-success btn-flat btn-sm"><i class="fa fa-plus"></i> Add New Student</button>
			</span>

		</div>
	</div>
	</div>
	<div class="box-body" style="min-height:400px;">

	<div class="table-responsive">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th width="10px">#</th>
                    <th>Student No.</th>
                    <th >Name</th>
                    <th >Year Level</th>
                    <th>Status</th>
                    <th >&nbsp;</th>
                    <th>Action</th>
                </tr>
            </thead>
        <tbody id="supplierList"></tbody>
        </table>
    </div><!-- /.table-responsive -->

   	</div><!--./box-body-->
</div><!--./box-->


<div id="studentModal" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times</button>
                    <h4 class="modal-title">Title</h4>
                </div>
                <form id="myForm" action="" method="post" class="form-horizontal">
                <div class="modal-body">
                    <p class="text-danger pull-right">Fields with (*) are required</p>
                    <div class="row">
                         <input type="hidden" id="stud_id">
            
			             <div class="col-lg-12">
                            <div class="form-group">
                              <label for="stud_no" class="col-sm-3 control-label">Student Number *</label>
                              <div class="col-sm-9">
                                <input type="number" class="form-control" id="stud_no" placeholder="Student Number" >
                              </div>
                            </div><!-- /.form-group -->

                            <div class="form-group">
                              <label for="fname" class="col-sm-3 control-label">First Name *</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" id="fname" placeholder="First Name" >
                              </div>
                            </div><!-- /.form-group -->

			                <div class="form-group">
			                  <label for="mname" class="col-sm-3 control-label">Middle Name</label>
			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" id="mname" placeholder="Middle Name" >
			                  </div>
			                </div><!-- /.form-group -->

			                <div class="form-group">
			                  <label for="lname" class="col-sm-3 control-label">Last Name *</label>
			                  <div class="col-sm-9">
                                <input type="text" class="form-control" id="lname" placeholder="Last Name">
			                  </div>
			                </div><!-- /.form-group -->

                            <div class="form-group">
                              <label for="ext" class="col-sm-3 control-label">Name Extension</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" id="ext" placeholder="Name Extension">
                              </div>
                            </div><!-- /.form-group -->

                            <div class="form-group">
                              <label for="yr_lvl" class="col-sm-3 control-label">Year Level *</label>
                              <div class="col-sm-9">
                                <select id="yr_lvl" class="form-control">
                                    <option value="">--select--</option>
                                    <option value="Grade 1">Grade 1</option>
                                    <option value="Grade 2">Grade 2</option>
                                    <option value="Grade 3">Grade 3</option>
                                    <option value="Grade 4">Grade 4</option>
                                    <option value="Grade 5">Grade 5</option>
                                    <option value="Grade 6">Grade 6</option>
                                    <option value="Grade 7">Grade 7</option>
                                    <option value="Grade 8">Grade 8</option>
                                    <option value="Grade 9">Grade 9</option>
                                    <option value="Grade 10">Grade 10</option>
                                    <option value="Grade 11">Grade 11</option>
                                    <option value="Grade 12">Grade 12</option>
                                    <option value="1st Year">1st Year</option>
                                    <option value="2nd Year">2nd Year</option>
                                    <option value="3rd Year">3rd Year</option>
                                    <option value="4th Year">4th Year</option>
                                </select>
                              </div>
                            </div><!-- /.form-group -->

                            <div class="form-group">
                              <label for="stud_status" class="col-sm-3 control-label">Status *</label>
                              <div class="col-sm-9">
                              <select id="stud_status" class="form-control">
                                  <option value="active">Active</option>
                                  <option value="inactive">Inactive</option>
                              </select>
                              </div>
                            </div><!-- /.form-group -->

			              </div><!-- /.col-md-12 -->
			             </div> <!-- /.row-->
                </div><!-- /.body-->
                <div class="modal-footer">
	                  <button type="button" id="btnAction" onclick="" class="btn btn-primary btn-flat">Update</button>
		            <input class="btn btn-default btn-flat" data-dismiss="modal" type="reset" value="cancel" name="cancel"> 
		        </div><!--footer-->
	          </form>
            </div> 
        </div>
    </div>



<div id="studBooksModal" class="modal fade" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times</button>
                    <h4 class="modal-title">Title</h4>
                </div>
                <div class="modal-body">
                    <div id="first">
                   <table class="table">
                       <thead>
                           <tr style="background-color:#ddd;">
                               <th>#</th>
                               <th>O.R. NO</th>
                               <th>O.R. Status</th>
                               <th>Amount Payable</th>
                               <th>Sold By</th>
                               <th>Transaction Date</th>
                               <th>&nbsp;</th>
                           </tr>
                       </thead>
                       <tbody id="studTrasList"></tbody>
                   </table>
                   </div>

                   <div id="second" style="display:none;">
                   <button class="btn btn-sm btn-default" onclick="showFirst();">Back</button>
                   <br><br>
                    <table class="table">
                       <thead>
                           <tr style="background-color:#ddd;">
                               <th>#</th>
                               <th>Title</th>
                               <th>Description</th>
                               <th>Barcode No</th>
                               <th>Qty</th>
                               <th>Price</th>
                               <th></th>
                           </tr>
                       </thead>
                       <tbody id="bookPurchasesList"></tbody>
                   </table>
                   </div>
                </div><!-- /.body-->
                <div class="modal-footer">
                    <input class="btn btn-default btn-flat" data-dismiss="modal" type="reset" value="Close" name="cancel"> 
                </div><!--footer-->
            </div> 
        </div>
    </div>



<script>
	$(document).on("click", "#addNewStudent", function(event){
    
        event.preventDefault();
        $('#stud_no').val('');
        $('#fname').val('');
        $('#lname').val('');
        $('#mname').val('');
        $('#stud_status').val('active');
        $('#yr_lvl').val('');
        $('#ext').val('');

        $('#myForm').attr('action', '../actions/insertNewStudent.php');
        $('#studentModal').find('.modal-title').text('Add New Student');
        $('#btnAction').attr('onclick','insertNewStudent()');
        $('#btnAction').text('Submit');
        $('#studentModal').modal('show');
    });

    $(document).on("click", ".viewStudTransactions", function(event){
    
        event.preventDefault();
        var stud_no = $(this).data('stud_no');
        var stud_id = $(this).data('stud_id');
        var full_name = $(this).data('full_name');
        $('#studBooksModal').find('.modal-title').text(full_name+'\' Transactions');

        getStudTransactions(stud_id);
        showFirst();
        $('#studBooksModal').modal('show');

    });

    $(document).on("click", ".viewTransBooks", function(event){
    
        event.preventDefault();
        var trans_id = $(this).data('trans_id');
        
        showSecond();
        getTransBooks(trans_id);
    });

    function showFirst()
    {
        $('#first').fadeIn();
        $('#second').hide();
    }

    function showSecond()
    {
        $('#bookPurchasesList').html('');
        $('#second').fadeIn();
        $('#first').hide();
    }

    


getStudents();

function getStudents()
{
	var search_txt = $('#search_txt').val();

    $.get({
        url: '../actions/getStudents.php?search_txt='+search_txt,
        dataType: 'json',
        success: function(data){
        	console.log(data);
            var html = "";
            var i;
            if(!data)
            {
                alert("Error: No data received");
            }
            else
            {
               
               var data_count = data.length;
                for(i = 0; i < data_count; i++) 
                {
                	var status_txt = '';

                	html += '<tr>'+
                                    '<td>'+ (i+1) +'</td>'+
                                    '<td>'+ data[i].stud_no +'</td>'+
                                    '<td>'+ data[i].full_name +'</td>'+
                                    '<td>'+ data[i].yr_lvl +'</td>'+
                                    '<td>'+ data[i].stud_status +'</td>'+
                                    '<td>'+ '<a href="#" class="viewStudTransactions" data-stud_id="'+data[i].stud_id+'" data-stud_no="'+data[i].stud_no+'" data-full_name="'+data[i].full_name+'">View Book Transactions</a>'+'</td>'+
                                    '<td>'+

                                    '<a href="#" class="editStudent btn btn-primary btn-flat btn-xs " data-stud_id="'+data[i].stud_id+'" data-stud_no="'+data[i].stud_no+'" data-ext="'+data[i].ext+'" data-fname="'+data[i].fname+'" data-mname="'+data[i].mname+'" data-lname="'+data[i].lname+'" data-yr_lvl="'+data[i].yr_lvl+'" data-stud_status="'+data[i].stud_status+'"    ><i class="fa fa-edit"></i> Edit</a>&nbsp;'+

                                    '</td>'+
                                '</tr>';
                }

                if(data_count==0)
                {
                    $('#supplierList').html('<tr><td colspan="8">0 Record Found</td></tr>');
                }
                else
                {
                    $('#supplierList').html(html);
                }
            }
        },
        error: function(data){
            console.log(data);
        }
        });
    }

    function insertNewStudent()
    {
    	var url = $('#myForm').attr('action');
    	var result = '';

        var stud_no = $('#stud_no');
	    var fname = $('#fname');
	    var lname = $('#lname');
	    var mname = $('#mname');
        var ext = $('#ext');
        var stud_status = $('#stud_status');
        var yr_lvl = $('#yr_lvl');
	    

	    if(stud_no.val() == ''){
	      stud_no.parent().addClass('has-error');
	      stud_no.focus();
	      return false;
	    }else{
	      stud_no.parent().removeClass('has-error');
	    }

	    if(fname.val() == ''){
	      fname.parent().addClass('has-error');
	      fname.focus();
	      return false;
	    }else{
	      fname.parent().removeClass('has-error');
	    }

	    /*if(mname.val() == ''){
	      mname.parent().addClass('has-error');
	      mname.focus();
	      return false;
	    }else{
	      mname.parent().removeClass('has-error');
	    }*/

        if(lname.val() == ''){
          lname.parent().addClass('has-error');
          lname.focus();
          return false;
        }else{
          lname.parent().removeClass('has-error');
        }

        if(yr_lvl.val() == ''){
          yr_lvl.parent().addClass('has-error');
          yr_lvl.focus();
          return false;
        }else{
          yr_lvl.parent().removeClass('has-error');
        }

        if(stud_status.val() == ''){
          stud_status.parent().addClass('has-error');
          stud_status.focus();
          return false;
        }else{
          stud_status.parent().removeClass('has-error');
        }

    
    var queryString = '?fname='+fname.val();
        queryString += '&mname='+mname.val();
        queryString += '&lname='+lname.val();
        queryString += '&stud_no='+stud_no.val();
        queryString += '&ext='+ext.val();
        queryString += '&yr_lvl='+yr_lvl.val();
        queryString += '&stud_status='+stud_status.val();

    
    $.ajax({
        type: 'ajax',
        method: 'get',
        url: url+queryString,
        dataType: 'json',
        success: function(response){
            if(response.msg==true)
            {
            	$('#studentModal').modal('hide');
              	getStudents();
            }
            else if(response.msg=='duplicate')
            {
            	alert('Duplicate Found!');
            }
            else
            {
              	alert('Unable to Add New Supplier');
            }
        },
        error: function(response){
          //alert('Error');
          console.log(response);
        }
      });
    }

    

    $(document).on("click", ".editStudent", function(event){
        event.preventDefault();

        var stud_id = $(this).data("stud_id");
        var stud_no = $(this).data("stud_no");
        var fname = $(this).data("fname");
        var lname = $(this).data("lname");
        var mname = $(this).data("mname");
        var ext = $(this).data("ext");
        var yr_lvl = $(this).data("yr_lvl");
        var stud_status = $(this).data("stud_status");

        $('#stud_id').val(stud_id);
        $('#stud_no').val(stud_no);
        $('#fname').val(fname);
        $('#lname').val(lname);
        $('#mname').val(mname);
        $('#ext').val(ext);
        $('#yr_lvl').val(yr_lvl);
        $('#stud_status').val(stud_status);

        $('#myForm').attr('action', '../actions/editStudent.php');
        $('#studentModal').find('.modal-title').text('Edit '+ fname);
        $('#btnAction').attr('onclick','updateStudent()');
        $('#btnAction').text('Update');
        $('#studentModal').modal('show');

    });

    function updateStudent()
    {
    	var url = $('#myForm').attr('action');

    	var stud_id = $('#stud_id');
        var stud_no = $('#stud_no');
        var fname = $('#fname');
        var lname = $('#lname');
        var mname = $('#mname');
        var ext = $("#ext");
        var yr_lvl = $("#yr_lvl");
        var stud_status = $("#stud_status");

        if(stud_no.val() == ''){
	      stud_no.parent().addClass('has-error');
	      stud_no.focus();
	      return false;
	    }else{
	      stud_no.parent().removeClass('has-error');
	    }

        if(fname.val() == ''){
          fname.parent().addClass('has-error');
          fname.focus();
          return false;
        }else{
          fname.parent().removeClass('has-error');
        }

	    if(mname.val() == ''){
	      mname.parent().addClass('has-error');
	      mname.focus();
	      return false;
	    }else{
	      mname.parent().removeClass('has-error');
	    }

	    if(lname.val() == ''){
	      lname.parent().addClass('has-error');
	      lname.focus();
	      return false;
	    }else{
	      lname.parent().removeClass('has-error');
	    }

        if(yr_lvl.val() == ''){
          yr_lvl.parent().addClass('has-error');
          yr_lvl.focus();
          return false;
        }else{
          yr_lvl.parent().removeClass('has-error');
        }

        if(stud_status.val() == ''){
          stud_status.parent().addClass('has-error');
          stud_status.focus();
          return false;
        }else{
          stud_status.parent().removeClass('has-error');
        }

    	var queryString = '?fname='+fname.val();
            queryString += '&mname='+mname.val();
            queryString += '&lname='+lname.val();
            queryString += '&stud_no='+stud_no.val();
            queryString += '&ext='+ext.val();
            queryString += '&yr_lvl='+yr_lvl.val();
            queryString += '&stud_status='+stud_status.val();
            queryString += '&stud_id='+stud_id.val();

    	$.ajax({
            type: 'ajax',
            method: 'get',
            url: url+queryString,
            dataType: 'json',
            success: function(response){
                if(response.msg==true)
                {
                  $('#studentModal').modal('hide');
                  getStudents();
                }
                else if(response.msg=='duplicate')
                {
                	alert('Duplicate found.');
                }
                else
                {
                  alert('Unable to update details');
                }
            },
            error: function(response){
              alert('Error');
              console.log(response);
            }
          });
    }

function getStudTransactions(stud_id)
{
    

    $.get({
        url: '../actions/getTransactions.php?stud_id='+stud_id,
        dataType: 'json',
        success: function(data){
            console.log(data);
            var html = "";
            var i;
            if(!data)
            {
                alert("Error: No data received");
            }
            else
            {
               
               var data_count = data.length;
                for(i = 0; i < data_count; i++) 
                {
                    var status_txt = '';

                    html += '<tr>'+
                                    '<td>'+ (i+1) +'</td>'+
                                    '<td>'+ data[i].or_no +'</td>'+
                                    '<td>'+ data[i].or_status +'</td>'+
                                    '<td>'+ data[i].amount_payable +'</td>'+
                                    '<td>'+ data[i].sold_by +'</td>'+
                                     '<td>'+ data[i].date_purchased +'</td>'+
                                     '<td>'+ '<a href="#" class="viewTransBooks" data-trans_id="'+data[i].trans_id+'">View Books</a>'+'</td>'+
                                '</tr>';
                }

                if(data_count==0)
                {
                    $('#studTrasList').html('<tr><td colspan="8">0 Record Found</td></tr>');
                }
                else
                {
                    $('#studTrasList').html(html);
                }
            }
        },
        error: function(data){
            console.log(data);
        }
        });
    }


function getTransBooks(trans_id)
{
    $.get({
        url: '../actions/getBookPurchases.php?trans_id='+trans_id,
        dataType: 'json',
        success: function(data){
            console.log(data);
            var html = "";
            var i;
            if(!data)
            {
                alert("Error: No data received");
            }
            else
            {
               
               var data_count = data.length;
                for(i = 0; i < data_count; i++) 
                {
                    var status_txt = '';

                    html += '<tr>'+
                                    '<td>'+ (i+1) +'</td>'+
                                    '<td>'+ data[i].title +'</td>'+
                                    '<td>'+ data[i].description +'</td>'+
                                    '<td>'+ data[i].barcode_no +'</td>'+
                                    '<td>'+ data[i].purchase_qty +'</td>'+
                                     '<td>'+ data[i].price_sold +'</td>'+
                                    '<td>'+
                            '</tr>';
                }

                if(data_count==0)
                {
                    $('#bookPurchasesList').html('<tr><td colspan="8">0 Record Found</td></tr>');
                }
                else
                {
                    $('#bookPurchasesList').html(html);
                }
            }
        },
        error: function(data){
            console.log(data);
        }
        });
    }

</script>

<?php include '../template/footer.php'; ?>