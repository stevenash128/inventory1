<?php 
$layout_active = 'suppliers';
$layout_header_txt = 'Suppliers';
?>

<?php include '../template/header.php'; ?>

<div class="box box-primary">
	<div class="box-header">
    
	<div class="row">
		<div class="col-lg-4">
			<div class="input-group">
				<input id="search_txt" type="text" class="form-control" placeholder="Search Suppliers">
				<div class="input-group-btn">
				    <button onclick="getSuppliers()" class="btn btn-primary btn-flat" id="search_btn"><span class="fa fa-search"></span></button>
				</div>
			</div>
		</div>
		<div class="col-lg-8">
			<span class="pull-right">
			<button type="button" id="addNewSupplier" class="btn btn-success btn-flat btn-sm"><i class="fa fa-plus"></i> Add New Supplier</button>
			</span>

		</div>
	</div>
	</div>
	<div class="box-body" style="min-height:400px;">

	<div class="table-responsive">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th width="10px">#</th>
                    <th >Name</th>
                    <th >Company No</th>
                    <th>Address</th>
                    <th>Contact No</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
        <tbody id="supplierList"></tbody>
        </table>
    </div><!-- /.table-responsive -->

   	</div><!--./box-body-->
</div><!--./box-->


<div id="supModal" class="modal fade" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times</button>
                    <h4 class="modal-title">Title</h4>
                </div>
                <form id="myForm" action="" method="post" class="form-horizontal">
                <div class="modal-body">
                    <div class="row">
                         <input type="hidden" id="sup_id">
            
			             <div class="col-lg-12">
			                <div class="form-group">
			                  <label for="name" class="col-sm-3 control-label">Name</label>
			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" id="name" name="name" placeholder="Enter Supplier Name" >
			                  </div>
			                </div><!-- /.form-group -->

			                <div class="form-group">
			                  <label for="address" class="col-sm-3 control-label">Address</label>
			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" id="address" placeholder="Address">
			                  </div>
			                </div><!-- /.form-group -->

                            <div class="form-group">
                              <label for="company_no" class="col-sm-3 control-label">Company No</label>
                              <div class="col-sm-9">
                                <input type="number" class="form-control" id="company_no" placeholder="Company No" >
                              </div>
                            </div><!-- /.form-group -->

			              </div><!-- /.col-md-12 -->
			             </div> <!-- /.row-->
                </div><!-- /.body-->
                <div class="modal-footer">
	                  <button type="button" id="btnAction" onclick="" class="btn btn-primary btn-flat">Update</button>
		            <input class="btn btn-default btn-flat" data-dismiss="modal" type="reset" value="cancel" name="cancel"> 
		        </div><!--footer-->
	          </form>
            </div> 
        </div>
    </div>


<script>
	$(document).on("click", "#addNewSupplier", function(event){
    
        event.preventDefault();
        $('#sup_id').val('');
        $('#name').val('');
        $('#address').val('');
        $('#company_no').val('');

        $('#myForm').attr('action', '../actions/insertNewSuppliers.php');
        $('#supModal').find('.modal-title').text('Add New Supplier');
        $('#btnAction').attr('onclick','insertNewSuppliers()');
        $('#btnAction').text('Submit');
        $('#supModal').modal('show');
    });


getSuppliers();

function getSuppliers()
{
	var search_txt = $('#search_txt').val();

    $.get({
        url: '../actions/getSuppliers.php?search_txt='+search_txt,
        dataType: 'json',
        success: function(data){
        	console.log(data);
            var html = "";
            var i;
            if(!data)
            {
                alert("Error: No data received");
            }
            else
            {
               
               var data_count = data.length;
                for(i = 0; i < data_count; i++) 
                {
                	var status_txt = '';
                	if(data[i].status=='active')
                	{
                		status_txt = 'Deactivate';
                	}
                	else
                	{
                		status_txt = 'Activate';
                	}

                	html += '<tr>'+
                                    '<td>'+ (i+1) +'</td>'+
                                    '<td>'+ data[i].name +'</td>'+
                                    '<td>'+ data[i].company_no +'</td>'+
                                    '<td>'+ data[i].address +'</td>'+
                                    '<td>'+ data[i].contact_no +'</td>'+
                                    '<td>'+ data[i].status +'</td>'+
                                    '<td>'+

                                    '<a href="#" class="editSupplier btn btn-primary btn-flat btn-xs " data-sup_id="'+data[i].sup_id+'" data-name="'+data[i].name+'" data-company_no="'+data[i].company_no+'" data-address="'+data[i].address+'"    ><i class="fa fa-edit"></i> Edit</a>&nbsp;'+

                                    '<a class="deactivate btn btn-default btn-flat btn-xs" data-sup_id="'+data[i].sup_id+'" data-name="'+data[i].name+'" data-status="'+data[i].status+'" href="#"><i class="fa fa-cog"></i> '+status_txt+'</a>'+

                                    '</td>'+
                                '</tr>';
                }

                if(data_count==0)
                {
                    $('#supplierList').html('<tr><td colspan="8">0 Record Found</td></tr>');
                }
                else
                {
                    $('#supplierList').html(html);
                }
            }
        },
        error: function(data){
            console.log(data);
        }
        });
    }

    function insertNewSuppliers()
    {
    	var url = $('#myForm').attr('action');
    	var result = '';
    
	    var name = $('#name');
	    var address = $('#address');
	    var company_no = $('#company_no');
	    

	    if(name.val() == ''){
	      name.parent().addClass('has-error');
	      name.focus();
	      return false;
	    }else{
	      name.parent().removeClass('has-error');
	    }

	    if(address.val() == ''){
	      address.parent().addClass('has-error');
	      address.focus();
	      return false;
	    }else{
	      address.parent().removeClass('has-error');
	    }

	    if(company_no.val() == ''){
	      company_no.parent().addClass('has-error');
	      company_no.focus();
	      return false;
	    }else{
	      company_no.parent().removeClass('has-error');
	    }

    
    
    var queryString = '?name='+name.val();
        queryString += '&company_no='+company_no.val();
        queryString += '&address='+address.val();

    

    $.ajax({
        type: 'ajax',
        method: 'get',
        url: url+queryString,
        dataType: 'json',
        success: function(response){
            if(response.msg==true)
            {
            	$('#supModal').modal('hide');
              	getSuppliers();
                showMsg('New supplier added');
            }
            else if(response.msg=='duplicate')
            {
            	alert('Duplicate Found!');
            }
            else
            {
              	alert('Unable to Add New Supplier');
            }
        },
        error: function(response){
          //alert('Error');
          console.log(response);
        }
      });
    }

    $(document).on("click", ".deactivate", function(event){
        event.preventDefault();

        var sup_id = $(this).data("sup_id");
        var name = $(this).data("name");
        var status = $(this).data("status");
        var strClear = '';

        var queryString = '?sup_id='+sup_id;
        	queryString += '&status='+status;

        	if(status == 'active'){
        		strClear = 'deactivate';
        	}else{
        		strClear = 'activate';
        	}

        var url = '../actions/deactivateSupplier.php';

        var conf = confirm("This will "+strClear+" "+name+", click OK to continue.");
        if(conf == true)
        {
            $.ajax({
            type: 'ajax',
            method: 'get',
            url: url+queryString,
            dataType: 'json',
            success: function(response){
                if(response.msg==true)
                {
                  getSuppliers();
                }
                else
                {
                  alert('Unable to deactivate supplier');
                }
            },
            error: function(response){
              alert('Error');
              console.log(response);
            }
          });
        }

    });

    $(document).on("click", ".editSupplier", function(event){
        event.preventDefault();

        var sup_id = $(this).data("sup_id");
        var name = $(this).data("name");
        var address = $(this).data("address");
        var company_no = $(this).data("company_no");

        $('#sup_id').val(sup_id);
        $('#name').val(name);
        $('#address').val(address);
        $('#company_no').val(company_no);

        $('#myForm').attr('action', '../actions/editSupplier.php');
        $('#supModal').find('.modal-title').text('Edit '+ name);
        $('#btnAction').attr('onclick','updateSupplier()');
        $('#btnAction').text('Update');
        $('#supModal').modal('show');

    });

    function updateSupplier()
    {
    	var url = $('#myForm').attr('action');

    	var sup_id = $('#sup_id');
        var name = $('#name');
        var address = $('#address');
        var company_no = $('#company_no');

        if(name.val() == ''){
	      name.parent().addClass('has-error');
	      name.focus();
	      return false;
	    }else{
	      name.parent().removeClass('has-error');
	    }

	    if(address.val() == ''){
	      address.parent().addClass('has-error');
	      address.focus();
	      return false;
	    }else{
	      address.parent().removeClass('has-error');
	    }

	    if(company_no.val() == ''){
	      company_no.parent().addClass('has-error');
	      company_no.focus();
	      return false;
	    }else{
	      company_no.parent().removeClass('has-error');
	    }

    	var queryString = '?sup_id='+sup_id.val();
        	queryString += '&name='+name.val();
        	queryString += '&address='+address.val();
        	queryString += '&company_no='+company_no.val();

    	$.ajax({
            type: 'ajax',
            method: 'get',
            url: url+queryString,
            dataType: 'json',
            success: function(response){
                if(response.msg==true)
                {
                  $('#supModal').modal('hide');
                  getSuppliers();
                }
                else if(response.msg=='duplicate')
                {
                	alert('Duplicate found.');
                }
                else
                {
                  alert('Unable to update details');
                }
            },
            error: function(response){
              alert('Error');
              console.log(response);
            }
          });
    }
</script>

<?php include '../template/footer.php'; ?>