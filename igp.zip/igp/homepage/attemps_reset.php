<?php
include '../connection/config.php';

if(isset($_GET['user_id'])){
	$user_id = $_GET['user_id'];
	if(mysqli_query($mysqli, "DELETE FROM login_attempts WHERE user_id='$user_id'")){
		echo '<td >Successfull Reset</td>';
	}

}

mysqli_close($mysqli);
?>