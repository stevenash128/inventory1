<?php 
$layout_active = 'logs';
$layout_header_txt = 'Activity Logs';

// Check connection
    include('../connection/config.php');

$where = '';
if(isset($_COOKIE['user_type']))
{
      if($_COOKIE['user_type']=='rel_personnel')
      {
        $where = " WHERE method = 'inserted_book' ";
      }
}
if(isset($_GET['id'])){
      
      $where = " WHERE l.id = ".$_GET['id'];
}

$sql="SELECT l.id AS id, l.to_id AS to_id, l.details AS details, l.method AS method, l.insert_time AS insert_time, CONCAT(u.fname,' ', u.lname) AS user_name FROM tbl_logs l LEFT JOIN tbl_users u ON u.id = l.user_id ".$where." ORDER BY id DESC";

$query=mysqli_query($mysqli,$sql)or die(mysqli_error($mysqli));

?>

<?php include '../template/header.php'; ?>

    <!-- Default box -->
    <div class="">
        <!-- <div class="box-header with-border">
            <h3 class="box-title">Books Data</h3>
        </div> -->
        <div class="">
        <?php if (isset($_GET['id'])): ?>
          <a class="" href="logs.php">View All</a>
          <br><br>
        <?php endif ?>
            <!-- <div class="date-filter">
                Start Date: <input class="filter-date" type="text" id="dateStart" name="dateStart" size="30">
                End Date: <input class="filter-date" type="text" id="dateend" name="dateend" size="30">
            </div> -->
          
<ul class="timeline">                     
    <?php
    $count = 0;
    $monthText = '';
    while($row=mysqli_fetch_array($query))
    {
      
      ?>
      <?php if($monthText != date('F Y', strtoTime($row['insert_time']))): ?>
        <li class="time-label"><!-- timeline time label -->
            <span class="bg-gray" style="border-radius:0 !important;">
                <?=date('F Y', strtoTime($row['insert_time']));?>
            </span>
        </li><!-- /.timeline-label -->
      <?php endif; ?>
      <?php $monthText = date('F Y', strtoTime($row['insert_time'])); ?>

      <?php
                $headerTxt = '';$icon = '';$action='';
                if($row['method']=='sold')
                {
                  $headerTxt = 'Sales';
                  $icon = 'fa-ticket';
                  $stud = mysqli_query($mysqli,"SELECT CONCAT(fname,' ', mname,' ',lname) AS stud_name FROM tbl_students WHERE stud_id = '".$row['to_id']."' ");
                  $stud_row = mysqli_fetch_array($stud);

                  $txt = '<b>'.$row['user_name']. '</b> sold a book to '. $stud_row['stud_name'];
                  $action = '<a class="viewBookPurchases btn btn-primary btn-xs" data-id="'.$row['id'].'" data-trans_id="'.$row['details'].'">View Details</a>';
                }
                elseif($row['method']=='inserted_book')
                {
                  $headerTxt = 'New Book';
                  $icon = 'fa-book';
                  $stud = mysqli_query($mysqli,"SELECT * FROM tbl_books b LEFT JOIN tbl_suppliers s ON s.sup_id=b.sup_id WHERE book_id= '".$row['details']."' ");
                  $stud_row = mysqli_fetch_array($stud);
                  $txt = '<b>'.$row['user_name']. '</b> added <span class="text-info"><b>'. $stud_row['title'].'</b></span> to '.$stud_row['name'].' books';
                  //$action = '<a class="viewNewBook btn btn-primary btn-xs" data-id="'.$row['id'].'" data-book_id="'.$stud_row['book_id'].'" >View Details</a>';
                }
                elseif($row['method']=='delivered')
                {
                  $headerTxt = 'Delivery';
                  $icon = 'fa-truck';

                  $sqlDelivery = "SELECT *,p.po_no as po_no_new FROM tbl_delivery d LEFT JOIN tbl_po p ON p.po_id=d.po_id WHERE d.delivery_id= '".$row['details']."' ";

                  $del = mysqli_query($mysqli,$sqlDelivery) or die(mysqli_error($mysqli));
                  $del_row = mysqli_fetch_array($del);
                  $txt = "<b>".$row['user_name']. "</b> created a delivery to Purchase Order # ". $del_row['po_no_new'];

                  //$action = '<a class="viewDelivery btn btn-primary btn-xs" data-id="'.$row['id'].'" data-po_id="'.$del_row['po_id'].'" >View Details</a>';
                }
                elseif($row['method']=='stud_insert')
                {
                  $headerTxt = 'New Student';
                  $icon = 'fa-user';

                  $sqlDelivery = "SELECT *, concat(fname,' ',mname,' ', lname) as stud_name FROM tbl_students s WHERE stud_id= '".$row['to_id']."' ";

                  $del = mysqli_query($mysqli,$sqlDelivery) or die(mysqli_error($mysqli));
                  $del_row = mysqli_fetch_array($del);
                  $txt = "<b>".$row['user_name']. "</b> added ". $del_row['stud_name'];

                  $action = '<a class="viewStudent btn btn-primary btn-xs" data-id="'.$row['id'].'" data-stud_id="'.$del_row['stud_id'].'" >View Details</a>';
                }
                elseif($row['method']=='back_up_db')
                {
                  $headerTxt = 'Database Backup';
                  $icon = 'fa-database';

                  /*$sqlDelivery = "SELECT *, concat(fname,' ',mname,' ', lname) as stud_name FROM tbl_students s WHERE stud_id= '".$row['to_id']."' ";

                  $del = mysqli_query($mysqli,$sqlDelivery) or die(mysqli_error($mysqli));
                  $del_row = mysqli_fetch_array($del);
                  $txt = "<b>".$row['user_name']. "</b> added ". $del_row['stud_name'];

                  $action = '<a class="viewStudent btn btn-primary btn-xs" data-id="'.$row['id'].'" data-stud_id="'.$del_row['stud_id'].'" >View Details</a>';*/

                  $txt = "<b>".$row['user_name']. "</b> created database backup: <b>".$row['details'].'</b>';
                }
                else
                {
                  $txt = $row['user_name'] .' '. $row['method'];
                }
                ?>


                <!-- timeline item -->
                <li>
                    <!-- timeline icon -->
                    <i class="fa <?=$icon; ?> bg-gray"></i>
                    <div class="timeline-item">
                        <span class="time"><i class="fa fa-clock-o"></i> 
                        <?=date('M d, Y', strtoTime($row['insert_time']));?>
                        </span>
                        <h3 class="timeline-header"><a href="logs.php?id=<?=$row['id'];?>"><?=$headerTxt;?></a></h3>
                        <div class="timeline-body">
                            <span style=""><?=$txt;?></span>
                            <div class="table-responsive hide-me" id="log<?=$row['id'];?>"></div>
                        </div>
                        <div class="timeline-footer">
                            <?=$action;?>
                        </div>
                    </div>
                </li>
                <!-- END timeline item -->
    <?php
    }
    
    mysqli_close($mysqli);
    $count = 0;
    ?>

    <li>
      <span class="bg-gray fa fa-history"></span>
    </li>
                  
</ul>
    </div><!-- /.box-body -->
</div>
    <!-- /.box -->

<script>
$(document).on("click", ".viewBookPurchases", function(event)
{
  event.preventDefault();
  $(this).hide();
  var trans_id = $(this).data('trans_id');
  var id = $(this).data('id');
  viewBookPurchases(trans_id,id);

});

function viewBookPurchases(trans_id,id)
{
  $('#log'+id).html('Loading...');
    $.get({
        url: '../actions/getBookPurchases.php?trans_id='+trans_id,
        dataType: 'json',
        success: function(data){
            console.log(data);
            var html = '<br><table class="table table-hover">'+
                       '<tr class="alert-info">'+
                       '<th>No</th>'+
                       '<th>Barcode No</th>'+
                       '<th>Title</th>'+
                       '<th>Description</th>'+
                       '<th>Qty</th>'+
                       '<th>Price</th>'+
                       '</tr>';

            var i;
            if(!data)
            {
                alert("Error: No data received");
            }
            else
            {
               
            var data_count = data.length;
                for(i = 0; i < data_count; i++) 
                {
                    html += '<tr>'+
                                    '<td>'+ (i+1) +'</td>'+
                                    '<td>'+ data[i].barcode_no +'</td>'+
                                    '<td>'+ data[i].title +'</td>'+
                                    '<td>'+ data[i].description +'</td>'+
                                    '<td>'+ data[i].purchase_qty +'</td>'+
                                     '<td>'+ data[i].price_sold +'</td>'+
                            '</tr>';
            }
            html += '</table>';

            if(data_count==0)
            {
              $('#log'+id).html('No Data Found!');
            }
            else
            {
              $('#log'+id).html(html);
            }
          }
          $('#log'+id).slideDown();
        },
        error: function(data){
            console.log(data);
        }
        });
    }

$(document).on("click", ".viewStudent", function(event)
{
  event.preventDefault();
  $(this).hide();
  var stud_id = $(this).data('stud_id');
  var id = $(this).data('id');
  viewStudent(stud_id,id);

});

function viewStudent(stud_id,id)
{
  $('#log'+id).html('Loading...');
    $.get({
        url: '../actions/getStudents.php?stud_id='+stud_id,
        dataType: 'json',
        success: function(data){
            console.log(data);
            var html = '<br><table class="table table-hover">'+
                       '<tr class="alert-info">'+
                       '<th>Student No</th>'+
                       '<th>Name</th>'+
                       '<th>Year Level</th>'+
                       '</tr>';

            var i;
            if(!data)
            {
                alert("Error: No data received");
            }
            else
            {
               
            var data_count = data.length;
                for(i = 0; i < data_count; i++) 
                {
                    html += '<tr>'+
                                    '<td>'+ data[i].stud_no +'</td>'+
                                    '<td>'+ data[i].full_name +'</td>'+
                                    '<td>'+ data[i].yr_lvl +'</td>'+
                            '</tr>';
            }
            html += '</table>';

            if(data_count==0)
            {
              $('#log'+id).html('No Data Found!');
            }
            else
            {
              $('#log'+id).html(html);
            }
          }
          $('#log'+id).slideDown();
        },
        error: function(data){
            console.log(data);
        }
        });
    }
</script>
<?php include '../template/footer.php'; ?>