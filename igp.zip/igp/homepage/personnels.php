<?php 
$layout_active = 'personnels';
$layout_header_txt = 'Personnels';
?>

<?php include '../template/header.php'; ?>

<div class="box box-primary">
	<div class="box-header">
    
	<div class="row">
		<div class="col-lg-4">
			<div class="input-group">
				<input id="search_txt" type="text" class="form-control" placeholder="Search Personnel">
				<div class="input-group-btn">
				    <button onclick="getPersonnels()" class="btn btn-primary btn-flat" id="search_btn"><span class="fa fa-search"></span></button>
				</div>
			</div>
		</div>
		<div class="col-lg-8">
			<span class="pull-right">
			<button type="button" id="addNewPersonnel" class="btn btn-success btn-flat btn-sm"><i class="fa fa-plus"></i> Add New Personnel</button>
			</span>

		</div>
	</div>
	</div>
	<div class="box-body" style="min-height:400px;">
    <h3 id="search_txtHolder" style="margin:0;"></h3>
	<div class="table-responsive">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th width="10px">#</th>
                    <th>Name</th>
                    <th >User Type</th>
                    <th >Username</th>
                    <th >Email</th>
                    <th >Sex</th>
                    <th >Active</th>
                    <th>Action</th>
                </tr>
            </thead>
        <tbody id="personnelList"></tbody>
        </table>
    </div><!-- /.table-responsive -->

   	</div><!--./box-body-->
</div><!--./box-->


<div id="personnelModal" class="modal fade" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times</button>
                    <h4 class="modal-title">Title</h4>
                </div>
                <form id="myForm" action="" method="post" class="form-horizontal">
                <div class="modal-body">
                
                    <div class="row">
                         <input type="hidden" id="id">
            
			             <div class="col-lg-12">

                            <div id="personal-info">
                            <span class="text-success">Personal Details</span>
                            <small class="text-danger pull-right"> <i class="fa fa-info-o"></i> Fields with asterisk(*) are required</small>
                            <hr>

                            <div class="form-group">
                              <label for="user_type" class="col-sm-4 control-label">Select User Type *</label>
                              <div class="col-sm-8">
                                <select id="user_type" class="form-control">
                                    <option value="">--select--</option>
                                    <option value="clerk">Admin Aid</option>
                                    <option value="rel_personnel">Releasing Personnel</option>
                                </select>
                              </div>
                            </div><!-- /.form-group -->

                            <div class="form-group">
                              <label for="fname" class="col-sm-4 control-label">First Name *</label>
                              <div class="col-sm-8">
                                <input type="text" class="form-control" id="fname" placeholder="First Name" >
                              </div>
                            </div><!-- /.form-group -->

			                <div class="form-group">
			                  <label for="mname" class="col-sm-4 control-label">Middle Name </label>
			                  <div class="col-sm-8">
			                    <input type="text" class="form-control" id="mname" placeholder="Middle Name" >
			                  </div>
			                </div><!-- /.form-group -->

                            <div class="form-group">
                              <label for="lname" class="col-sm-4 control-label">Last Name *</label>
                              <div class="col-sm-8">
                                <input type="text" class="form-control" id="lname" placeholder="Last Name" >
                              </div>
                            </div><!-- /.form-group -->

			                <div class="form-group">
			                  <label for="sex" class="col-sm-4 control-label">Sex</label>
			                  <div class="col-sm-8">
                                <select id="sex" class="form-control">
                                  <option value="">--select--</option>
                                  <option value="Male">Male</option>
                                  <option value="Female">Female</option>
                              </select>
			                  </div>
			                </div><!-- /.form-group -->

                            <div class="form-group">
                              <label for="book_yr_lvl" class="col-sm-4 control-label">Email</label>
                              <div class="col-sm-8">
                                <input type="email" id="email" id="email" class="form-control" placeholder="Email">
                              </div>
                            </div><!-- /.form-group -->

                            </div>


                            <div id="login-details" style="display:none;">

                            <div class="form-group">
                                <hr>
                                <span class="col-sm-4 text-success">Login Details</span>
                            </div>

                            <div class="form-group">
                              <label for="username" class="col-sm-4 control-label">Username *</label>
                              <div class="col-sm-8">
                                <input type="text" class="form-control" id="username" placeholder="Username" >
                              </div>
                            </div><!-- /.form-group -->


                            <div class="form-group">
                              <label for="password" class="col-sm-4 control-label">Password *</label>
                              <div class="col-sm-8">
                                <input type="password" class="form-control" id="password" placeholder="Password" >
                              </div>
                            </div><!-- /.form-group -->

                            <div class="form-group">
                              <label for="conf_password" class="col-sm-4 control-label">Confirm Password *</label>
                              <div class="col-sm-8">
                                <input type="password" class="form-control" id="conf_password" placeholder="Confirm Password" >
                              </div>
                            </div><!-- /.form-group -->

                            </div>

			              </div><!-- /.col-md-12 -->
			             </div> <!-- /.row-->
                </div><!-- /.body-->
                <div class="modal-footer">
	                  <button type="button" id="btnAction" onclick="" class="btn btn-primary btn-flat">Update</button>
		            <input class="btn btn-default btn-flat" data-dismiss="modal" type="reset" value="cancel" name="cancel"> 
		        </div><!--footer-->
	          </form>
            </div> 
        </div>
    </div>


<script>

function showDiv(val)
{
    if(val=='login'){
        $('#login-details').show();
        $('#personal-info').hide();
        $('#username').prop('disabled',true);
    }else if(val=='personal'){
        $('#login-details').hide();
        $('#personal-info').show();
        $('#username').prop('disabled',false);
    }else{
        $('#login-details').show();
        $('#personal-info').show();
        $('#username').prop('disabled',false);
    }
    
}

	$(document).on("click", "#addNewPersonnel", function(event){
    
        event.preventDefault();
        $('#id').val('');
        $('#user_type').val('');
        $('#fname').val('');
        $('#mname').val('');
        $('#lname').val('');
        $('#sex').val('');
        $('#email').val('');
        $('#username').val('');
        $('#password').val('');
        $('#conf_password').val('');

        showDiv('all');

        $('#myForm').attr('action', '../actions/insertNewPersonnel.php');
        $('#personnelModal').find('.modal-title').text('Add New Personnel');
        $('#btnAction').attr('onclick','insertNewPersonnel()');
        $('#btnAction').text('Submit');
        $('#personnelModal').modal('show');
    });




    


getPersonnels();

function getPersonnels()
{
	var search_txt = $('#search_txt').val();
    
    if(search_txt.trim()!=''){
        $('#search_txtHolder').text('Search Results for \''+search_txt+'\'');
    }else{
         $('#search_txtHolder').text('');
    }

    $.get({
        url: '../actions/getPersonnels.php?search_txt='+search_txt,
        dataType: 'json',
        success: function(data){
        	console.log(data);
            var html = "";
            var i;
            if(!data)
            {
                alert("Error: No data received");
            }
            else
            {
               var data_count = data.length;
                for(i = 0; i < data_count; i++) 
                {
                    var editCntrl = 0, btnShow = '';
                	var user_type = '';
                    if(data[i].user_type=='system_admin'){
                        user_type = 'Administrator (IGP Director)';
                        editCntrl = 1;
                    }else if(data[i].user_type=='rel_personnel'){
                        user_type = 'Releasing Personnel';
                    }else if(data[i].user_type=='clerk'){
                        user_type = 'Admin Aid (Clerk)';
                    }

                    

                    if(editCntrl !=1 ){
                        btnShow = '<a href="#" class="editPersonnel btn btn-primary btn-flat btn-xs " data-id="'+data[i].id+'" data-full_name="'+data[i].full_name+'" data-fname="'+data[i].fname+'" data-mname="'+data[i].mname+'" data-lname="'+data[i].lname+'" data-sex="'+data[i].sex+'" data-user_type="'+data[i].user_type+'" data-username="'+data[i].username+'" data-email="'+data[i].email+'" data-active="'+data[i].active+'" ><i class="fa fa-edit"></i> Edit</a>&nbsp;'+

                        '<a href="#" class="editSecurity btn btn-default btn-flat btn-xs " data-id="'+data[i].id+'" data-full_name="'+data[i].full_name+'" data-username="'+data[i].username+'" data-username="'+data[i].username+'"><i class="fa fa-unlock-alt"></i></a>';
                    }

                	html += '<tr>'+
                                    '<td>'+ (i+1) +'</td>'+
                                    '<td>'+ data[i].full_name +'</td>'+
                                    '<td>'+ user_type +'</td>'+
                                    '<td>'+ data[i].username +'</td>'+
                                    '<td>'+ data[i].email +'</td>'+
                                    '<td>'+ data[i].sex +'</td>'+
                                    '<td>'+ data[i].active +'</td>'+
                                    '<td>'+ btnShow +'</td>'+
                                '</tr>';
                }

                if(data_count==0)
                {
                    $('#personnelList').html('<tr><td colspan="8">0 Record Found</td></tr>');
                }
                else
                {
                    $('#personnelList').html(html);
                }
            }
        },
        error: function(data){
            console.log(data);
        }
        });
    }

    function insertNewPersonnel()
    {
    	var url = $('#myForm').attr('action');
    	var result = '';

        var user_type = $('#user_type');
        var fname = $('#fname');
        var mname = $('#mname');
        var lname = $('#lname');
        var sex = $('#sex');
        var email = $('#email');
        var username = $('#username');
        var password = $('#password');
        var conf_password = $('#conf_password');

        var fnameVal = fname.val().replace(/\s{2,}/g,' ');
        var mnameVal = mname.val().replace(/\s{2,}/g,' ');
        var lnameVal = lname.val().replace(/\s{2,}/g,' ');
        var usernameVal = username.val().replace(/\s{2,}/g,' ');
        var passwordVal = password.val().replace(/\s{2,}/g,' ');
        var conf_passwordVal = conf_password.val().replace(/\s{2,}/g,' ');

        if(user_type.val() == ''){
          user_type.parent().addClass('has-error');
          user_type.focus();
          return false;
        }else{
          user_type.parent().removeClass('has-error');
        }

	    if(fnameVal == '' || fnameVal == ' '){
	      fname.parent().addClass('has-error');
	      fname.focus();
	      return false;
	    }else{
	      fname.parent().removeClass('has-error');
	    }

	    if(lnameVal == '' || lnameVal == ' '){
	      lname.parent().addClass('has-error');
	      lname.focus();
	      return false;
	    }else{
	      lname.parent().removeClass('has-error');
	    }

        if(usernameVal == '' || usernameVal == ' '){
          username.parent().addClass('has-error');
          username.focus();
          return false;
        }else{
          username.parent().removeClass('has-error');
        }

        if(passwordVal == '' || passwordVal == ' '){
          password.parent().addClass('has-error');
          password.focus();
          return false;
        }else{
          password.parent().removeClass('has-error');
        }

        if(conf_passwordVal == '' || conf_passwordVal == ' '){
          conf_password.parent().addClass('has-error');
          conf_password.focus();
          return false;
        }else{
          conf_password.parent().removeClass('has-error');
        }

        if(password.val() != conf_password.val()){
            alert('Password and Confirm Password do not match!');
            conf_password.focus();
            conf_password.parent().addClass('has-error');
            password.parent().addClass('has-error');
            return false;
        }else{
            conf_password.parent().removeClass('has-error');
            password.parent().removeClass('has-error');
        }

    var queryString = '?fname='+fnameVal;
        queryString += '&mname='+mnameVal;
        queryString += '&lname='+lnameVal;
        queryString += '&sex='+sex.val();
        queryString += '&email='+email.val();
        queryString += '&username='+usernameVal;
        queryString += '&password='+password.val();
        queryString += '&conf_password='+conf_password.val();
        queryString += '&user_type='+user_type.val();

    $.ajax({
        type: 'ajax',
        method: 'get',
        url: url+queryString,
        dataType: 'json',
        success: function(response){
            if(response.msg==true)
            {
            	$('#personnelModal').modal('hide');
              	getPersonnels();
                showMsg('Account successfully added');
            }
            else if(response.msg=='duplicate')
            {
            	alert('Duplicate Found!');
            }
            else
            {
              	alert('Unable to Add New Supplier');
            }
        },
        error: function(response){
          //alert('Error');
          console.log(response);
        }
      });
    }

    $(document).on("click", ".deactivate", function(event){
        event.preventDefault();

        var book_id = $(this).data("book_id");
        var name = $(this).data("name");
        var status = $(this).data("status");
        var strClear = '';

        var queryString = '?book_id='+book_id;
        	queryString += '&status='+status;

        	if(status == 'active'){
        		strClear = 'deactivate';
        	}else{
        		strClear = 'activate';
        	}

        var url = '../actions/deactivateSupplier.php';

        var conf = confirm("This will "+strClear+" "+name+", click OK to continue.");
        if(conf == true)
        {
            $.ajax({
            type: 'ajax',
            method: 'get',
            url: url+queryString,
            dataType: 'json',
            success: function(response){
                if(response.msg==true)
                {
                  getPersonnels();
                }
                else
                {
                  alert('Unable to deactivate supplier');
                }
            },
            error: function(response){
              alert('Error');
              console.log(response);
            }
          });
        }

    });

    $(document).on("click", ".editPersonnel", function(event){
        event.preventDefault();

        var id = $(this).data("id");
        var user_type = $(this).data('user_type');
        var fname = $(this).data('fname');
        var mname = $(this).data('mname');
        var lname = $(this).data('lname');
        var sex = $(this).data('sex');
        var email = $(this).data('email');
        var username = $(this).data('username');
        var full_name = $(this).data('full_name');

        $('#id').val(id);
        $('#user_type').val(user_type);
        $('#fname').val(fname);
        $('#mname').val(mname);
        $('#lname').val(lname);
        $('#sex').val(sex);
        $('#email').val(email);
        
        showDiv('personal');

        $('#myForm').attr('action', '../actions/editPersonnel_info.php');
        $('#personnelModal').find('.modal-title').text('Update '+ full_name);
        $('#btnAction').attr('onclick','updatePersonnel()');
        $('#btnAction').text('Update');
        $('#personnelModal').modal('show');

    });

    function updatePersonnel()
    {
    	var url = $('#myForm').attr('action');

    	var id = $('#id');
        var user_type = $('#user_type');
        var fname = $('#fname');
        var mname = $('#mname');
        var lname = $('#lname');
        var sex = $('#sex');
        var email = $('#email');

        var fnameVal = fname.val().replace(/\s{2,}/g,' ');
        var mnameVal = mname.val().replace(/\s{2,}/g,' ');
        var lnameVal = lname.val().replace(/\s{2,}/g,' ');

        if(user_type.val() == ''){
          user_type.parent().addClass('has-error');
          user_type.focus();
          return false;
        }else{
          user_type.parent().removeClass('has-error');
        }

        if(fnameVal == '' || fnameVal == ' '){
          fname.parent().addClass('has-error');
          fname.focus();
          return false;
        }else{
          fname.parent().removeClass('has-error');
        }

        if(lnameVal == '' || lnameVal == ' '){
          lname.parent().addClass('has-error');
          lname.focus();
          return false;
        }else{
          lname.parent().removeClass('has-error');
        }

    var queryString = '?fname='+fnameVal;
        queryString += '&mname='+mnameVal;
        queryString += '&lname='+lnameVal;
        queryString += '&sex='+sex.val();
        queryString += '&email='+email.val();
        queryString += '&user_type='+user_type.val();
        queryString += '&id='+id.val();

    	$.ajax({
            type: 'ajax',
            method: 'get',
            url: url+queryString,
            dataType: 'json',
            success: function(response){
                if(response.msg==true)
                {
                  $('#personnelModal').modal('hide');
                  getPersonnels();
                  showMsg('Personnel details successfully updated');
                }
                else if(response.msg=='duplicate')
                {
                	alert('Duplicate found.');
                }
                else
                {
                  alert('Unable to update details');
                }
            },
            error: function(response){
              alert('Error');
              console.log(response);
            }
          });
    }

    $(document).on("click", ".editSecurity", function(event){
    
        event.preventDefault();
        var id = $(this).data("id");
        var username = $(this).data('username');
        var full_name = $(this).data('full_name');

        $('#id').val(id);
        $('#username').val(username);
        $('#password').val('');
        $('#conf_password').val('');

        showDiv('login');

        $('#myForm').attr('action', '../actions/editSecurity.php');
        $('#personnelModal').find('.modal-title').text(full_name+' -> Reset password ');
        $('#btnAction').attr('onclick','editSecurity()');
        $('#btnAction').text('Update');
        $('#personnelModal').modal('show');
    });

    function editSecurity()
    {
        var url = $('#myForm').attr('action');

        var id = $('#id');
        var password = $('#password');
        var conf_password = $('#conf_password');

        if(password.val() == ''){
          password.parent().addClass('has-error');
          password.focus();
          return false;
        }else{
          password.parent().removeClass('has-error');
        }

        if(conf_password.val() == ' '){
          conf_password.parent().addClass('has-error');
          conf_password.focus();
          return false;
        }else{
          conf_password.parent().removeClass('has-error');
        }

        if(password.val() != conf_password.val()){
            alert('Password and Confirm Password do not match!');
            conf_password.focus();
            conf_password.parent().addClass('has-error');
            password.parent().addClass('has-error');
            return false;
        }else{
            conf_password.parent().removeClass('has-error');
            password.parent().removeClass('has-error');
        }

    var queryString = '?id='+id.val();
        queryString += '&password='+password.val();
        queryString += '&conf_password='+conf_password.val();

        $.ajax({
            type: 'ajax',
            method: 'get',
            url: url+queryString,
            dataType: 'json',
            success: function(response){
                if(response.msg==true)
                {
                  $('#personnelModal').modal('hide');
                  getPersonnels();
                  showMsg('Password successfully updated');
                }
                else
                {
                  alert('Unable to update details');
                }
            },
            error: function(response){
              alert('Error');
              console.log(response);
            }
          });
    }

</script>

<?php include '../template/footer.php'; ?>