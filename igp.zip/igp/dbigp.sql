-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 18, 2018 at 09:18 PM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbigp`
--

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `at_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `time` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_attempts`
--

INSERT INTO `login_attempts` (`at_id`, `user_id`, `time`) VALUES
(1, 11, '1518415075'),
(2, 14, '1518832301'),
(3, 1, '1518833490');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_books`
--

CREATE TABLE `tbl_books` (
  `book_id` int(11) NOT NULL,
  `barcode_no` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `book_yr_lvl` varchar(100) NOT NULL,
  `publisher` varchar(255) NOT NULL,
  `sup_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` enum('used','unused') NOT NULL DEFAULT 'used',
  `date_added` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_books`
--

INSERT INTO `tbl_books` (`book_id`, `barcode_no`, `title`, `description`, `book_yr_lvl`, `publisher`, `sup_id`, `user_id`, `status`, `date_added`) VALUES
(1, '190001', 'The little big star', 'Giving up is not easy', '1st Year', 'phoenix', 2, 1, 'used', '2018-02-02 22:41:52'),
(2, '1900021111', 'aaaaaaaaaaaa', 'bbbbbbbbbbbbb', 'Grade 3', 'phoenix', 2, 0, 'used', '2018-02-02 23:17:03'),
(3, '1', 'ccc', 'desc cc', 'Grade 11', 'phoenix', 2, 0, 'used', '2018-02-02 23:18:15'),
(4, '1900045', 'vbs', 'ddfs', 'Grade 11', 'lastico', 24, 0, 'used', '2018-02-02 23:19:09'),
(5, '1900046', 'Korean Culture', 'Annyeong', 'Grade 11', 'thunder volt', 1, 0, 'used', '2018-02-05 14:28:44'),
(6, '', 'In the woods', 'The statutory ', 'Grade 2', 'Philpost', 1, 0, 'used', '2018-02-06 21:03:06'),
(7, '', 'asdfsdfsdf', 'sdfsdfs', 'Grade 11', 'asdfsdf', 1, 0, 'used', '2018-02-06 22:14:16'),
(8, '19089881', 'Dulce et decurum es pro patrio more', 'It\'s sweet to die for once country', 'Grade 11', 'Phoenix', 1, 0, 'used', '2018-02-10 08:26:34'),
(9, '', 'LKSDFJLK', 'SDKFJLK', 'Grade 1', 'LJKLSDFJSDF', 2, 0, 'used', '2018-02-11 14:15:04'),
(10, '', 'new book', 'desc', 'Grade 3', 'Phoenix', 2, 0, 'used', '2018-02-11 14:16:34'),
(11, '', 'Book 2', 'desc', 'Grade 1', 'osdfsldfkjsdf', 2, 0, 'used', '2018-02-11 14:21:52'),
(12, '', 'sdf', 'sdfsdf', 'Grade 3', '1212', 2, 0, 'used', '2018-02-11 14:26:26'),
(13, '1908923', 'Descendants of the sun', 'dsf', 'Grade 9', 'Phoenix', 2, 0, 'used', '2018-02-11 14:30:35'),
(14, '192039303', 'Hotel California', 'dkdsl', '1st Year', 'Phoenix', 2, 1, 'used', '2018-02-11 14:38:10'),
(15, '', 'Pluma', 'Ang wika', 'Grade 1', 'Phoenix', 2, 1, 'used', '2018-02-11 14:45:23'),
(16, '19029202', 'Brezze', 'Desc', '1st Year', 'Phoenix', 30, 1, 'used', '2018-02-14 10:26:27'),
(17, '186979379039', 'EDUKASYON SA PAGPAPAKATAO 1', 'desc', 'Grade 10', 'Phoenix', 2, 14, 'used', '2018-02-16 18:01:52'),
(18, '186979379040', 'GRAMMAR AND APPLICATION 10', 'none', 'Grade 10', 'Phoenix', 2, 14, 'used', '2018-02-16 18:03:04'),
(19, '', 'Araling Panlipunan', 'NONE', 'Grade 8', 'Phoenix', 2, 14, 'used', '2018-02-16 18:06:45');

--
-- Triggers `tbl_books`
--
DELIMITER $$
CREATE TRIGGER `onInsert` AFTER INSERT ON `tbl_books` FOR EACH ROW BEGIN
INSERT INTO tbl_logs(user_id, to_id, method,details) VALUES(new.user_id,'','inserted_book',new.book_id);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_book_purchases`
--

CREATE TABLE `tbl_book_purchases` (
  `purchase_id` int(11) NOT NULL,
  `trans_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `pob_id` int(11) NOT NULL,
  `purchase_qty` int(11) NOT NULL,
  `price_sold` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_book_purchases`
--

INSERT INTO `tbl_book_purchases` (`purchase_id`, `trans_id`, `book_id`, `pob_id`, `purchase_qty`, `price_sold`) VALUES
(55, 53, 17, 77, 1, 500),
(56, 54, 18, 78, 1, 400),
(57, 55, 17, 77, 1, 500);

--
-- Triggers `tbl_book_purchases`
--
DELIMITER $$
CREATE TRIGGER `tbl_purhcesInsert` AFTER INSERT ON `tbl_book_purchases` FOR EACH ROW BEGIN
UPDATE tbl_po_books p SET p.sold_qty = p.sold_qty + new.purchase_qty WHERE p.pob_id = new.pob_id LIMIT 1;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_delivery`
--

CREATE TABLE `tbl_delivery` (
  `delivery_id` int(11) NOT NULL,
  `po_id` int(11) NOT NULL,
  `dr_no` varchar(255) NOT NULL,
  `delivery_date` date NOT NULL,
  `user_id_deliver` int(11) NOT NULL,
  `date_input` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_delivery`
--

INSERT INTO `tbl_delivery` (`delivery_id`, `po_id`, `dr_no`, `delivery_date`, `user_id_deliver`, `date_input`) VALUES
(33, 32, '25794 (GT)', '2017-11-05', 1, '2018-02-16 18:15:24');

--
-- Triggers `tbl_delivery`
--
DELIMITER $$
CREATE TRIGGER `onDelivery` AFTER INSERT ON `tbl_delivery` FOR EACH ROW BEGIN
INSERT INTO tbl_logs(user_id, method,details) VALUES(new.user_id_deliver,'delivered',new.delivery_id);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_logs`
--

CREATE TABLE `tbl_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `to_id` int(11) NOT NULL,
  `method` varchar(100) NOT NULL,
  `details` varchar(255) NOT NULL,
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_logs`
--

INSERT INTO `tbl_logs` (`id`, `user_id`, `to_id`, `method`, `details`, `insert_time`) VALUES
(79, 14, 0, 'inserted_book', '17', '2018-02-17 02:01:52'),
(80, 14, 0, 'inserted_book', '18', '2018-02-17 02:03:04'),
(82, 1, 0, 'delivered', '33', '2018-02-17 02:15:24'),
(91, 1, 11, 'stud_insert', '', '2018-02-17 02:31:21'),
(92, 11, 1, 'sold', '53', '2018-02-17 03:57:34'),
(93, 11, 6, 'sold', '54', '2018-02-17 22:14:41'),
(94, 1, 0, 'back_up_db', '', '2018-02-18 04:43:06'),
(95, 1, 0, 'back_up_db', 'db_backup_February 18, 2018_1518929395.sql', '2018-02-18 04:49:55'),
(96, 1, 0, 'back_up_db', 'db_backup_February 18, 2018_1518929497.sql', '2018-02-18 04:51:37'),
(97, 11, 1, 'sold', '55', '2018-02-18 19:21:06'),
(98, 1, 0, 'back_up_db', 'db_backup_February 18, 2018_1518984727.sql', '2018-02-18 20:12:07');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_po`
--

CREATE TABLE `tbl_po` (
  `po_id` int(11) NOT NULL,
  `sup_id` int(11) NOT NULL,
  `po_no` varchar(255) NOT NULL,
  `date_receive` date NOT NULL,
  `user_id_receive` int(11) NOT NULL,
  `user_id_po` int(11) NOT NULL,
  `po_status` enum('received','delivered') NOT NULL DEFAULT 'received',
  `insert_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_po`
--

INSERT INTO `tbl_po` (`po_id`, `sup_id`, `po_no`, `date_receive`, `user_id_receive`, `user_id_po`, `po_status`, `insert_date`) VALUES
(32, 2, '17-05-0012', '2017-08-05', 14, 0, 'received', '2018-02-16 18:00:29'),
(33, 2, '1090-202-90', '2018-02-16', 1, 0, 'received', '2018-02-16 19:18:28');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_po_books`
--

CREATE TABLE `tbl_po_books` (
  `pob_id` int(11) NOT NULL,
  `po_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `pob_qty` int(11) NOT NULL,
  `pob_company_price` float NOT NULL,
  `delivered_qty` int(11) NOT NULL,
  `pob_lnu_price` float NOT NULL,
  `sold_qty` int(11) NOT NULL,
  `user_id_inserted` int(11) NOT NULL,
  `date_inserted` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_po_books`
--

INSERT INTO `tbl_po_books` (`pob_id`, `po_id`, `book_id`, `pob_qty`, `pob_company_price`, `delivered_qty`, `pob_lnu_price`, `sold_qty`, `user_id_inserted`, `date_inserted`) VALUES
(77, 32, 17, 40, 417, 40, 500, 2, 14, '2018-02-16 18:02:18'),
(78, 32, 18, 45, 340, 40, 400, 1, 14, '2018-02-16 18:04:32'),
(79, 33, 1, 100, 130, 0, 0, 0, 1, '2018-02-16 19:36:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_seen_logs`
--

CREATE TABLE `tbl_seen_logs` (
  `id` int(11) NOT NULL,
  `log_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date_seen` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_seen_logs`
--

INSERT INTO `tbl_seen_logs` (`id`, `log_id`, `user_id`, `date_seen`) VALUES
(1, 79, 1, '2018-02-17 21:14:39'),
(2, 80, 1, '2018-02-17 22:21:14'),
(3, 82, 1, '2018-02-17 22:21:14'),
(4, 91, 1, '2018-02-17 22:21:14'),
(5, 92, 1, '2018-02-17 22:21:14'),
(6, 93, 1, '2018-02-17 22:21:14'),
(7, 94, 1, '2018-02-17 22:21:14'),
(8, 95, 1, '2018-02-17 22:21:14'),
(9, 96, 1, '2018-02-17 22:21:14'),
(14, 79, 11, '2018-02-17 22:39:16'),
(15, 80, 11, '2018-02-17 22:39:16'),
(16, 97, 1, '2018-02-18 12:02:01'),
(17, 79, 16, '2018-02-18 12:06:21'),
(18, 80, 16, '2018-02-18 12:06:22'),
(19, 82, 16, '2018-02-18 12:06:22'),
(20, 91, 16, '2018-02-18 12:06:22'),
(21, 92, 16, '2018-02-18 12:06:22'),
(22, 93, 16, '2018-02-18 12:06:22'),
(23, 94, 16, '2018-02-18 12:06:22'),
(24, 95, 16, '2018-02-18 12:06:22'),
(25, 96, 16, '2018-02-18 12:06:22'),
(26, 97, 16, '2018-02-18 12:06:22'),
(27, 98, 1, '2018-02-18 12:12:55');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_students`
--

CREATE TABLE `tbl_students` (
  `stud_id` int(11) NOT NULL,
  `stud_no` int(11) NOT NULL,
  `fname` varchar(200) NOT NULL,
  `mname` varchar(200) NOT NULL,
  `lname` varchar(200) NOT NULL,
  `ext` varchar(100) NOT NULL,
  `yr_lvl` varchar(100) NOT NULL,
  `user_added` int(11) NOT NULL,
  `date_added` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `stud_status` enum('active','inactive') NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_students`
--

INSERT INTO `tbl_students` (`stud_id`, `stud_no`, `fname`, `mname`, `lname`, `ext`, `yr_lvl`, `user_added`, `date_added`, `stud_status`) VALUES
(1, 1301510, 'Bruno', 'Mars', 'Balle', '', '1st Year', 1, '2018-02-04 23:59:41', 'active'),
(2, 1301511, 'Christopher', 'Chui', 'Cruz', '', '1st Year', 0, '2018-02-05 00:43:29', 'active'),
(3, 1301512, 'Janessa', '', 'Blake', '', 'Grade 3', 0, '2018-02-16 18:19:56', 'active'),
(4, 1301513, 'Ivy', '', 'Aguas', '', 'Grade 4', 0, '2018-02-16 18:20:41', 'active'),
(5, 1301514, 'Hardley', '', 'Park', '', 'Grade 5', 0, '2018-02-16 18:21:09', 'active'),
(6, 1301516, 'Emerson ', '', 'Azucena', '', 'Grade 6', 0, '2018-02-16 18:21:45', 'active'),
(7, 1301517, 'June Dale', '', 'Asis', '', 'Grade 1', 0, '2018-02-16 18:22:30', 'active'),
(8, 1301518, 'Chris', '', 'Villanueva', '', 'Grade 2', 0, '2018-02-16 18:23:16', 'active'),
(9, 1301519, 'Precious', '', 'Supe', '', 'Grade 3', 0, '2018-02-16 18:26:23', 'active'),
(10, 1301520, 'Jong Suk', '', 'Lee', '', 'Grade 6', 1, '2018-02-16 18:28:55', 'active'),
(11, 1301521, 'Rose Anne', '', 'Yocte', '', 'Grade 6', 1, '2018-02-16 18:31:21', 'active');

--
-- Triggers `tbl_students`
--
DELIMITER $$
CREATE TRIGGER `onInsertStud` AFTER INSERT ON `tbl_students` FOR EACH ROW BEGIN
INSERT INTO tbl_logs(user_id, method,to_id) VALUES(new.user_added,'stud_insert',new.stud_id);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_suppliers`
--

CREATE TABLE `tbl_suppliers` (
  `sup_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `contact_no` varchar(200) NOT NULL,
  `company_no` varchar(100) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date_registered` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('active','deactivated') NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_suppliers`
--

INSERT INTO `tbl_suppliers` (`sup_id`, `name`, `address`, `contact_no`, `company_no`, `user_id`, `date_registered`, `status`) VALUES
(1, 'VRCS', 'Brgy. Catinco', '098735633', '1111', 0, '2018-02-02 05:52:57', 'active'),
(2, 'VICARISH PUBLICATION ', '1946-A F. Torres corner Diamante Ext, Sta. Ana, Manila', '3232323\r\n', '5648318', 0, '2018-02-02 05:52:57', 'active'),
(23, 'Justine Company', 'Real St. Tacloban city', '', '0908189290', 0, '2018-02-03 05:03:29', 'active'),
(24, 'thoers', 'block 1', '', '9122333', 0, '2018-02-03 05:04:40', 'active'),
(25, 'ABCD company', 'Tacloban City', '', '888678897', 0, '2018-02-08 20:31:07', 'active'),
(26, 'abyy company', 'San Isidro,Leyte', '', '9802389', 0, '2018-02-08 20:31:59', 'active'),
(27, 'kjsdflj', 'dfksj', '', '232323', 0, '2018-02-09 03:23:14', 'active'),
(28, 'sldkfjasdfkfj', 'asdf', '', '343432323', 0, '2018-02-09 03:26:32', 'active'),
(29, 'Sharmaine Company', 'sdkfjsf', '', '1212919212', 0, '2018-02-09 03:27:29', 'active'),
(30, 'Stiff\'s Company', 'Barangay Binaun', '', '901212', 0, '2018-02-09 03:29:43', 'active'),
(31, 'Supplier 1', 'Brgy, 212 paterno', '', '2147483647', 0, '2018-02-10 04:00:17', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_transactions`
--

CREATE TABLE `tbl_transactions` (
  `trans_id` int(11) NOT NULL,
  `stud_id` int(11) NOT NULL,
  `or_no` varchar(255) NOT NULL,
  `or_status` enum('cash','promisory') NOT NULL,
  `amount_payable` float NOT NULL,
  `sold_by` int(11) NOT NULL,
  `date_purchased` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_transactions`
--

INSERT INTO `tbl_transactions` (`trans_id`, `stud_id`, `or_no`, `or_status`, `amount_payable`, `sold_by`, `date_purchased`) VALUES
(53, 1, '', 'promisory', 500, 11, '2018-02-16 19:57:34'),
(54, 6, '', 'promisory', 400, 11, '2018-02-17 14:14:41'),
(55, 1, '', 'promisory', 500, 11, '2018-02-18 11:21:06');

--
-- Triggers `tbl_transactions`
--
DELIMITER $$
CREATE TRIGGER `onpurchase` AFTER INSERT ON `tbl_transactions` FOR EACH ROW BEGIN
INSERT INTO tbl_logs(user_id, to_id, method,details) VALUES(new.sold_by,new.stud_id,'sold',new.trans_id);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL,
  `user_type` varchar(100) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `mname` varchar(100) NOT NULL,
  `sex` enum('Male','Female') DEFAULT NULL,
  `email` varchar(30) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_block` tinyint(1) NOT NULL DEFAULT '0',
  `role_id` int(11) NOT NULL,
  `online_stat` tinyint(1) NOT NULL DEFAULT '0',
  `timelaps` datetime NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_ip` varchar(100) NOT NULL,
  `active` enum('yes','no') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `user_type`, `lname`, `fname`, `mname`, `sex`, `email`, `username`, `password`, `user_block`, `role_id`, `online_stat`, `timelaps`, `created_at`, `user_ip`, `active`) VALUES
(1, 'system_admin', 'Alimangohan', 'Freddie', '', 'Male', 'admin@gmail.com', 'admin', 'c7ad44cbad762a5da0a452f9e854fdc1e0e7a52a38015f23f3eab1d80b931dd472634dfac71cd34ebc35d16ab7fb8a90c81f975113d6c7538dc69dd8de9077ec', 0, 1, 1, '2018-02-18 21:18:54', '2018-02-01 00:00:00', '::1', 'yes'),
(11, 'rel_personnel', 'Andoque', 'Sharm', '', 'Female', '', 'sharm', 'c7ad44cbad762a5da0a452f9e854fdc1e0e7a52a38015f23f3eab1d80b931dd472634dfac71cd34ebc35d16ab7fb8a90c81f975113d6c7538dc69dd8de9077ec', 0, 0, 0, '2018-02-18 21:01:36', '2018-02-10 19:38:57', '::1', 'yes'),
(14, 'clerk', 'Cinco', 'Vryan', '', 'Male', 'vryan@gmail.com', 'vryan', '9917a61d34235f7d502d5c983830fc475c51714af189a7462437cfc8714c2d855ec63923ae232ce6b19a5e6ebf5fcdb9fd446342f82a1b05530dd804afd58160', 0, 0, 0, '2018-02-17 03:11:21', '2018-02-16 17:51:20', '::1', 'no'),
(15, 'rel_personnel', 'Barreto', 'Christopher', '', 'Male', '', 'christopher', '2c1954d7285d5e8a7f379d3e3d38780026df8fc64f7af09ead6085dd00525279a8b1f20e5e931e6c39dfc4ad598fd07639e267425f43b3a3d6eb58532688fc5b', 0, 0, 0, '0000-00-00 00:00:00', '2018-02-18 12:03:38', '', 'yes'),
(16, 'clerk', 'Alom', 'Abegail', '', 'Female', '', 'alom', '9898ca720b803082b88b68601f3d3ae0cbf0de65d7315e5e69b2d03f2a9ac75928cf2de40b22bffe6332733a192cf4e82c14a227d1b3c0e603d05375f7969132', 0, 0, 0, '2018-02-18 21:11:48', '2018-02-18 12:05:10', '::1', 'yes');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`at_id`);

--
-- Indexes for table `tbl_books`
--
ALTER TABLE `tbl_books`
  ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `tbl_book_purchases`
--
ALTER TABLE `tbl_book_purchases`
  ADD PRIMARY KEY (`purchase_id`);

--
-- Indexes for table `tbl_delivery`
--
ALTER TABLE `tbl_delivery`
  ADD PRIMARY KEY (`delivery_id`);

--
-- Indexes for table `tbl_logs`
--
ALTER TABLE `tbl_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_po`
--
ALTER TABLE `tbl_po`
  ADD PRIMARY KEY (`po_id`);

--
-- Indexes for table `tbl_po_books`
--
ALTER TABLE `tbl_po_books`
  ADD PRIMARY KEY (`pob_id`);

--
-- Indexes for table `tbl_seen_logs`
--
ALTER TABLE `tbl_seen_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_students`
--
ALTER TABLE `tbl_students`
  ADD PRIMARY KEY (`stud_id`);

--
-- Indexes for table `tbl_suppliers`
--
ALTER TABLE `tbl_suppliers`
  ADD PRIMARY KEY (`sup_id`);

--
-- Indexes for table `tbl_transactions`
--
ALTER TABLE `tbl_transactions`
  ADD PRIMARY KEY (`trans_id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `at_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_books`
--
ALTER TABLE `tbl_books`
  MODIFY `book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `tbl_book_purchases`
--
ALTER TABLE `tbl_book_purchases`
  MODIFY `purchase_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;
--
-- AUTO_INCREMENT for table `tbl_delivery`
--
ALTER TABLE `tbl_delivery`
  MODIFY `delivery_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `tbl_logs`
--
ALTER TABLE `tbl_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=99;
--
-- AUTO_INCREMENT for table `tbl_po`
--
ALTER TABLE `tbl_po`
  MODIFY `po_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `tbl_po_books`
--
ALTER TABLE `tbl_po_books`
  MODIFY `pob_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;
--
-- AUTO_INCREMENT for table `tbl_seen_logs`
--
ALTER TABLE `tbl_seen_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `tbl_students`
--
ALTER TABLE `tbl_students`
  MODIFY `stud_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `tbl_suppliers`
--
ALTER TABLE `tbl_suppliers`
  MODIFY `sup_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `tbl_transactions`
--
ALTER TABLE `tbl_transactions`
  MODIFY `trans_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;
--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
