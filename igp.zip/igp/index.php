<?php
require_once 'connection/config.php';
include_once 'security/methods.php';
if (checkLogin($mysqli) == true) 
{ 
    header('Location: homepage/index.php'); 
}
?>

<!DOCTYPE html>
<html>
    <head>
    <title>Login</title>
    <link rel="icon" href="assets/image/igp-logo.jpg">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/custom.css">
    <link rel="stylesheet" href="assets/dist/css/AdminLTE.css">
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script type="text/JavaScript" src="assets/js/sha512.js"></script> 
    <script type="text/JavaScript" src="assets/js/forms.js"></script>

    </head>
    <body class="hold-transition login-page" style="background: blue;padding-top: 95px;">

        <form class="form-horizontal login-form" action="security/login.php" method="POST" name="login_form" id="login_form">
            <div class="login-header">
                <img src="assets/image/lnu-logo.png" class="lnu-logo left">
                <img src="assets/image/igp-logo-2.jpeg" class="lnu-logo right">
                <h2>LNU-IGP BOOKSTORE<br>SALES AND INVENTORY SYSTEM</h2>
            </div>
            <div class="sub-form">
                <h1 class="head"><span class="glyphicon glyphicon-lock"></span> &nbsp; SIGN &nbsp; IN</h1>
                <div class="form-group">
                <?php
                if (isset($_GET['error'])) { echo '<p style="color:red;">Invalid Username and Password!</p>'; }
                if (!empty($error_msg)) { echo $error_msg; }
                ?> 
                    <div class="row">
                        <div class="col-xs-12">
                            <label class="col-xs-2 control-label" style="padding-right: 0;">
                                <span class="glyphicon glyphicon-user"></span>
                            </label>
                            <div class="col-xs-9">
                                <input type="text" name="username"  placeholder="Unsername" class="form-control" autofocus />
                                
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="row">
                        <div class="col-xs-12">
                            <label class="col-xs-2 control-label" style="padding-right: 0;">
                                <span class="glyphicon glyphicon-lock"></span>
                            </label>
                            <div class="col-xs-9">
                                <input onkeypress="handle(event)" id="password" type="password" name="password" placeholder="Password" class="form-control" />
                                
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="row">
                        <div class="col-xs-12">
                            <button type="submit" class="btn btn-primary" id="login" onclick="formhash(this.form, this.form.password,this.form.username);">
                                Log in
                                <i class="glyphicon glyphicon-log-in"></i>
                            </button>

                            <!-- <a href="" class="btn btn-primary">
                                Register
                                <i class="glyphicon glyphicon-registration-mark"></i>
                            </a> -->
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <h4>All Rights Reserved 2017 | THE SITS</h4>
            <br>
        </form>

    </body>
</html>


<script>
function handle(e){
    if(e.keyCode === 13){
        e.preventDefault(); // Ensure it is only this code that runs
        var x = document.getElementById('login');
        x.click();
    }
}
function checkCookieEnable(){
    if(navigator.cookieEnabled==false){
        alert('Warning! Please enable cookie. \nCHED SCOPES uses cookies to store user login infromations.');
    }
}

$(document).on("click", ".for-password", function(event){
    event.preventDefault();
    $('#modal_password').modal('show');  
});

function sendPassReq(){
    
    var result = '';
    var email_req = $('#email_req').val().trim();

    if(email_req != '')
    {
        result = '1';
    }
    else
    {
        $('#email_req').focus();
    }

    var queryString = '?email_req='+email_req;
        queryString += '&action='+'sendemail';
    
    if(result == '1')
    {
        $('#msg-email').html('Loading...');
        $('#msg-email').slideDown();
        $.ajax({
        type: 'ajax',
        method: 'get',
        url: 'system_main/sendEmail.php'+queryString,
        dataType: 'json',
        success: function(response){
            if(response.msg==true)
            {
              $('#msg-email').html('<p class="text-success">Success! <br>If the email entered correctly, you will be receiving an email shortly with instructions on how you can set up your new password.</p>');
            }
            else
            {
              $('#msg-email').html('<p class="text-danger">'+response.error+'</p>');
            }
        },
        error: function(response){
          //alert('Error');
          console.log(response);
        }
      });
      
    }
}

</script>


</body>
</html>