function formhash(form, password, username) {
    if(username.value==''){
        username.focus();
        return false;
    }else if(password.value==''){
        password.focus();
        return false;
    } 
    // Create a new element input, this will be our hashed password field. 
    var p = document.createElement("input");
 
    // Add the new element to our form. 
    form.appendChild(p);
    p.name = "p";
    p.type = "hidden";
    p.value = hex_sha512(password.value);
 
    // Make sure the plaintext password doesn't get sent. 
    password.value = "";
 
    // Finally submit the form. 
    form.submit();
}



 
function regformhash(form, username, email, password, conf, user_type, fname, lname, position ) {
     // Check each field has a value
    if (username.value == ''         || 
          email.value == ''     || 
          password.value == ''  || 
          conf.value == '') {
 
        alert('You must provide all the requested details. Please try again');
        return false;
    }
 
    // Check the username
 
    re = /^\w+$/; 
    if(!re.test(form.username.value)) { 
        alert("Username must contain only letters, numbers and underscores. Please try again"); 
        form.username.focus();
        return false; 
    }
 
    // Check that the password is sufficiently long (min 6 chars)
    // The check is duplicated below, but this is included to give more
    // specific guidance to the user
    if (password.value.length < 6) {
        alert('Passwords must be at least 6 characters long.  Please try again');
        form.password.focus();
        return false;
    }
 
    // At least one number, one lowercase and one uppercase letter 
    // At least six characters 
 
    var re = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}/; 
    if (!re.test(password.value)) {
        alert('Passwords must contain at least one number, one lowercase and one uppercase letter.  Please try again');
        return false;
    }
 
    // Check password and confirmation are the same
    if (password.value != conf.value) {
        alert('Your password and confirmation do not match. Please try again');
        form.password.focus();
        return false;
    }
 
    // Create a new element input, this will be our hashed password field. 
    var p = document.createElement("input");
 
    // Add the new element to our form. 
    form.appendChild(p);
    p.name = "p";
    p.type = "hidden";
    p.value = hex_sha512(password.value);
 
    // Finally submit the form. 
    //form.submit();
    submitForm(username.value, email.value, p.value, position.value, user_type.value, fname.value, lname.value);
    // Make sure the plaintext password doesn't get sent. 
    
    //password.value = "";
    //conf.value = "";
    return true;
}

function submitForm(username, email, password, position, user_type, fname, lname)
{
    if (window.XMLHttpRequest) { 
        xmlhttp3 = new XMLHttpRequest();
        } else { 
            xmlhttp3 = new ActiveXObject("Microsoft.XMLHTTP");
        }
          xmlhttp3.onreadystatechange=function() {
            if (xmlhttp3.readyState==4 && xmlhttp3.status==200) {
               var x = xmlhttp3.responseText;
               if(x=='1111'){
                    window.location.href = 'register_success.php';
               } else {
                    document.getElementById('alertDiv').innerHTML= x;
               }

            }
          }
          
       var queryString = "?username="+username;
           queryString += "&email="+email;
           queryString += "&password="+password;
           queryString += "&position="+position;
           queryString += "&user_type="+user_type;
           queryString += "&fname="+fname;
           queryString += "&lname="+lname;

       xmlhttp3.open("GET","includes/register.inc.php"+queryString,true);
       xmlhttp3.send();
}