<?php 
include '../connection/config.php';

if(isset($_POST['securityBtn']))
{
	$old_pass=$_POST['curPass'];
	$new_pass=$_POST['newPass'];
	$conf_pass=$_POST['confPass'];

	if($new_pass!=$conf_pass)
	{
		echo '<script>alert("Passwords did not matched.");</script>';
		echo '<script>window.location.href="../homepage/profile.php";</script>';
	}
	else
	{
		if(isset($_COOKIE['user_id']))
		{
			$id = $_COOKIE['user_id'];

			$matchpass = "SELECT password FROM tbl_users WHERE id='".$id."' ";
			if( $respass = mysqli_query($mysqli,$matchpass))
			{
				$row_pass = mysqli_fetch_array($respass);
				$db_password = $row_pass['password'];

				//has the entered old password and compare it to the hashed dbpassword
				$old_pass = hash('sha512', $old_pass);

				//if old password match with dbpassword, update new password 
				if($old_pass==$db_password)
				{
					//hash the new password and insert it to the databse
					$new_hpassword = hash('sha512', $new_pass);
					$update_profile = "UPDATE tbl_users SET password = '".$new_hpassword."' WHERE id='".$id."' ";
					if(mysqli_query($mysqli,$update_profile) )
					{
						$new_hpassword2 = hash('sha512', $new_hpassword);
	                    setcookie('login_string', $new_hpassword2, time() + (86400), "/"); 

	                    echo '<script>alert("Password Successully Updated!");</script>';
						echo '<script>window.location.href="../homepage/profile.php";</script>';
					}
					else 
					{
						echo '<script>alert("Unable to update password.");</script>';
						echo '<script>window.location.href="../homepage/profile.php";</script>';
					}
				}
				else
				{
					echo '<script>alert("Incorrect password.");</script>';
					echo '<script>window.location.href="../homepage/profile.php";</script>';
				}

			}

			

		}
	}

	
}
else
{
	header('Location: ../homepage/profile.php');
}


mysqli_close($mysqli);
?>