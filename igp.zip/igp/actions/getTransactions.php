<?php
	// Check connection
	include('../connection/config.php');
    if(isset($_GET['stud_id']))
    {
    	$where = 'WHERE t.stud_id = '.$_GET['stud_id'];
    }
    else{
    	$where = '';
    }
		
		$sql="SELECT *,(SELECT concat(fname, ' ',mname,' ',lname) FROM tbl_users u WHERE t.sold_by = u.id)AS sold_by FROM tbl_transactions t LEFT JOIN tbl_students s ON s.stud_id=t.stud_id ".$where." ORDER BY date_purchased DESC";

		$query=mysqli_query($mysqli,$sql)or die(mysqli_error($mysqli));
		$data=array();
		while($row=mysqli_fetch_array($query))
		{
			$data[] = array('trans_id' => $row['trans_id'], 
							'stud_no' => $row['stud_no'],
							'or_no' => $row['or_no'],
							'or_status' => $row['or_status'],
							'amount_payable' => $row['amount_payable'],
							'sold_by' => $row['sold_by'],
							'date_purchased' => $row['date_purchased']
							);
		}
	
	echo json_encode($data);

	mysqli_close($mysqli);
?>