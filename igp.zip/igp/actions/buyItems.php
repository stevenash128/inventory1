<?php 
include('../connection/config.php');
session_start();
$msg['msg'] = false;
if(isset($_SESSION['cartItems']))
{
	$data = $_SESSION['cartItems'];
	$stud_no = trim($_GET['stud_no']);

	$prep_stmt = "SELECT stud_id FROM tbl_students WHERE stud_no = ?";
    if ($stmt = $mysqli->prepare($prep_stmt)) 
    {
		$stmt->bind_param('s', $stud_no);
		$stmt->execute();
		$stmt->store_result();
		$stmt->bind_result($stud_id);
	    $stmt->fetch();
         
		if ($stmt->num_rows == 1) 
		{


			$query = "INSERT INTO tbl_transactions(stud_id, or_no, or_status, amount_payable, sold_by) VALUES (?,?,?,?,?)";
			if($stmt3 = $mysqli->prepare($query))
			{
				$stmt3->bind_param('sssss',$stud_id, $_GET['or_no'],  $_GET['or_status'],$_GET['amount_payable'], $_COOKIE['user_id']);
				if($stmt3->execute())
				{
					$id = $stmt3->insert_id;
					$msg['id'] = $id;
					$x = 0;
					foreach ($data as $key) 
					{
						$sResult = mysqli_query($mysqli,"SELECT (SELECT pob_id FROM tbl_po_books p WHERE p.book_id = b.book_id AND p.sold_qty < p.delivered_qty ORDER BY date_inserted DESC LIMIT 1) AS pob_id FROM tbl_books b WHERE book_id = ".$key['book_id']." ");
						$sRow = mysqli_fetch_array($sResult);
						$pob_id = $sRow['pob_id'];
						if($pob_id)
						{

							$query4 = "INSERT INTO tbl_book_purchases(trans_id, book_id, pob_id, purchase_qty,price_sold) VALUES (?,?,?,?,?)";
							if($stmt4 = $mysqli->prepare($query4))
							{
								$stmt4->bind_param('sssss', $id, $key['book_id'], $pob_id, $key['qty'],$key['lnu_price']);
								if($stmt4->execute())
								{
									$msg['msg'] = true;
								}
								else
								{
									$msg['msg'] = 'false:insert';
								}
							}
						}
					}

					if($msg['msg']==true){
						$_SESSION['cartItems'] = array();
					}

				}
				else
				{
					$msg['msg'] = 'false:insert';
				}


			}

		}
		elseif($stmt->num_rows > 1)
		{
			$msg['msg'] = 'multiple_stud_no';
		}
		else
		{
			$msg['msg'] = 'stud_no_not_found';
		}
	}

	echo json_encode($msg);

	
}
mysqli_close($mysqli);
 ?>