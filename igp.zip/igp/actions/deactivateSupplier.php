<?php 
include('../connection/config.php');

$msg['msg'] = false;
if(isset($_GET['sup_id']))
{
	$prep_stmt = "UPDATE tbl_suppliers SET status = ? WHERE sup_id = ?";
    if ($stmt = $mysqli->prepare($prep_stmt)) 
    {
    	if($_GET['status']=='active')
    	{
    		$newStat = 'deactivated';
    	}
    	else
    	{
    		$newStat = 'active';
    	}

		$stmt->bind_param('ss', $newStat, $_GET['sup_id']);
		if($stmt->execute())
		{
			$msg['msg'] = true;
		}
	}
	else
	{
		$msg['msg'] = 'error';
	}

	echo json_encode($msg);

	
}
mysqli_close($mysqli);
 ?>