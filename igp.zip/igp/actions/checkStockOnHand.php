<?php 

function checkStockOnHand($book_id,$qty)
{
	include '../connection/config.php';
	$no = false;
	$prep_stmt = "SELECT (SELECT SUM(sold_qty) from tbl_po_books pbks WHERE pbks.book_id = b.book_id) AS sold_qty, (SELECT SUM(delivered_qty) from tbl_po_books pb WHERE pb.book_id = b.book_id) AS total_count FROM tbl_books b WHERE book_id = ? LIMIT 1";
    if ($stmt = $mysqli->prepare($prep_stmt)) 
    {
		$stmt->bind_param('s', $book_id);
		$stmt->execute();
		$stmt->store_result();
		$stmt->bind_result($sold_qty, $total_count);
        $stmt->fetch();
         
		if ($stmt->num_rows == 1) 
		{
			$stock_on_hand = $total_count - $sold_qty;
			if($qty <= $stock_on_hand){
				$no = true;
			}
		}
	}
	return $no;
}


 ?>