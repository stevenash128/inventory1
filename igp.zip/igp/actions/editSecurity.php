<?php 
include '../connection/config.php';

$msg['msg'] = false;
if(isset($_GET['id']))
{
	$password = $_GET['password'];
	$conf_password = $_GET['conf_password'];
	$id = $_GET['id'];

	if($password != $conf_password)
	{
		$msg['msg'] = 'not_matched';
	}
	else
	{
		$new_hpassword = hash('sha512', $password);

		$query = "UPDATE tbl_users SET password = ? WHERE id = ?";
		$stmtU = $mysqli->prepare($query);
		$stmtU->bind_param('ss', $new_hpassword, $id);
		
		if($stmtU->execute())
		{
			$msg['msg'] = true;
		}

	}

	
}

echo json_encode($msg);



mysqli_close($mysqli);

 ?>