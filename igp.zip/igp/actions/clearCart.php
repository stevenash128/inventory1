<?php 
session_start();

	$_SESSION['cartItems'] = array();
		
	if(count($_SESSION['cartItems'])==0){
		$msg['msg'] = true;
	}else{
		$msg['msg'] = false;
	}

	echo json_encode($msg);

 ?>