<?php 
	include('../connection/config.php');

	if(isset($_POST['btnPersonal']))
	{
		$fname = filter_input(INPUT_POST, 'fname', FILTER_SANITIZE_STRING);
		$lname = filter_input(INPUT_POST, 'lname', FILTER_SANITIZE_STRING);
		$mname = filter_input(INPUT_POST, 'mname', FILTER_SANITIZE_STRING);
		
		$fname = ucwords(trim($fname));
		$lname = ucwords(trim($lname));
		$mname = ucwords(trim($mname));

		$query = "UPDATE tbl_users SET fname = ?, mname = ?, lname = ?, sex = ?, email = ? WHERE id = ?";
		if($stmtU = $mysqli->prepare($query))
		{
			$stmtU->bind_param('ssssss', $fname, $mname, $lname, $_POST['sex'], $_POST['email'], $_COOKIE['user_id']);
			if($stmtU->execute())
			{
				$fullname = $fname.' '.$mname.' '.$lname;

				setcookie('fullname', $fullname, time() + (86400), "/");

				echo '<script>alert("Successully Updated!");</script>';
				echo '<script>window.location.href="../homepage/profile.php";</script>';
			}
			else
			{
				echo '<script>alert("Unable to update");</script>';
				echo '<script>window.location.href="../homepage/profile.php";</script>';
			}

		}
		else
		{
			echo '<script>window.location.href="../homepage/profile.php";</script>';
		}

	}
	else
	{
		//echo '<script>window.location.href="../homepage/profile.php";</script>';
	}
	mysqli_close($mysqli);
?>