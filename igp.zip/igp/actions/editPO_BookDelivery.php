<?php 
include('../connection/config.php');

$msg['msg'] = false;
if(isset($_GET['pob_id']))
{
	$go = false;
	$prep_stmt = "SELECT book_id FROM tbl_books WHERE barcode_no = ?";
    if ($stmt = $mysqli->prepare($prep_stmt))
    {
		$stmt->bind_param('s', $_GET['barcode_no']);
		$stmt->execute();
		$stmt->store_result();
		$stmt->bind_result($book_id);
        $stmt->fetch();
         
		if ($stmt->num_rows == 0) 
		{
			$go = true;
		}
		elseif($stmt->num_rows == 1)
		{
			if($_GET['book_id']==$book_id)
			{
        		$go = true;
        	}
        	else
        	{
        		$msg['msg'] = 'barcode_duplicate';
        	}
		}
		else
		{
			$msg['msg'] = 'duplicate';
		}

		if($go==true)
		{
			$query = "UPDATE tbl_po_books SET delivered_qty = ?, pob_lnu_price = ? WHERE pob_id = ?";
			if($stmtU = $mysqli->prepare($query))
			{
				$stmtU->bind_param('sss', $_GET['delivered_qty'], $_GET['pob_lnu_price'], $_GET['pob_id']);
				if($stmtU->execute())
				{
					if(mysqli_query($mysqli,"UPDATE tbl_books SET barcode_no = ".$_GET['barcode_no']." WHERE book_id = ".$_GET['book_id']." "))
					{

					}

					//company_price = ".$_GET['company_price'].", lnu_price =".$_GET['pob_lnu_price'].", 


					$msg['msg'] = true;
				}
			}
			else
			{
				$msg['msg'] = 'false: update';
			}

		}

	}



	
}

echo json_encode($msg);

mysqli_close($mysqli);
?>