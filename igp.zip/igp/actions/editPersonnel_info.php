<?php 
	include('../connection/config.php');

	$msg['msg'] = false;
	$go = false;
	if(isset($_GET['id']))
	{
		$prep_stmt = "SELECT id FROM tbl_users WHERE fname = ? AND lname = ? AND mname = ? ";
	    if ($stmt = $mysqli->prepare($prep_stmt))
	    {
			$stmt->bind_param('sss', $_GET['fname'], $_GET['lname'], $_GET['mname']);
			$stmt->execute();
			$stmt->store_result();
			$stmt->bind_result($id);
	        $stmt->fetch();
	         
			if ($stmt->num_rows == 0) 
			{
				$go = true;
			}
			elseif($stmt->num_rows == 1)
			{
				if($_GET['id']==$id)
				{
	        		$go = true;
	        	}
	        	else
	        	{
	        		$msg['msg'] = 'duplicate';
	        	}
			}
			else
			{
				$msg['msg'] = 'duplicate';
			}

			if($go==true)
			{

				$query = "UPDATE tbl_users SET fname = ?, mname = ?, lname = ?, sex = ?,user_type = ?, email = ? WHERE id = ?";
				if($stmtU = $mysqli->prepare($query))
				{
					$stmtU->bind_param('sssssss', $_GET['fname'], $_GET['mname'], $_GET['lname'], $_GET['sex'], $_GET['user_type'], $_GET['email'], $_GET['id']);
					if($stmtU->execute())
					{
						$msg['msg'] = true;
					}
				}
			}
		}
		else
		{
			$msg['msg'] = 'error';
		}

	echo json_encode($msg);
	}
	mysqli_close($mysqli);
?>