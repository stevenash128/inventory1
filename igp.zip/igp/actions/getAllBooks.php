<?php
	// Check connection
	include('../connection/config.php');
    if(isset($_GET['sup_id']))
    {
		$sql="SELECT * FROM tbl_books WHERE sup_id = ".$_GET['sup_id'];

		$query=mysqli_query($mysqli,$sql);
		$data=array();
		while($row=mysqli_fetch_array($query))
		{
			$data[] = array('book_id' => $row['book_id'], 
							'barcode_no' => $row['barcode_no'],
							'title' => $row['title'],
							'description' => $row['description'],
							'user_id' => $row['user_id'],
							'date_added' => $row['date_added'],
							'status' => $row['status']
							);
		}
	}
	echo json_encode($data);

	mysqli_close($mysqli);
?>