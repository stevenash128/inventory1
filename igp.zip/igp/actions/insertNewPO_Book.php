<?php 
include('../connection/config.php');

$msg['msg'] = false;

if(isset($_COOKIE['user_id']))
{
	$user_id = $_COOKIE['user_id'];

	if(isset($_GET['new_book_id']))
	{
		$prep_stmt = "SELECT * FROM tbl_po_books WHERE book_id = ? AND po_id = ?";
	    if ($stmt = $mysqli->prepare($prep_stmt)) 
	    {
			$stmt->bind_param('ss', $_GET['new_book_id'], $_GET['po_id']);
			$stmt->execute();
			$stmt->store_result();
	         
			if ($stmt->num_rows == 0) 
			{
				$query = "INSERT INTO tbl_po_books (po_id, book_id, pob_qty, pob_company_price, user_id_inserted) VALUES (?,?,?,?,?)";
				if($stmt3 = $mysqli->prepare($query))
				{
					$stmt3->bind_param('sssss',$_GET['po_id'], $_GET['new_book_id'], $_GET['new_qty'], $_GET['new_unit_cost'], $user_id);
					if($stmt3->execute())
					{
						$msg['msg'] = true;
					}
					else
					{
						$msg['msg'] = 'false:insert';
					}
				}
				else
				{
					$msg['msg'] = 'error_insert';
				}
			}
			else
			{
				$msg['msg'] = 'duplicate';
			}
		}
		else
		{
			$msg['msg'] = 'error';
		}

	}

}

echo json_encode($msg);

mysqli_close($mysqli);
 ?>