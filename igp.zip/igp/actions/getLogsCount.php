<?php
header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');

include('../connection/config.php');

$date = date("Y-m-d H:i:s", $_SERVER['REQUEST_TIME']);
$sql = "UPDATE tbl_users SET timelaps='$date' where id = '".$_COOKIE['user_id']."' LIMIT 1 ";
$query = mysqli_query($mysqli,$sql);

$count = 0;
if(isset($_COOKIE['user_id']))
{
	$stat = '';
	if($_COOKIE['user_type']=='rel_personnel'){
		$stat = 'AND method = "inserted_book" ';
	}

	$sql = "SELECT *,count FROM (SELECT *,(SELECT COUNT(id) FROM tbl_seen_logs s WHERE log_id=l.id AND user_id = ".$_COOKIE['user_id'].") as count FROM `tbl_logs` l) aa WHERE count = 0 ".$stat;

	//SELECT * FROM tbl_logs WHERE seen='no' ".$stat

	if($getDefered = mysqli_query($mysqli, $sql)) 
	{
	   $count = mysqli_num_rows($getDefered);
	}
}

echo "data: {$count}\n\n";
flush();

?>