<?php 
include('../connection/config.php');

$msg['msg'] = false;
if(isset($_GET['title']))
{
    
	$prep_stmt = "SELECT * FROM tbl_books WHERE title = ? AND sup_id = ?";
    if ($stmt = $mysqli->prepare($prep_stmt)) 
    {
		$stmt->bind_param('ss', $_GET['title'], $_GET['sup_id']);
		$stmt->execute();
		$stmt->store_result();
         
		if ($stmt->num_rows == 0) 
		{
			$query = "INSERT INTO tbl_books (title, description, book_yr_lvl, publisher, sup_id, user_id) VALUES (?,?,?,?,?,?)";
			if($stmt3 = $mysqli->prepare($query))
			{
				$stmt3->bind_param('ssssss', $_GET['title'], $_GET['description'],  $_GET['book_yr_lvl'],  $_GET['publisher'], $_GET['sup_id'], $_COOKIE['user_id']);
				if($stmt3->execute())
				{
					$msg['msg'] = true;
					$msg['id'] = $stmt3->insert_id;
				}
				else
				{
					$msg['msg'] = 'false:insert';
				}
			}
		}
		else
		{
			$msg['msg'] = 'duplicate';
		}

		
	}
	else
	{
		$msg['msg'] = 'error';
	}

	//print_r($stmt);

	echo json_encode($msg);

	
}
mysqli_close($mysqli);
 ?>