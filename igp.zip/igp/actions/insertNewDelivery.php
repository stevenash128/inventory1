<?php 
include('../connection/config.php');

$msg['msg'] = false;
if(isset($_GET['po_id']))
{

	$prep_stmt = "SELECT * FROM tbl_delivery WHERE po_id = ? AND dr_no = ?";
    if ($stmt = $mysqli->prepare($prep_stmt)) 
    {
		$stmt->bind_param('ss', $_GET['po_id'], $_GET['dr_no']);
		$stmt->execute();
		$stmt->store_result();
         
		if ($stmt->num_rows == 0) 
		{
			$query = "INSERT INTO tbl_delivery (po_id, dr_no, delivery_date, user_id_deliver) VALUES (?,?,?,?)";
			if($stmt3 = $mysqli->prepare($query))
			{

				$stmt3->bind_param('ssss', $_GET['po_id'], $_GET['dr_no'], $_GET['delivery_date'], $_COOKIE['user_id']);
				if($stmt3->execute())
				{
					$msg['msg'] = true;
				}
				else
				{
					$msg['msg'] = 'false:insert';
				}
			}
		}
		else
		{
			$msg['msg'] = 'duplicate';
		}

		
	}
	else
	{
		$msg['msg'] = 'error';
	}

	//print_r($stmt);

	echo json_encode($msg);

	
}
mysqli_close($mysqli);
 ?>