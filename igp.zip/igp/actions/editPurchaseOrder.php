<?php 
include('../connection/config.php');

$msg['msg'] = false;
$go = false;
if(isset($_GET['po_no']))
{
	$prep_stmt = "SELECT po_id FROM tbl_po WHERE po_no = ?";
    if ($stmt = $mysqli->prepare($prep_stmt))
    {
		$stmt->bind_param('s', $_GET['po_no']);
		$stmt->execute();
		$stmt->store_result();
		$stmt->bind_result($po_id);
        $stmt->fetch();
         
		if ($stmt->num_rows == 0) 
		{
			$go = true;
		}
		elseif($stmt->num_rows == 1)
		{
			if($_GET['po_id']==$po_id)
			{
        		$go = true;
        	}
        	else
        	{
        		$msg['msg'] = 'duplicate';
        	}
		}
		else
		{
			$msg['msg'] = 'duplicate';
		}

		if($go==true)
		{
			$query = "UPDATE tbl_po SET po_no = ?, date_receive = ?, sup_id = ? WHERE po_id = ?";
			if($stmtU = $mysqli->prepare($query))
			{
				$stmtU->bind_param('ssss', $_GET['po_no'], $_GET['date_receive'], $_GET['sup_id'], $_GET['po_id']);
				if($stmtU->execute())
				{
					$msg['msg'] = true;
				}
			}
		}
	}
	else
	{
		$msg['msg'] = 'error';
	}

	echo json_encode($msg);

	
}
mysqli_close($mysqli);
?>