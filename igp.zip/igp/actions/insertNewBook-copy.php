<?php 
include('../connection/config.php');

$msg['msg'] = false;
if(isset($_GET['title']))
{

	$prep_stmt = "SELECT * FROM tbl_books WHERE title = ?";
    if ($stmt = $mysqli->prepare($prep_stmt)) 
    {
		$stmt->bind_param('s', $_GET['title']);
		$stmt->execute();
		$stmt->store_result();
         
		if ($stmt->num_rows == 0) 
		{
			$query = "INSERT INTO tbl_books (barcode_no, title, description, book_yr_lvl, publisher, sup_id, company_price, lnu_price, status) VALUES (?,?,?,?,?,?,?,?,?)";
			if($stmt3 = $mysqli->prepare($query))
			{
				$stmt3->bind_param('sssssssss',$_GET['barcode_no'], $_GET['title'], $_GET['description'],  $_GET['book_yr_lvl'],  $_GET['publisher'], $_GET['sup_id'], $_GET['company_price'], $_GET['lnu_price'], $_GET['status']);
				if($stmt3->execute())
				{
					$msg['msg'] = true;
				}
				else
				{
					$msg['msg'] = 'false:insert';
				}
			}
		}
		else
		{
			$msg['msg'] = 'duplicate';
		}

		
	}
	else
	{
		$msg['msg'] = 'error';
	}

	//print_r($stmt);

	echo json_encode($msg);

	
}
mysqli_close($mysqli);
 ?>