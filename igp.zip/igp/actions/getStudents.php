<?php
	// Check connection
	include('../connection/config.php');

	$where = '';

	if(isset($_GET['search_txt'])){
		if($_GET['search_txt']  != '')
		{
			$search_txt = trim($_GET['search_txt']);
	        $search_txt = str_replace("'", "", $search_txt);
			$where = ' WHERE stud_no LIKE "%'.$search_txt.'%" OR fname LIKE "%'.$search_txt.'%" OR lname LIKE "%'.$search_txt.'%" OR mname LIKE "%'.$search_txt.'%" OR CONCAT(lname,", ",fname," ",mname," ",ext) LIKE "%'.$search_txt.'%" OR CONCAT(fname," ",lname) LIKE "%'.$search_txt.'%" OR yr_lvl LIKE "%'.$search_txt.'%" OR stud_status LIKE "%'.$search_txt.'%"' ;
		}
	}
	else if(isset($_GET['stud_id']))
	{
		$where = " WHERE stud_id='".$_GET['stud_id']."'";
	}
	else{
		$where = '';
	}

	

	$sql="SELECT *,CONCAT(lname,', ',fname,' ',mname,' ',ext) AS full_name FROM tbl_students ".$where;


	$query=mysqli_query($mysqli,$sql);
	$data=array();
	while($row=mysqli_fetch_array($query))
	{
		$data[] = array('stud_id' => $row['stud_id'], 
						'stud_no' => $row['stud_no'],
						'fname' => ucwords($row['fname']),
						'mname' => ucwords($row['mname']),
						'lname' => ucwords($row['lname']),
						'ext' => $row['ext'],
						'yr_lvl' => $row['yr_lvl'],
						'user_added' => $row['user_added'],
						'date_added' => $row['date_added'],
						'stud_status' => $row['stud_status'],
						'full_name'  => ucwords($row['full_name'])
						);
	}
	echo json_encode($data);

	mysqli_close($mysqli);
?>