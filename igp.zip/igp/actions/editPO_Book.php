<?php 
include('../connection/config.php');

$msg['msg'] = false;
$go = false;
if(isset($_GET['new_book_id']))
{
	$prep_stmt = "SELECT pob_id FROM tbl_po_books WHERE book_id = ? AND po_id = ?";
    if ($stmt = $mysqli->prepare($prep_stmt))
    {
		$stmt->bind_param('ss', $_GET['new_book_id'], $_GET['po_id']);
		$stmt->execute();
		$stmt->store_result();
		$stmt->bind_result($pob_id);
        $stmt->fetch();
         
		if ($stmt->num_rows == 0) 
		{
			$go = true;
		}
		elseif($stmt->num_rows == 1)
		{
			if($_GET['pob_id']==$pob_id)
			{
        		$go = true;
        	}
        	else
        	{
        		$msg['msg'] = 'duplicate';
        	}
		}
		else
		{
			$msg['msg'] = 'duplicate';
		}

		if($go==true)
		{
			$query = "UPDATE tbl_po_books SET book_id = ?, pob_qty = ?, pob_company_price = ? WHERE pob_id = ?";
			if($stmtU = $mysqli->prepare($query))
			{
				$stmtU->bind_param('ssss', $_GET['new_book_id'], $_GET['new_qty'], $_GET['new_unit_cost'], $_GET['pob_id']);
				if($stmtU->execute())
				{
					$msg['msg'] = true;
				}
			}
		}
	}
	else
	{
		$msg['msg'] = 'error';
	}

	echo json_encode($msg);

	
}
mysqli_close($mysqli);
?>