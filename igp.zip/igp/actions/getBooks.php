<?php
	// Check connection
	include('../connection/config.php');

	if(isset($_GET['search_txt']) != ''){
		$search_txt = trim($_GET['search_txt']);
        $search_txt = str_replace("'", "", $search_txt);
		$where = ' WHERE b.title LIKE "%'.$search_txt.'%" OR description LIKE "%'.$search_txt.'%"';
	}else{
		$where = '';
	}

	if(isset($_GET['barcode_no']))
	{
		$barcode_no = trim($_GET['barcode_no']);
        $barcode_no = str_replace("'", "", $barcode_no);
		$where = ' WHERE b.barcode_no = "'.$barcode_no.'" LIMIT 1';

		if($barcode_no=='')
		{
			exit;
		}
	}

	$sql="SELECT *, ppp.pob_lnu_price AS lnu_price, ppp.pob_company_price AS company_price, (SELECT SUM(sold_qty) from tbl_po_books pbks WHERE pbks.book_id = b.book_id) AS sold_qty, (SELECT s.name FROM tbl_suppliers s WHERE s.sup_id = b.sup_id)AS supplier, (SELECT SUM(delivered_qty) from tbl_po_books pb WHERE pb.book_id = b.book_id) AS total_count FROM `tbl_books` b LEFT JOIN tbl_po_books ppp ON ppp.book_id=b.book_id" .$where;

	$query=mysqli_query($mysqli,$sql);
	$data=array();
	while($row=mysqli_fetch_array($query))
	{
		$data[] = array('book_id' => $row['book_id'], 
						'barcode_no' => $row['barcode_no'],
						'title' => $row['title'],
						'description' => $row['description'],
						'publisher' => $row['publisher'],
						'company_price' => $row['company_price'],
						'lnu_price' => $row['lnu_price'],
						'user_id' => $row['user_id'],
						'date_added' => $row['date_added'],
						'status' => $row['status'],
						'total_count' => $row['total_count'],
						'sup_id' => $row['sup_id'],
						'supplier' => $row['supplier'],
						'sold_qty' => $row['sold_qty'],
						'book_yr_lvl' => $row['book_yr_lvl'],
						'stock_on_hand' => ($row['total_count'] - $row['sold_qty'])

						);
	}
	echo json_encode($data);

	mysqli_close($mysqli);
	//'po_id' => $row['po_id'],
?>