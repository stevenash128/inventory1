<?php
	// Check connection
	include('../connection/config.php');

	if($_GET['search_txt'] != ''){
		$search_txt = trim($_GET['search_txt']);
        $search_txt = str_replace("'", "", $search_txt);
		$where = ' WHERE s.name LIKE "%'.$search_txt.'%" OR p.po_no LIKE "%'.$search_txt.'%" OR EXTRACT(YEAR FROM date_receive) LIKE "%'.$search_txt.'%"';
	}else{
		$where = '';
	}
	//SELECT *, d.delivery_id FROM `tbl_po` po LEFT JOIN tbl_delivery d ON d.po_id = po.po_id
	$sql="SELECT *,p.po_id as pur_po_id, s.sup_id AS s_sup_id,
	      (SELECT delivery_date FROM tbl_delivery d WHERE p.po_id = d.po_id) AS delivered_date, 
	      (SELECT count(*) FROM tbl_delivery d WHERE p.po_id = d.po_id) AS count, 
	      (SELECT concat(fname,' ',lname) FROM tbl_users u WHERE u.id=p.user_id_receive) AS user_name_received,
          (SELECT concat(fname,' ',lname) FROM tbl_users u WHERE u.id=de.user_id_deliver) AS user_name_delivered 
	      FROM tbl_po p LEFT JOIN tbl_suppliers s ON s.sup_id = p.sup_id
          LEFT JOIN tbl_delivery de ON de.po_id = p.po_id ".$where." ORDER BY p.date_receive DESC";


	$query=mysqli_query($mysqli,$sql);
	$data=array();
	while($row=mysqli_fetch_array($query))
	{
		$data[] = array('sup_id' => $row['sup_id'], 
						'address' => $row['address'],
						'name' => $row['name'],
						'company_no' => $row['company_no'],
						'contact_no' => $row['contact_no'],
						'status' => $row['status'],
						'po_no' => $row['po_no'],
						'date_receive' => $row['date_receive'],
						'user_id_receive' => $row['user_id_receive'],
						'user_id_po' => $row['user_id_po'],
						'user_name_received' => $row['user_name_received'],
						'po_id' => $row['pur_po_id'],
						'delivered_date' => $row['delivered_date'],
						'count' => $row['count'],
						'dr_no' => $row['dr_no'],
						'user_name_delivered' => $row['user_name_delivered']
						);
	}
	echo json_encode($data);

	mysqli_close($mysqli);
?>