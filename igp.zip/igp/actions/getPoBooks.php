<?php
	// Check connection
	include('../connection/config.php');

	$data=array();
	if(isset($_GET['po_id']))
	{
		$po_id = $_GET['po_id'];

		$sql="SELECT *,p.po_id AS po_id FROM tbl_po_books p LEFT JOIN tbl_books b ON b.book_id = p.book_id WHERE p.po_id = ".$po_id;

		$query=mysqli_query($mysqli,$sql)or die(mysqli_error($mysqli));
		
		while($row=mysqli_fetch_array($query))
		{
			$data[] = array('book_id' => $row['book_id'], 
							'barcode_no' => $row['barcode_no'],
							'title' => $row['title'],
							'description' => $row['description'],
							'pob_qty' => $row['pob_qty'],
							'company_price' => $row['pob_company_price'],
							'po_id' => $row['po_id'],
							'user_id' => $row['user_id'],
							'date_added' => $row['date_added'],
							'status' => $row['status'],
							'pob_id' => $row['pob_id'],
							'pob_lnu_price' => $row['pob_lnu_price'],
							'delivered_qty' => $row['delivered_qty']
							);
		}
	}
	echo json_encode($data);

	mysqli_close($mysqli);
?>