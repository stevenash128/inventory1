<?php
	include '../connection/config.php';
	$username = $_COOKIE['username'];
	if($mysqli->query("UPDATE tbl_users SET online_stat='0' WHERE username='$username' "))
	{
	    setcookie('username', $username, time() + (0), "/");
	    setcookie('login_string', $hashed_password, time() + (0), "/");
	    setcookie('user_type', $user_type, time() + (0), "/");
	    setcookie('fullname', $fullname, time() + (0), "/");
		header('Location: ../index.php');
	}

?>