<?php

require_once '../connection/config.php';
 
$error_msg = '';
$msg['msg'] = false;

if (isset($_GET['fname'])) 
{
	if($_GET['email']!=''){


    $prep_stmt = "SELECT id FROM tbl_users WHERE email = ? ";
    $stmt = $mysqli->prepare($prep_stmt);
 
   // check existing email  
    if ($stmt) {
        $stmt->bind_param('s', $_GET['email']);
        $stmt->execute();
        $stmt->store_result();
 
        if ($stmt->num_rows > 0) {
            // A user with this email address already exists
            $error_msg .= '<p>A user with this email address already exists.</p>';
   
            $msg['msg'] = 'email_dup';
            $stmt->close();
        }
    } else {
        $error_msg .= '<p class="error">Database error Line 39</p>';
        $stmt->close();
    }

    }

 
    // check existing username
    $prep_stmt = "SELECT id FROM tbl_users WHERE username = ? LIMIT 1";
    $stmt = $mysqli->prepare($prep_stmt);
 
    if ($stmt) {
        $stmt->bind_param('s', $_GET['username']);
        $stmt->execute();
        $stmt->store_result();
 
        	if ($stmt->num_rows == 1) 
        	{
                $msg['msg'] = 'username_dup';
                $error_msg .= '<p class="error">A user with this username already exists</p>';
                $stmt->close();
         	}
        } 
        else 
        {
            $error_msg .= '<p class="error">Database error line 55</p>';
            $stmt->close();
        }
   

    if (empty($error_msg)) 
    {
        // only the releasing personnel can have multiple users
        if($_GET['user_type']!='rel_personnel')
        {
            mysqli_query($mysqli,"UPDATE tbl_users SET active = 'no' WHERE user_type = '".$_GET['user_type']."' ");
        }
        
        

        $password = hash('sha512', $_GET['password']);

        $insert_stmt = $mysqli->prepare("INSERT INTO tbl_users (user_type, fname, lname, mname, sex, username, email, password) VALUES (?, ?, ?,?, ? , ?, ?, ?)");
        
        $insert_stmt->bind_param('ssssssss', $_GET['user_type'], $_GET['fname'], $_GET['lname'], $_GET['mname'], $_GET['sex'], $_GET['username'], $_GET['email'] , $password);

        if(! $insert_stmt->execute()) 
        {
            $msg['msg'] = 'false:insert';
        }
        else
        {
            $msg['msg'] = true;

            mysqli_query($mysqli,"INSERT INTO tbl_logs (username,method,description) VALUES('".$_COOKIE['username']."','registered','".$_GET['fname'].' '.$_GET['lname']."')");
        }
    }
    
}

echo json_encode($msg);

?>