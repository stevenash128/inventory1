<?php 
include('../connection/config.php'); 

if(isset($_COOKIE['username']))
{
	$wh = '';
	if(isset($_GET['from']) AND isset($_GET['to']) )
	{
		if($_GET['from']!='' OR $_GET['to'] == '')
		{
			$wh = "WHERE (date_log >= '".$_GET['from']." 00-00-00' AND date_log <= '". $_GET['to'] ." 24-00-00') ";
		}
	}

	$stat = '';$lStat = '';
	if($_COOKIE['user_type']=='rel_personnel')
	{
		$stat = " AND method = 'inserted_book' ";
		$lStat = " WHERE method = 'inserted_book' ";
	}

	$sql = "SELECT *,count FROM (SELECT *,(SELECT COUNT(id) FROM tbl_seen_logs s WHERE log_id=l.id AND user_id = ".$_COOKIE['user_id'].") as count FROM `tbl_logs` l) aa WHERE count = 0 ".$stat;
	//"SELECT count(*) AS count FROM tbl_logs WHERE seen = 'no' ".$stat
	$res = mysqli_query($mysqli,$sql);

	$totalCount = mysqli_num_rows($res); //$rCount['count'];

	while($rCount = mysqli_fetch_array($res))
	{
		mysqli_query($mysqli,"INSERT INTO tbl_seen_logs (log_id,user_id)VALUES('".$rCount['id']."','".$_COOKIE['user_id']."')");
	}



	$sql="SELECT l.id AS id, l.to_id AS to_id, l.details AS details, l.method AS method, l.insert_time AS insert_time, CONCAT(u.fname,' ', u.lname) AS user_name, CONCAT(s.fname,' ',s.lname) as stud_name FROM tbl_logs l LEFT JOIN tbl_users u ON u.id = l.user_id LEFT JOIN tbl_students s ON s.stud_id = l.to_id ".$lStat." ORDER BY id DESC LIMIT 10";
	$query1=mysqli_query($mysqli,$sql) or die(mysqli_error($mysqli));
	
	$data = array();
	while($row=mysqli_fetch_array($query1))
	{
		$data[] = array('method' => $row['method'], 
						'user_name' => $row['user_name'], 
						'stud_name' => $row['stud_name'], 
						'stud_id' => $row['to_id'], 
						'insert_time' => $row['insert_time'], 
						'details' => $row['details'], 
						'id' => $row['id']);
	}

	/*$sql2 = "UPDATE tbl_logs SET seen='yes'";
	mysqli_query($mysqli,$sql2);*/

	echo json_encode(array('log'=>$data,'count'=> $totalCount));
	
}

mysqli_close($mysqli);
?>	