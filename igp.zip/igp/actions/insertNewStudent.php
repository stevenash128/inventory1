<?php 
include('../connection/config.php');

$msg['msg'] = false;
if(isset($_GET['stud_no']))
{
	$fname = strip_tags($_GET['fname']);
	$lname = strip_tags($_GET['lname']);
	$mname = strip_tags($_GET['mname']);
	$ext = strip_tags($_GET['ext']);


	$prep_stmt = "SELECT * FROM tbl_students WHERE stud_no = ?";
    if ($stmt = $mysqli->prepare($prep_stmt)) 
    {
		$stmt->bind_param('s', $_GET['stud_no']);
		$stmt->execute();
		$stmt->store_result();
         
		if ($stmt->num_rows == 0) 
		{
			$query = "INSERT INTO tbl_students (stud_no, fname, lname, mname, ext, yr_lvl, stud_status, user_added) VALUES (?,?,?,?,?,?,?,?)";
			if($stmt3 = $mysqli->prepare($query))
			{
				$stmt3->bind_param('ssssssss', $_GET['stud_no'], $fname, $lname, $mname, $ext, $_GET['yr_lvl'], $_GET['stud_status'], $_COOKIE['user_id']);
				if($stmt3->execute())
				{
					$msg['msg'] = true;
				}
				else
				{
					$msg['msg'] = false;
				}
			}
			//$stmt3->close();
		}
		else
		{
			$msg['msg'] = 'duplicate';
		}

		
	}
	else
	{
		$msg['msg'] = 'error';
	}

	echo json_encode($msg);

	
}
mysqli_close($mysqli);
 ?>