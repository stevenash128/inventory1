<?php 
include('../connection/config.php');

$msg['msg'] = false;
$go = false;
if(isset($_GET['sup_id']))
{
	$prep_stmt = "SELECT sup_id, name FROM tbl_suppliers WHERE name = ?";
    if ($stmt = $mysqli->prepare($prep_stmt))
    {
		$stmt->bind_param('s', $_GET['name']);
		$stmt->execute();
		$stmt->store_result();
		$stmt->bind_result($sup_id, $name);
        $stmt->fetch();
         
		if ($stmt->num_rows == 0) 
		{
			$go = true;
		}
		elseif($stmt->num_rows == 1)
		{
			if($_GET['sup_id']==$sup_id)
			{
        		$go = true;
        	}
        	else
        	{
        		$msg['msg'] = 'duplicate';
        	}
		}
		else
		{
			$msg['msg'] = 'duplicate';
		}

		if($go==true)
		{
			$query = "UPDATE tbl_suppliers SET name = ?, address = ?, company_no = ? WHERE sup_id = ?";
			if($stmtU = $mysqli->prepare($query))
			{
				$stmtU->bind_param('ssss', $_GET['name'], $_GET['address'], $_GET['company_no'], $_GET['sup_id']);
				if($stmtU->execute())
				{
					$msg['msg'] = true;
				}
			}
		}
	}
	else
	{
		$msg['msg'] = 'error';
	}

	echo json_encode($msg);

	
}
mysqli_close($mysqli);
?>