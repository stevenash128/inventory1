
<?php

$filename = $_REQUEST['file'];
$mysqli = new mysqli("localhost","root","","dbigp");

// Temporary variable, used to store current query
$templine = '';
// Read in entire file
$lines = file('../data/'.$filename);
// Loop through each line
foreach ($lines as $line)
{
	// Skip it if it's a comment
	if (substr($line, 0, 2) == '--' || $line == '')
	    continue;

	// Add this line to the current segment
	$templine .= $line;
	// If it has a semicolon at the end, it's the end of the query
	$get_query_output = 0;
	if (substr(trim($line), -1, 1) == ';')
	{
	    // Perform the query
	   
	    $query = mysqli_query($mysqli,$templine);
	    // Reset temp variable to empty
	    if($query == true)
	    {
	    	echo "<script>alert('DB Restoration failed!');window.location = '../homepage/database.php'</script>";
	    	break;
	    }
	    else
	    {
	    	echo "<script>alert('Successfully restored ".$filename."');window.location = '../homepage/database.php'</script>";
	    	 $templine = '';
	    }
	   
	}

}

?>