<?php 
include('../connection/config.php');

$msg['msg'] = false;
$msg['id'] = 0;
if(isset($_GET['po_no']))
{
	$prep_stmt = "SELECT * FROM tbl_po WHERE po_no = ?";
    if ($stmt = $mysqli->prepare($prep_stmt)) 
    {
		$stmt->bind_param('s', $_GET['po_no']);
		$stmt->execute();
		$stmt->store_result();
         
		if ($stmt->num_rows == 0) 
		{
			$query = "INSERT INTO tbl_po (po_no, date_receive, sup_id, user_id_receive) VALUES (?,?,?,?)";
			if($stmt3 = $mysqli->prepare($query))
			{
				$user_id = '';
				if(isset($_COOKIE['user_id'])){
					$user_id = $_COOKIE['user_id'];
				}
				$stmt3->bind_param('ssss', $_GET['po_no'], $_GET['date_receive'], $_GET['sup_id'], $user_id);
				if($stmt3->execute())
				{
					$msg['msg'] = true;
					$msg['id'] = $stmt3->insert_id;
				}
				else
				{
					$msg['msg'] = false;
				}
			}
			//$stmt3->close();
		}
		else
		{
			$msg['msg'] = 'duplicate';
		}

		
	}
	else
	{
		$msg['msg'] = 'error';
	}

	echo json_encode($msg);

	
}
mysqli_close($mysqli);
 ?>