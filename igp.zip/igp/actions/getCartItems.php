<?php 
session_start();

if(isset($_SESSION['cartItems']))
{
	$data = $_SESSION['cartItems'];
}else{
	$data = array();
}
echo json_encode($data);

 ?>