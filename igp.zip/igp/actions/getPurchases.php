<?php
	// Check connection
	include('../connection/config.php');

	/*if($_GET['search_txt'] != ''){
		$search_txt = trim($_GET['search_txt']);
        $search_txt = str_replace("'", "", $search_txt);
		$where = ' WHERE b.title LIKE "%'.$search_txt.'%" OR description LIKE "%'.$search_txt.'%"';
	}else{
		$where = '';
	}*/

	$sql="SELECT * FROM tbl_purchases ";

	$query=mysqli_query($mysqli,$sql);
	$data=array();
	while($row=mysqli_fetch_array($query))
	{
		$data[] = array('book_id' => $row['book_id'], 
						'barcode_no' => $row['barcode_no'],
						'title' => $row['title'],
						'description' => $row['description'],
						'qty' => $row['qty'],
						'company_price' => $row['company_price'],
						'lnu_price' => $row['lnu_price'],
						'user_id' => $row['user_id'],
						'date_added' => $row['date_added'],
						'status' => $row['status'],
						'total_count' => $row['total_count']
						);
	}
	echo json_encode($data);

	mysqli_close($mysqli);
	//'po_id' => $row['po_id'],
?>