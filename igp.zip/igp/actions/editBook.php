<?php 
include('../connection/config.php');

$msg['msg'] = false;
$go = false;
if(isset($_GET['book_id']))
{
		$barcode_no = trim($_GET['barcode_no']);

		if($barcode_no != '')
		{
			$prep_stmt2 = "SELECT book_id FROM tbl_books WHERE barcode_no = ?";
		    if ($stmt2 = $mysqli->prepare($prep_stmt2))
		    {
				$stmt2->bind_param('s', $barcode_no);
				$stmt2->execute();
				$stmt2->store_result();
				$stmt2->bind_result($book_id2);
		        $stmt2->fetch();
		         
				if ($stmt2->num_rows == 0)
				{
					$go = true;
				}
				elseif($stmt2->num_rows == 1)
				{
					if($_GET['book_id'] == $book_id2)
					{
		        		$go = true;
		        	}
		        	else
		        	{
		        		$go = false;
		        		$msg['msg'] = 'duplicate';
		        		$msg['details'] = 'Barcode No';
		        	}
				}
				else
				{
					$go = false;
					$msg['msg'] = 'duplicate';
				}
			}
			else
			{
				$go = false;
			}
	}
	else
	{
		$go = true;
	}

	if($go==true)
	{
		$prep_stmt = "SELECT book_id, title FROM tbl_books WHERE title = ? AND sup_id = ?";
	    if ($stmt = $mysqli->prepare($prep_stmt))
	    {
			$stmt->bind_param('ss', $_GET['title'], $_GET['sup_id']);
			$stmt->execute();
			$stmt->store_result();
			$stmt->bind_result($book_id, $title);
	        $stmt->fetch();
	         
			if ($stmt->num_rows == 0) 
			{
				$go = true;
			}
			elseif($stmt->num_rows == 1)
			{
				if($_GET['book_id']==$book_id)
				{
	        		$go = true;
	        	}
	        	else
	        	{
	        		$msg['msg'] = 'duplicate';
	        	}
			}
			else
			{
				$msg['msg'] = 'duplicate';
			}

			


			if($go==true) 
			{

				$query = "UPDATE tbl_books SET title = ?, description = ?, book_yr_lvl = ?, publisher = ?,sup_id = ?, status = ?, barcode_no = ? WHERE book_id = ?";
				if($stmtU = $mysqli->prepare($query))
				{
					//if($_GET['status'])
					$stmtU->bind_param('ssssssss', $_GET['title'], $_GET['description'], $_GET['book_yr_lvl'], $_GET['publisher'], $_GET['sup_id'], $_GET['status'], $_GET['barcode_no'], $_GET['book_id']);
					if($stmtU->execute())
					{
						$msg['msg'] = true;
					}
				}
			}
		}
		else
		{
			$msg['msg'] = 'error';
		}

	}

	echo json_encode($msg);

	
}
mysqli_close($mysqli);
?>