<?php 
include('../connection/config.php');

$msg['msg'] = false;
$go = false;
if(isset($_GET['stud_id']))
{
	$prep_stmt = "SELECT stud_id FROM tbl_students WHERE stud_no = ?";
    if ($stmt = $mysqli->prepare($prep_stmt))
    {
		$stmt->bind_param('s', $_GET['stud_no']);
		$stmt->execute();
		$stmt->store_result();
		$stmt->bind_result($stud_id);
        $stmt->fetch();
         
		if ($stmt->num_rows == 0) 
		{
			$go = true;
		}
		elseif($stmt->num_rows == 1)
		{
			if($_GET['stud_id']==$stud_id)
			{
        		$go = true;
        	}
        	else
        	{
        		$msg['msg'] = 'duplicate';
        	}
		}
		else
		{
			$msg['msg'] = 'duplicate';
		}

		if($go==true)
		{
			$query = "UPDATE tbl_students SET stud_no = ?, fname = ?, mname = ?, lname = ?, ext = ?, stud_status = ?, yr_lvl = ? WHERE stud_id = ?";
			if($stmtU = $mysqli->prepare($query))
			{
				//if($_GET['status'])
				$stmtU->bind_param('ssssssss', $_GET['stud_no'], $_GET['fname'], $_GET['mname'], $_GET['lname'], $_GET['ext'], $_GET['stud_status'], $_GET['yr_lvl'], $_GET['stud_id']);
				if($stmtU->execute())
				{
					$msg['msg'] = true;
				}
			}
		}
	}
	else
	{
		$msg['msg'] = 'error';
	}

	echo json_encode($msg);

	
}
mysqli_close($mysqli);
?>