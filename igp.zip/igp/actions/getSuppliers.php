<?php
	// Check connection
	include('../connection/config.php');

	$where = '';

	if(isset($_GET['search_txt']))
	{
		if($_GET['search_txt'] != '')
		{
			$search_txt = trim($_GET['search_txt']);
	        $search_txt = str_replace("'", "", $search_txt);
			$where = ' WHERE name LIKE "%'.$search_txt.'%"';
		}
	}
	

	$sql="SELECT * FROM tbl_suppliers ".$where;

	$query=mysqli_query($mysqli,$sql);
	$data=array();
	while($row=mysqli_fetch_array($query))
	{
		$data[] = array('sup_id' => $row['sup_id'], 
						'address' => $row['address'],
						'name' => $row['name'],
						'company_no' => $row['company_no'],
						'contact_no' => $row['contact_no'],
						'status' => $row['status']
						);
	}
	echo json_encode($data);

	mysqli_close($mysqli);
?>