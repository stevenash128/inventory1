<?php
	// Check connection
	include('../connection/config.php');
    if(isset($_GET['trans_id']))
    {
    	$where = 'WHERE bp.trans_id = '.$_GET['trans_id'];
    }
    else{
    	$where = '';
    }
		
		$sql="SELECT * FROM tbl_book_purchases bp LEFT JOIN tbl_po_books po ON po.pob_id = bp.pob_id LEFT JOIN tbl_books b ON po.book_id=b.book_id ".$where;

		$query=mysqli_query($mysqli,$sql)or die(mysqli_error($mysqli));
		$data=array();
		while($row=mysqli_fetch_array($query))
		{
			$data[] = array('purchase_id' => $row['purchase_id'], 
							'trans_id' => $row['trans_id'], 
							'title' => $row['title'],
							'description' => $row['description'],
							'barcode_no' => $row['barcode_no'],
							'purchase_qty' => $row['purchase_qty'],
							'price_sold' => $row['price_sold'],
							);
		}
	
	echo json_encode($data);

	mysqli_close($mysqli);
?>