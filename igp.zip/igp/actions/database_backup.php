<?php
include '../connection/config.php';

$tables = '*';

startBackUp($mysqli,$tables);

function startBackUp($mysqli,$tables)
{
    //$mysqli = new mysqli($dbData['host'], $dbData['username'], $dbData['password'], $dbData['database']); 

    if($tables == '*')
    {
        $tables = array();
        $result = $mysqli->query("SHOW TABLES");
        while($row = $result->fetch_row())
        {
            $tables[] = $row[0];
        }
    }
    else
    {
        $tables = is_array($tables)?$tables:explode(',',$tables);
    }

    $return = '';
    foreach($tables as $table)
    {
        $result = $mysqli->query("SELECT * FROM $table");
        $numColumns = $result->field_count;

        $result2 = $mysqli->query("SHOW CREATE TABLE $table");
        $row2 = $result2->fetch_row();

        $return .= "\n\n".$row2[1].";\n\n";

        for($i = 0; $i < $numColumns; $i++)
        {
            while($row = $result->fetch_row())
            {
                $return .= "INSERT INTO $table VALUES(";
                for($j=0; $j < $numColumns; $j++)
                {
                    $row[$j] = addslashes($row[$j]);
                   // $row[$j] = ereg_replace("\n","\\n",$row[$j]);
                    if (isset($row[$j])) { $return .= '"'.$row[$j].'"' ; } else { $return .= '""'; }
                    if ($j < ($numColumns-1)) { $return.= ','; }
                }

                $return .= ");\n";
            }
        }

        $return .= "\n\n\n";
    }
    $t=time();
    $dateTxt = date("Y-m-d", $_SERVER['REQUEST_TIME']);
    $dateTxt = date('F d, Y', strtoTime($dateTxt));
    $address = 'db_backup_'.$dateTxt.'_'.$t.'.sql';

    //save file
    $handle = fopen('../data/'.$address,'w+');
    fwrite($handle,$return);
    fclose($handle);

    if(mysqli_query($mysqli,"INSERT INTO tbl_logs(user_id,method,details)VALUES(".$_COOKIE['user_id'].",'back_up_db','$address')"))
    {
        header("location:../homepage/database.php");
    }

    

}

?>