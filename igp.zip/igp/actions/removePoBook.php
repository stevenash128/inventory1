<?php 
include('../connection/config.php');

$msg['msg'] = false;
if(isset($_GET['pob_id']))
{
	$prep_stmt = "DELETE FROM tbl_po_books WHERE pob_id = ?";
    if ($stmt = $mysqli->prepare($prep_stmt)) 
    {
		$stmt->bind_param('s', $_GET['pob_id']);
		if($stmt->execute())
		{
			$msg['msg'] = true;
		}
	}
	else
	{
		$msg['msg'] = 'error';
	}

	echo json_encode($msg);
}

mysqli_close($mysqli);
 ?>