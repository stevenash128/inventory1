<div class="row">
<?php 
include('../connection/config.php');
//$_GET['year'] = '2018';
if(isset($_GET['year']))
{
	$year = $_GET['year'];

	$book_count = 0;
	$booksQuery="SELECT *,((total_sold/total_delivered)*100) as percentage 
				FROM (SELECT SUM(delivered_qty) as total_delivered, 
                title, description, 
                barcode_no,
                b.book_id,
                t.date_purchased, 
		        SUM(pob.sold_qty) as total_sold
		        FROM tbl_po_books pob 
		        LEFT JOIN `tbl_book_purchases` bp ON bp.pob_id = pob.pob_id
		        LEFT JOIN tbl_books b ON pob.book_id = b.book_id
		        LEFT JOIN tbl_transactions t ON t.trans_id = bp.trans_id
		        GROUP BY b.book_id) aa WHERE EXTRACT(YEAR FROM date_purchased) = '$year' ORDER BY total_sold DESC";

		        //SUM(bp.purchase_qty) as total_sold
		        //
	if($result = mysqli_query($mysqli,$booksQuery)or die(mysqli_error($mysqli)))
	{
		echo '<div class="col-sm-6">';
			$count_type = mysqli_num_rows($result);
			while($row_type = mysqli_fetch_array($result))
			{
				$book_count++;
				$title = $row_type['title'];

				$delivered_qty = $row_type['total_delivered'];
				$sold_qty = $row_type['total_sold'];

				$percentage = 0;
				if($sold_qty!=0){
					$percentage = ($sold_qty / $delivered_qty) * 100;
				}
			
				?>
				<div class="progress-group">
	                 <span class="progress-text"><?php  echo $book_count.'. '.$title; ?></span>
	                 <span class="progress-number"><b><?php echo $sold_qty; ?></b>/<?php echo $delivered_qty; ?></span>

	                 <div class="progress sm">
	                   <div class="progress-bar progress-bar-blue" style="width: <?php echo $percentage; ?>%"></div>
	                 </div>
	            </div>
				<?php
			}
			if($book_count==0){
				echo '<span class="gray-me">No data found for year '.$year.'</span>';
			}
			echo '</div>';
			

		}



	}

mysqli_close($mysqli);

?>	
</div>