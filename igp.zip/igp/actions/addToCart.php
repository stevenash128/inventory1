<?php 
session_start();

include 'checkStockOnHand.php';

if(isset($_GET['book_id']))
{
	$row = array('book_id' => $_GET['book_id'], 'title' => $_GET['title'],'lnu_price' => $_GET['lnu_price'], 'qty' => 1);

	if(isset($_SESSION['cartItems']))
	{
		$data = $_SESSION['cartItems'];

		$tr = 0; $i = 0; $in = ''; 
		
		foreach ($data as $subKey) 
		{
			if($subKey['book_id'] == $_GET['book_id'])
			{
				$in = $i;
				$tr = 1;
				$nQty = $subKey['qty'] + 1;
			}
			$i++;
		}

		if($tr==1)
		{
			if(checkStockOnHand($_GET['book_id'],$nQty)==true)
			{
				$data[$in]['qty'] = $nQty;
			}
		}
		else
		{
			array_push($data, $row);
		}

		$_SESSION['cartItems'] = $data;
	}
	else
	{
		$cartData[] = $row;
		$_SESSION['cartItems'] = $cartData;
	}


}

echo json_encode($_SESSION['cartItems']);

 ?>