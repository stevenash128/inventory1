<?php 
session_start();

if(isset($_GET['index']))
{
	include 'checkStockOnHand.php';
	$book_id = $_SESSION['cartItems'][$_GET['index']]['book_id'];
	
	if(checkStockOnHand($book_id,$_GET['qty'])==true)
	{
		$_SESSION['cartItems'][$_GET['index']]['qty'] = $_GET['qty'];
	}
}

echo json_encode($_SESSION['cartItems']);

 ?>