<?php
	// Check connection
	include('../connection/config.php');

	$data=array();

	if(isset($_GET['po_id']))
	{
		$sql="SELECT *,s.sup_id AS s_sup_id, (SELECT concat(fname,' ',lname) FROM tbl_users u WHERE u.id=p.user_id_receive) AS user_name_received FROM `tbl_po` p LEFT JOIN tbl_suppliers s ON s.sup_id = p.sup_id WHERE p.po_id = ".$_GET['po_id'];

		$query=mysqli_query($mysqli,$sql) or die(mysqli_error($mysqli));
		
		while($row=mysqli_fetch_array($query))
		{
			$data[] = array('sup_id' => $row['sup_id'], 
							'address' => $row['address'],
							'name' => $row['name'],
							'company_no' => $row['company_no'],
							'contact_no' => $row['contact_no'],
							'status' => $row['status'],
							'po_no' => $row['po_no'],
							'date_receive' => $row['date_receive'],
							'user_id_receive' => $row['user_id_receive'],
							'user_id_po' => $row['user_id_po'],
							'user_name_received' => $row['user_name_received'],
							'po_id' => $row['po_id'],
							'delivered_date' => $row['delivered_date']
							);
		}
	}
	
	echo json_encode($data);

	mysqli_close($mysqli);
?>