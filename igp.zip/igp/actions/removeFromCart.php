<?php 

session_start();

	if(count($_SESSION['cartItems'])!=0){
		$msg['msg'] = true;
		$data = $_SESSION['cartItems'];
		unset($data[$_GET['index']]);

		$newData = array();
		foreach ($data as $key) {
			array_push($newData,array(
				'book_id'=>$key['book_id'],
				'title'=>$key['title'],
				'lnu_price'=>$key['lnu_price'],
				'qty'=>$key['qty']
				));
		}

		$_SESSION['cartItems'] = $newData ;

	}else{
		$msg['msg'] = false;
	}

	echo json_encode($msg);

 ?>