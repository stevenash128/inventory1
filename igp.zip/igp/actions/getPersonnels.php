<?php
	// Check connection
	include('../connection/config.php');

	if(isset($_GET['search_txt']) != ''){
		$search_txt = trim($_GET['search_txt']);
        $search_txt = str_replace("'", "", $search_txt);
		$where = ' WHERE fname LIKE "%'.$search_txt.'%" OR lname LIKE "%'.$search_txt.'%"';
	}else{
		$where = '';
	}

	$sql="SELECT *, concat(fname,' ', mname,' ', lname) as full_name FROM tbl_users " .$where;

	$query=mysqli_query($mysqli,$sql);
	$data=array();
	while($row=mysqli_fetch_array($query))
	{
		$data[] = array('id' => $row['id'], 
						'user_type' => $row['user_type'],
						'lname' => ucwords($row['lname']),
						'fname' => ucwords($row['fname']),
						'mname' => ucwords($row['mname']),
						'full_name' => ucwords($row['full_name']),
						'email' => $row['email'],
						'username' => $row['username'],
						'user_block' => $row['user_block'],
						'created_at' => $row['created_at'],
						'online_stat' => $row['online_stat'],
						'timelaps' => $row['timelaps'],
						'active' => $row['active'],
						'sex' => $row['sex']
						);
	}
	echo json_encode($data);

	mysqli_close($mysqli);
	//'po_id' => $row['po_id'],
?>