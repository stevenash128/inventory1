

CREATE TABLE `login_attempts` (
  `at_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `time` varchar(30) NOT NULL,
  PRIMARY KEY (`at_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO login_attempts VALUES("1","11","1518415075");
INSERT INTO login_attempts VALUES("2","14","1518832301");
INSERT INTO login_attempts VALUES("3","1","1518833490");





CREATE TABLE `tbl_book_purchases` (
  `purchase_id` int(11) NOT NULL AUTO_INCREMENT,
  `trans_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `pob_id` int(11) NOT NULL,
  `purchase_qty` int(11) NOT NULL,
  `price_sold` float NOT NULL,
  PRIMARY KEY (`purchase_id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=latin1;

INSERT INTO tbl_book_purchases VALUES("55","53","17","77","1","500");
INSERT INTO tbl_book_purchases VALUES("56","54","18","78","1","400");





CREATE TABLE `tbl_books` (
  `book_id` int(11) NOT NULL AUTO_INCREMENT,
  `barcode_no` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `book_yr_lvl` varchar(100) NOT NULL,
  `publisher` varchar(255) NOT NULL,
  `sup_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` enum('used','unused') NOT NULL DEFAULT 'used',
  `date_added` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`book_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

INSERT INTO tbl_books VALUES("1","190001","The little big star","Giving up is not easy","1st Year","phoenix","2","1","used","2018-02-02 22:41:52");
INSERT INTO tbl_books VALUES("2","1900021111","aaaaaaaaaaaa","bbbbbbbbbbbbb","Grade 3","phoenix","2","0","used","2018-02-02 23:17:03");
INSERT INTO tbl_books VALUES("3","1","ccc","desc cc","Grade 11","phoenix","2","0","used","2018-02-02 23:18:15");
INSERT INTO tbl_books VALUES("4","1900045","vbs","ddfs","Grade 11","lastico","24","0","used","2018-02-02 23:19:09");
INSERT INTO tbl_books VALUES("5","1900046","Korean Culture","Annyeong","Grade 11","thunder volt","1","0","used","2018-02-05 14:28:44");
INSERT INTO tbl_books VALUES("6","","In the woods","The statutory ","Grade 2","Philpost","1","0","used","2018-02-06 21:03:06");
INSERT INTO tbl_books VALUES("7","","asdfsdfsdf","sdfsdfs","Grade 11","asdfsdf","1","0","used","2018-02-06 22:14:16");
INSERT INTO tbl_books VALUES("8","19089881","Dulce et decurum es pro patrio more","It\'s sweet to die for once country","Grade 11","Phoenix","1","0","used","2018-02-10 08:26:34");
INSERT INTO tbl_books VALUES("9","","LKSDFJLK","SDKFJLK","Grade 1","LJKLSDFJSDF","2","0","used","2018-02-11 14:15:04");
INSERT INTO tbl_books VALUES("10","","new book","desc","Grade 3","Phoenix","2","0","used","2018-02-11 14:16:34");
INSERT INTO tbl_books VALUES("11","","Book 2","desc","Grade 1","osdfsldfkjsdf","2","0","used","2018-02-11 14:21:52");
INSERT INTO tbl_books VALUES("12","","sdf","sdfsdf","Grade 3","1212","2","0","used","2018-02-11 14:26:26");
INSERT INTO tbl_books VALUES("13","1908923","Descendants of the sun","dsf","Grade 9","Phoenix","2","0","used","2018-02-11 14:30:35");
INSERT INTO tbl_books VALUES("14","192039303","Hotel California","dkdsl","1st Year","Phoenix","2","1","used","2018-02-11 14:38:10");
INSERT INTO tbl_books VALUES("15","","Pluma","Ang wika","Grade 1","Phoenix","2","1","used","2018-02-11 14:45:23");
INSERT INTO tbl_books VALUES("16","19029202","Brezze","Desc","1st Year","Phoenix","30","1","used","2018-02-14 10:26:27");
INSERT INTO tbl_books VALUES("17","186979379039","EDUKASYON SA PAGPAPAKATAO 1","desc","Grade 10","Phoenix","2","14","used","2018-02-16 18:01:52");
INSERT INTO tbl_books VALUES("18","186979379040","GRAMMAR AND APPLICATION 10","none","Grade 10","Phoenix","2","14","used","2018-02-16 18:03:04");
INSERT INTO tbl_books VALUES("19","","Araling Panlipunan","NONE","Grade 8","Phoenix","2","14","used","2018-02-16 18:06:45");





CREATE TABLE `tbl_delivery` (
  `delivery_id` int(11) NOT NULL AUTO_INCREMENT,
  `po_id` int(11) NOT NULL,
  `dr_no` varchar(255) NOT NULL,
  `delivery_date` date NOT NULL,
  `user_id_deliver` int(11) NOT NULL,
  `date_input` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`delivery_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

INSERT INTO tbl_delivery VALUES("33","32","25794 (GT)","2017-11-05","1","2018-02-16 18:15:24");





CREATE TABLE `tbl_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `to_id` int(11) NOT NULL,
  `method` varchar(100) NOT NULL,
  `details` varchar(255) NOT NULL,
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `seen` enum('yes','no') NOT NULL DEFAULT 'no',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=latin1;

INSERT INTO tbl_logs VALUES("79","14","0","inserted_book","17","2018-02-16 18:01:52","yes");
INSERT INTO tbl_logs VALUES("80","14","0","inserted_book","18","2018-02-16 18:03:04","yes");
INSERT INTO tbl_logs VALUES("82","1","0","delivered","33","2018-02-16 18:15:24","yes");
INSERT INTO tbl_logs VALUES("91","1","11","stud_insert","","2018-02-16 18:31:21","yes");
INSERT INTO tbl_logs VALUES("92","11","1","sold","53","2018-02-16 19:57:34","yes");
INSERT INTO tbl_logs VALUES("93","11","6","sold","54","2018-02-17 14:14:41","yes");
INSERT INTO tbl_logs VALUES("94","1","0","back_up_db","","2018-02-17 20:43:06","yes");
INSERT INTO tbl_logs VALUES("95","1","0","back_up_db","../data/db_backup_February 18, 2018_1518929395.sql","2018-02-17 20:49:55","yes");





CREATE TABLE `tbl_po` (
  `po_id` int(11) NOT NULL AUTO_INCREMENT,
  `sup_id` int(11) NOT NULL,
  `po_no` varchar(255) NOT NULL,
  `date_receive` date NOT NULL,
  `user_id_receive` int(11) NOT NULL,
  `user_id_po` int(11) NOT NULL,
  `po_status` enum('received','delivered') NOT NULL DEFAULT 'received',
  `insert_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`po_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

INSERT INTO tbl_po VALUES("32","2","17-05-0012","2017-08-05","14","0","received","2018-02-16 18:00:29");
INSERT INTO tbl_po VALUES("33","2","1090-202-90","2018-02-16","1","0","received","2018-02-16 19:18:28");





CREATE TABLE `tbl_po_books` (
  `pob_id` int(11) NOT NULL AUTO_INCREMENT,
  `po_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `pob_qty` int(11) NOT NULL,
  `pob_company_price` float NOT NULL,
  `delivered_qty` int(11) NOT NULL,
  `pob_lnu_price` float NOT NULL,
  `sold_qty` int(11) NOT NULL,
  `user_id_inserted` int(11) NOT NULL,
  `date_inserted` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pob_id`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=latin1;

INSERT INTO tbl_po_books VALUES("77","32","17","40","417","40","500","1","14","2018-02-16 18:02:18");
INSERT INTO tbl_po_books VALUES("78","32","18","45","340","45","400","1","14","2018-02-16 18:04:32");
INSERT INTO tbl_po_books VALUES("79","33","1","100","130","0","0","0","1","2018-02-16 19:36:00");





CREATE TABLE `tbl_students` (
  `stud_id` int(11) NOT NULL AUTO_INCREMENT,
  `stud_no` int(11) NOT NULL,
  `fname` varchar(200) NOT NULL,
  `mname` varchar(200) NOT NULL,
  `lname` varchar(200) NOT NULL,
  `ext` varchar(100) NOT NULL,
  `yr_lvl` varchar(100) NOT NULL,
  `user_added` int(11) NOT NULL,
  `date_added` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `stud_status` enum('active','inactive') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`stud_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO tbl_students VALUES("1","1301510","Bruno","Mars","Balle","","1st Year","1","2018-02-04 23:59:41","active");
INSERT INTO tbl_students VALUES("2","1301511","Christopher","Chui","Cruz","","1st Year","0","2018-02-05 00:43:29","active");
INSERT INTO tbl_students VALUES("3","1301512","Janessa","","Blake","","Grade 3","0","2018-02-16 18:19:56","active");
INSERT INTO tbl_students VALUES("4","1301513","Ivy","","Aguas","","Grade 4","0","2018-02-16 18:20:41","active");
INSERT INTO tbl_students VALUES("5","1301514","Hardley","","Park","","Grade 5","0","2018-02-16 18:21:09","active");
INSERT INTO tbl_students VALUES("6","1301516","Emerson ","","Azucena","","Grade 6","0","2018-02-16 18:21:45","active");
INSERT INTO tbl_students VALUES("7","1301517","June Dale","","Asis","","Grade 1","0","2018-02-16 18:22:30","active");
INSERT INTO tbl_students VALUES("8","1301518","Chris","","Villanueva","","Grade 2","0","2018-02-16 18:23:16","active");
INSERT INTO tbl_students VALUES("9","1301519","Precious","","Supe","","Grade 3","0","2018-02-16 18:26:23","active");
INSERT INTO tbl_students VALUES("10","1301520","Jong Suk","","Lee","","Grade 6","1","2018-02-16 18:28:55","active");
INSERT INTO tbl_students VALUES("11","1301521","Rose Anne","","Yocte","","Grade 6","1","2018-02-16 18:31:21","active");





CREATE TABLE `tbl_suppliers` (
  `sup_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `contact_no` varchar(200) NOT NULL,
  `company_no` varchar(100) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date_registered` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('active','deactivated') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`sup_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

INSERT INTO tbl_suppliers VALUES("1","VRCS","Brgy. Catinco","098735633","1111","0","2018-02-01 21:52:57","active");
INSERT INTO tbl_suppliers VALUES("2","VICARISH PUBLICATION ","1946-A F. Torres corner Diamante Ext, Sta. Ana, Manila","3232323
","5648318","0","2018-02-01 21:52:57","active");
INSERT INTO tbl_suppliers VALUES("23","Justine Company","Real St. Tacloban city","","0908189290","0","2018-02-02 21:03:29","active");
INSERT INTO tbl_suppliers VALUES("24","thoers","block 1","","9122333","0","2018-02-02 21:04:40","active");
INSERT INTO tbl_suppliers VALUES("25","ABCD company","Tacloban City","","888678897","0","2018-02-08 12:31:07","active");
INSERT INTO tbl_suppliers VALUES("26","abyy company","San Isidro,Leyte","","9802389","0","2018-02-08 12:31:59","active");
INSERT INTO tbl_suppliers VALUES("27","kjsdflj","dfksj","","232323","0","2018-02-08 19:23:14","active");
INSERT INTO tbl_suppliers VALUES("28","sldkfjasdfkfj","asdf","","343432323","0","2018-02-08 19:26:32","active");
INSERT INTO tbl_suppliers VALUES("29","Sharmaine Company","sdkfjsf","","1212919212","0","2018-02-08 19:27:29","active");
INSERT INTO tbl_suppliers VALUES("30","Stiff\'s Company","Barangay Binaun","","901212","0","2018-02-08 19:29:43","active");
INSERT INTO tbl_suppliers VALUES("31","Supplier 1","Brgy, 212 paterno","","2147483647","0","2018-02-09 20:00:17","active");





CREATE TABLE `tbl_transactions` (
  `trans_id` int(11) NOT NULL AUTO_INCREMENT,
  `stud_id` int(11) NOT NULL,
  `or_no` varchar(255) NOT NULL,
  `or_status` enum('cash','promisory') NOT NULL,
  `amount_payable` float NOT NULL,
  `sold_by` int(11) NOT NULL,
  `date_purchased` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`trans_id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=latin1;

INSERT INTO tbl_transactions VALUES("53","1","","promisory","500","11","2018-02-16 19:57:34");
INSERT INTO tbl_transactions VALUES("54","6","","promisory","400","11","2018-02-17 14:14:41");





CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_type` varchar(100) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `mname` varchar(100) NOT NULL,
  `sex` enum('Male','Female') DEFAULT NULL,
  `email` varchar(30) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_block` tinyint(1) NOT NULL DEFAULT '0',
  `role_id` int(11) NOT NULL,
  `online_stat` tinyint(1) NOT NULL DEFAULT '0',
  `timelaps` datetime NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_ip` varchar(100) NOT NULL,
  `active` enum('yes','no') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

INSERT INTO tbl_users VALUES("1","system_admin","Alimangohan","Freddie","","Male","admin@gmail.com","admin","c7ad44cbad762a5da0a452f9e854fdc1e0e7a52a38015f23f3eab1d80b931dd472634dfac71cd34ebc35d16ab7fb8a90c81f975113d6c7538dc69dd8de9077ec","0","1","1","2018-02-18 05:51:35","2018-02-01 00:00:00","::1","yes");
INSERT INTO tbl_users VALUES("11","rel_personnel","Andoque","Sharm","","Female","","sharm","c7ad44cbad762a5da0a452f9e854fdc1e0e7a52a38015f23f3eab1d80b931dd472634dfac71cd34ebc35d16ab7fb8a90c81f975113d6c7538dc69dd8de9077ec","0","0","1","2018-02-17 23:19:03","2018-02-10 19:38:57","::1","yes");
INSERT INTO tbl_users VALUES("14","clerk","Cinco","Vryan","","Male","vryan@gmail.com","vryan","9917a61d34235f7d502d5c983830fc475c51714af189a7462437cfc8714c2d855ec63923ae232ce6b19a5e6ebf5fcdb9fd446342f82a1b05530dd804afd58160","0","0","0","2018-02-17 03:11:21","2018-02-16 17:51:20","::1","yes");



