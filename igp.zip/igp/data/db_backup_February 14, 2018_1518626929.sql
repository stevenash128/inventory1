-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 13, 2018 at 08:16 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbigp`
--

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `at_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `time` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_attempts`
--

INSERT INTO `login_attempts` (`at_id`, `user_id`, `time`) VALUES
(1, 11, '1518415075');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_books`
--

CREATE TABLE `tbl_books` (
  `book_id` int(11) NOT NULL,
  `barcode_no` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `book_yr_lvl` varchar(100) NOT NULL,
  `publisher` varchar(255) NOT NULL,
  `qty` int(11) NOT NULL,
  `lnu_price` float NOT NULL,
  `company_price` float NOT NULL,
  `sup_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` enum('used','unused') NOT NULL DEFAULT 'used',
  `date_added` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_books`
--

INSERT INTO `tbl_books` (`book_id`, `barcode_no`, `title`, `description`, `book_yr_lvl`, `publisher`, `qty`, `lnu_price`, `company_price`, `sup_id`, `user_id`, `status`, `date_added`) VALUES
(1, '190001', 'The little big star', 'kdsjflskfj', 'Grade 11', 'phoenix', 5, 120, 100, 2, 1, 'used', '2018-02-02 22:41:52'),
(2, '1900021111', 'aaaaaaaaaaaa', 'bbbbbbbbbbbbb', 'Grade 3', 'phoenix', 0, 150, 10, 2, 0, 'used', '2018-02-02 23:17:03'),
(3, '1', 'ccc', 'desc cc', 'Grade 11', 'phoenix', 0, 20, 0, 2, 0, 'used', '2018-02-02 23:18:15'),
(4, '1900045', 'vbs', 'ddfs', 'Grade 11', 'lastico', 0, 2323, 0, 24, 0, 'used', '2018-02-02 23:19:09'),
(5, '1900046', 'Korean Culture', 'Annyeong', 'Grade 11', 'thunder volt', 0, 200, 150, 1, 0, 'used', '2018-02-05 14:28:44'),
(6, '', 'In the woods', 'The statutory ', 'Grade 2', 'Philpost', 0, 150, 100, 1, 0, 'used', '2018-02-06 21:03:06'),
(7, '', 'asdfsdfsdf', 'sdfsdfs', 'Grade 11', 'asdfsdf', 0, 100, 10, 1, 0, 'used', '2018-02-06 22:14:16'),
(8, '19089881', 'Dulce et decurum es pro patrio more', 'It\'s sweet to die for once country', 'Grade 11', 'Phoenix', 0, 250, 100, 1, 0, 'used', '2018-02-10 08:26:34'),
(9, '', 'LKSDFJLK', 'SDKFJLK', 'Grade 1', 'LJKLSDFJSDF', 0, 0, 0, 2, 0, 'used', '2018-02-11 14:15:04'),
(10, '', 'new book', 'desc', 'Grade 3', 'Phoenix', 0, 0, 0, 2, 0, 'used', '2018-02-11 14:16:34'),
(11, '', 'Book 2', 'desc', 'Grade 1', 'osdfsldfkjsdf', 0, 0, 0, 2, 0, 'used', '2018-02-11 14:21:52'),
(12, '', 'sdf', 'sdfsdf', 'Grade 3', '1212', 0, 0, 0, 2, 0, 'used', '2018-02-11 14:26:26'),
(13, '1908923', 'Descendants of the sun', 'dsf', 'Grade 9', 'Phoenix', 0, 200, 200, 2, 0, 'used', '2018-02-11 14:30:35'),
(14, '', 'Hotel California', 'dkdsl', '1st Year', 'Phoenix', 0, 0, 0, 2, 1, 'used', '2018-02-11 14:38:10'),
(15, '', 'Pluma', 'Ang wika', 'Grade 1', 'Phoenix', 0, 0, 0, 2, 1, 'used', '2018-02-11 14:45:23');

--
-- Triggers `tbl_books`
--
DELIMITER $$
CREATE TRIGGER `onInsert` AFTER INSERT ON `tbl_books` FOR EACH ROW BEGIN
INSERT INTO tbl_logs(user_id, to_id, method,details) VALUES(new.user_id,'','inserted_book',new.book_id);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_book_purchases`
--

CREATE TABLE `tbl_book_purchases` (
  `purchase_id` int(11) NOT NULL,
  `trans_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `pob_id` int(11) NOT NULL,
  `purchase_qty` int(11) NOT NULL,
  `price_sold` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_book_purchases`
--

INSERT INTO `tbl_book_purchases` (`purchase_id`, `trans_id`, `book_id`, `pob_id`, `purchase_qty`, `price_sold`) VALUES
(32, 32, 1, 64, 1, 120),
(33, 33, 1, 71, 8, 120),
(34, 34, 13, 73, 1, 250),
(35, 35, 13, 73, 1, 250),
(36, 36, 13, 73, 1, 250),
(37, 37, 13, 73, 1, 250),
(38, 38, 13, 73, 1, 250),
(39, 40, 13, 73, 1, 250),
(40, 41, 13, 73, 1, 250),
(41, 42, 13, 73, 1, 250),
(42, 43, 13, 73, 1, 250),
(43, 44, 2, 72, 1, 150),
(44, 44, 13, 73, 2, 250),
(45, 45, 13, 73, 1, 250),
(46, 45, 2, 72, 1, 150),
(47, 46, 13, 73, 1, 250);

--
-- Triggers `tbl_book_purchases`
--
DELIMITER $$
CREATE TRIGGER `tbl_purhcesInsert` AFTER INSERT ON `tbl_book_purchases` FOR EACH ROW BEGIN
UPDATE tbl_po_books p SET p.sold_qty = p.sold_qty + new.purchase_qty WHERE p.pob_id = new.pob_id LIMIT 1;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_delivery`
--

CREATE TABLE `tbl_delivery` (
  `delivery_id` int(11) NOT NULL,
  `po_id` int(11) NOT NULL,
  `dr_no` varchar(255) NOT NULL,
  `delivery_date` date NOT NULL,
  `user_id_deliver` int(11) NOT NULL,
  `date_input` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_delivery`
--

INSERT INTO `tbl_delivery` (`delivery_id`, `po_id`, `dr_no`, `delivery_date`, `user_id_deliver`, `date_input`) VALUES
(30, 30, '81993933', '2018-02-11', 1, '2018-02-11 14:47:50');

--
-- Triggers `tbl_delivery`
--
DELIMITER $$
CREATE TRIGGER `onDelivery` AFTER INSERT ON `tbl_delivery` FOR EACH ROW BEGIN
INSERT INTO tbl_logs(user_id, method) VALUES(new.user_id_deliver,'delivered');
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_logs`
--

CREATE TABLE `tbl_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `to_id` int(11) NOT NULL,
  `method` varchar(100) NOT NULL,
  `details` varchar(255) NOT NULL,
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `seen` enum('yes','no') NOT NULL DEFAULT 'no'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_logs`
--

INSERT INTO `tbl_logs` (`id`, `user_id`, `to_id`, `method`, `details`, `insert_time`, `seen`) VALUES
(52, 1, 0, 'inserted_book', '14', '2018-02-11 22:38:10', 'yes'),
(53, 1, 0, 'inserted_book', '15', '2018-02-11 22:45:23', 'yes'),
(54, 1, 0, 'delivered', '', '2018-02-11 22:47:50', 'yes'),
(55, 11, 1301652, 'sold', '32', '2018-02-11 23:02:19', 'yes'),
(56, 11, 10000, 'sold', '33', '2018-02-12 05:40:04', 'yes'),
(57, 11, 10000, 'sold', '34', '2018-02-12 06:32:58', 'yes'),
(58, 11, 10000, 'sold', '35', '2018-02-12 06:34:40', 'yes'),
(59, 11, 10000, 'sold', '36', '2018-02-12 06:35:20', 'yes'),
(60, 11, 10000, 'sold', '37', '2018-02-12 06:37:22', 'yes'),
(61, 11, 10000, 'sold', '38', '2018-02-12 06:39:37', 'yes'),
(62, 11, 10000, 'sold', '39', '2018-02-12 06:40:35', 'yes'),
(63, 11, 10000, 'sold', '40', '2018-02-12 06:41:04', 'yes'),
(64, 11, 10000, 'sold', '41', '2018-02-12 06:41:40', 'yes'),
(65, 11, 10000, 'sold', '42', '2018-02-12 07:06:58', 'yes'),
(66, 11, 10000, 'sold', '43', '2018-02-12 07:12:58', 'yes'),
(67, 11, 10000, 'sold', '44', '2018-02-12 07:14:24', 'yes'),
(68, 11, 10000, 'sold', '45', '2018-02-12 07:45:19', 'yes'),
(69, 11, 10000, 'sold', '46', '2018-02-12 07:53:09', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_po`
--

CREATE TABLE `tbl_po` (
  `po_id` int(11) NOT NULL,
  `sup_id` int(11) NOT NULL,
  `po_no` varchar(255) NOT NULL,
  `date_receive` date NOT NULL,
  `user_id_receive` int(11) NOT NULL,
  `user_id_po` int(11) NOT NULL,
  `po_status` enum('received','delivered') NOT NULL DEFAULT 'received',
  `insert_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_po`
--

INSERT INTO `tbl_po` (`po_id`, `sup_id`, `po_no`, `date_receive`, `user_id_receive`, `user_id_po`, `po_status`, `insert_date`) VALUES
(30, 2, '09-09201', '2018-02-11', 1, 0, 'received', '2018-02-11 11:51:08');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_po_books`
--

CREATE TABLE `tbl_po_books` (
  `pob_id` int(11) NOT NULL,
  `po_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `pob_qty` int(11) NOT NULL,
  `pob_company_price` float NOT NULL,
  `delivered_qty` int(11) NOT NULL,
  `pob_lnu_price` float NOT NULL,
  `sold_qty` int(11) NOT NULL,
  `user_id_inserted` int(11) NOT NULL,
  `date_inserted` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_po_books`
--

INSERT INTO `tbl_po_books` (`pob_id`, `po_id`, `book_id`, `pob_qty`, `pob_company_price`, `delivered_qty`, `pob_lnu_price`, `sold_qty`, `user_id_inserted`, `date_inserted`) VALUES
(71, 30, 1, 100, 100, 8, 120, 8, 1, '2018-02-11 20:18:19'),
(72, 30, 2, 100, 10, 100, 150, 2, 1, '2018-02-11 20:50:14'),
(73, 30, 13, 150, 200, 150, 250, 13, 1, '2018-02-11 21:50:12');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_students`
--

CREATE TABLE `tbl_students` (
  `stud_id` int(11) NOT NULL,
  `stud_no` int(11) NOT NULL,
  `fname` varchar(200) NOT NULL,
  `mname` varchar(200) NOT NULL,
  `lname` varchar(200) NOT NULL,
  `ext` varchar(100) NOT NULL,
  `yr_lvl` varchar(100) NOT NULL,
  `user_added` int(11) NOT NULL,
  `date_added` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `stud_status` enum('active','inactive') NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_students`
--

INSERT INTO `tbl_students` (`stud_id`, `stud_no`, `fname`, `mname`, `lname`, `ext`, `yr_lvl`, `user_added`, `date_added`, `stud_status`) VALUES
(1, 1301652, 'Bruno', 'Mars', 'Balle', '', '1', 1, '2018-02-04 23:59:41', 'active'),
(2, 10000, 'Justine', 'Chui', 'Minez', '', '2', 0, '2018-02-05 00:43:29', 'active');

--
-- Triggers `tbl_students`
--
DELIMITER $$
CREATE TRIGGER `onInsertStud` BEFORE INSERT ON `tbl_students` FOR EACH ROW BEGIN
INSERT INTO tbl_logs(user_id, method) VALUES(new.user_added,'stud_insert');
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_suppliers`
--

CREATE TABLE `tbl_suppliers` (
  `sup_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `contact_no` varchar(200) NOT NULL,
  `company_no` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date_registered` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('active','deactivated') NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_suppliers`
--

INSERT INTO `tbl_suppliers` (`sup_id`, `name`, `address`, `contact_no`, `company_no`, `user_id`, `date_registered`, `status`) VALUES
(1, 'VRCS', 'Brgy. Catinco', '098735633', 1111, 0, '2018-02-02 05:52:57', 'active'),
(2, 'VICARISH PUBLICATION ', '1946-A F. Torres corner Diamante Ext, Sta. Ana, Manila', '3232323\r\n', 5648318, 0, '2018-02-02 05:52:57', 'active'),
(23, 'sdfjlj', 'sdfjlsdjfl', '', 232323, 0, '2018-02-03 05:03:29', 'active'),
(24, 'thoers', 'block 1', '', 9122333, 0, '2018-02-03 05:04:40', 'active'),
(25, 'ABCD company', 'Tacloban City', '', 888678897, 0, '2018-02-08 20:31:07', 'active'),
(26, 'abyy company', 'San Isidro,Leyte', '', 9802389, 0, '2018-02-08 20:31:59', 'active'),
(27, 'kjsdflj', 'dfksj', '', 232323, 0, '2018-02-09 03:23:14', 'active'),
(28, 'sldkfjasdfkfj', 'asdf', '', 343432323, 0, '2018-02-09 03:26:32', 'active'),
(29, 'Sharmaine Company', 'sdkfjsf', '', 1212919212, 0, '2018-02-09 03:27:29', 'active'),
(30, 'Stiff\'s Company', 'Barangay Binaun', '', 901212, 0, '2018-02-09 03:29:43', 'active'),
(31, 'Supplier 1', 'Brgy, 212 paterno', '', 2147483647, 0, '2018-02-10 04:00:17', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_transactions`
--

CREATE TABLE `tbl_transactions` (
  `trans_id` int(11) NOT NULL,
  `stud_no` int(11) NOT NULL,
  `or_no` varchar(255) NOT NULL,
  `or_status` enum('cash','promisory') NOT NULL,
  `amount_payable` float NOT NULL,
  `sold_by` int(11) NOT NULL,
  `date_purchased` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_transactions`
--

INSERT INTO `tbl_transactions` (`trans_id`, `stud_no`, `or_no`, `or_status`, `amount_payable`, `sold_by`, `date_purchased`) VALUES
(32, 1301652, '', 'promisory', 120, 11, '2018-02-11 15:02:19'),
(33, 10000, '', 'promisory', 960, 11, '2018-02-11 21:40:04'),
(34, 10000, '', 'promisory', 250, 11, '2018-02-11 22:32:58'),
(35, 10000, '', 'promisory', 250, 11, '2018-02-11 22:34:40'),
(36, 10000, '', 'promisory', 250, 11, '2018-02-11 22:35:20'),
(37, 10000, '', 'promisory', 250, 11, '2018-02-11 22:37:22'),
(38, 10000, '', 'promisory', 250, 11, '2018-02-11 22:39:37'),
(39, 10000, '', 'promisory', 250, 11, '2018-02-11 22:40:35'),
(40, 10000, '', 'promisory', 250, 11, '2018-02-11 22:41:04'),
(41, 10000, '', 'promisory', 250, 11, '2018-02-11 22:41:40'),
(42, 10000, '', 'promisory', 250, 11, '2018-02-11 23:06:58'),
(43, 10000, '', 'promisory', 250, 11, '2018-02-11 23:12:58'),
(44, 10000, '', 'promisory', 650, 11, '2018-02-11 23:14:24'),
(45, 10000, '', 'promisory', 400, 11, '2018-02-11 23:45:19'),
(46, 10000, '', 'promisory', 250, 11, '2018-02-11 23:53:09');

--
-- Triggers `tbl_transactions`
--
DELIMITER $$
CREATE TRIGGER `onpurchase` AFTER INSERT ON `tbl_transactions` FOR EACH ROW BEGIN
INSERT INTO tbl_logs(user_id, to_id, method,details) VALUES(new.sold_by,new.stud_no,'sold',new.trans_id);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL,
  `user_type` varchar(100) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `mname` varchar(100) NOT NULL,
  `sex` enum('Male','Female') DEFAULT NULL,
  `email` varchar(30) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_block` tinyint(1) NOT NULL DEFAULT '0',
  `role_id` int(11) NOT NULL,
  `online_stat` tinyint(1) NOT NULL DEFAULT '0',
  `timelaps` datetime NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_ip` varchar(100) NOT NULL,
  `active` enum('yes','no') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `user_type`, `lname`, `fname`, `mname`, `sex`, `email`, `username`, `password`, `user_block`, `role_id`, `online_stat`, `timelaps`, `created_at`, `user_ip`, `active`) VALUES
(1, 'system_admin', 'Alimangohan', 'Freddie', '', 'Male', 'admin@gmail.com', 'admin', 'c7ad44cbad762a5da0a452f9e854fdc1e0e7a52a38015f23f3eab1d80b931dd472634dfac71cd34ebc35d16ab7fb8a90c81f975113d6c7538dc69dd8de9077ec', 0, 1, 1, '2018-02-13 08:16:10', '2018-02-01 00:00:00', '::1', 'yes'),
(2, 'rel_personnel', 'Persona', 'Yur', '', 'Male', 'sm@gmail.com', 'one', '05f70341078acf6a06d423d21720f9643d5f953626d88a02636dc3a9e79582aeb0c820857fd3f8dc502aa8360d2c8fa97a985fda5b629b809cad18ffb62d3899', 0, 2, 0, '2018-02-05 07:58:32', '2018-02-01 00:00:00', '::1', 'no'),
(3, 'clerk', 'Persona', 'Yur', 'sdfsdf', 'Female', '', 'jane', '39a1e48814b369adbd86a5028e682b8f322120e9883bb416dcbbd6ca6d0ef4bd23534be430f0cdd0bf4d08b0ce38c0a852feca381e0a578cc29c41d0de3be25e', 1, 0, 0, '0000-00-00 00:00:00', '2018-02-10 13:01:29', '', 'no'),
(4, 'clerk', 'Mith', 'Justin', '', 'Male', '', 'justin123', '2d2b99036a70620bda32d472495944696e179a433088b527d2a4668d520b1145d6cf0dd550662cc08538166c506e6712c57138465a8a9ad988bc62b3425dd93f', 1, 0, 0, '0000-00-00 00:00:00', '2018-02-10 13:43:15', '', 'no'),
(6, 'clerk', 'sdf', 'sdfs', 'sdf', 'Male', '', 'jkl', '3c9909afec25354d551dae21590bb26e38d53f2173b8d3dc3eee4c047e7ab1c1eb8b85103e3be7ba613b31bb5c9c36214dc9f14a42fd7a2fdb84856bca5c44c2', 1, 0, 0, '0000-00-00 00:00:00', '2018-02-10 13:48:37', '', 'no'),
(7, 'clerk', 'Alajar', 'Gino', '', 'Female', '', 'gino', '09282d9b8315032a05c0efebdfebbcb6cb96258db65be8b19a1a59180c4f607ab96020b02057a572719115780bb535d9adca20ad51c17c24c72e2ebd3bdf8f8a', 1, 0, 0, '0000-00-00 00:00:00', '2018-02-10 15:54:53', '', 'no'),
(8, 'clerk', 'Lester', 'Shane', '', 'Female', '', 'shane', '80cfb2354a6f95b69bfd03ce256663933cd00aa767386267f78e5fc766f5cf34aa679ae0a037379549a93dd7423a8e505413962d9790987511fb66ce14150090', 1, 0, 0, '0000-00-00 00:00:00', '2018-02-10 15:58:06', '', 'no'),
(9, 'clerk', 'Dubiz', 'Karen', '', 'Female', '', 'karen', '6a783bcbc9bf43ae98a31986c32026422e49594cabe74701953f14942e000bc89d535a94e4d425be2ea109fab79ea099bc7a5b4c2208aca99bfb937fcdce7c6e', 1, 0, 0, '0000-00-00 00:00:00', '2018-02-10 16:19:40', '', 'no'),
(10, 'clerk', 'sdf', 'sdf', '', 'Female', '', 'ghh', '1f40fc92da241694750979ee6cf582f2d5d7d28e18335de05abc54d0560e0f5302860c652bf08d560252aa5e74210546f369fbbbce8c12cfc7957b2652fe9a75', 1, 0, 0, '0000-00-00 00:00:00', '2018-02-10 16:20:50', '', 'no'),
(11, 'rel_personnel', 'Andoque', 'Sharmaine Joy', '', 'Female', '', 'sharm', 'c7ad44cbad762a5da0a452f9e854fdc1e0e7a52a38015f23f3eab1d80b931dd472634dfac71cd34ebc35d16ab7fb8a90c81f975113d6c7538dc69dd8de9077ec', 0, 0, 0, '2018-02-12 07:32:21', '2018-02-10 19:38:57', '::1', 'yes'),
(12, 'clerk', 'Vine', 'Claro', '', 'Male', '', 'claro', '43192475f95e3820fe441daaff7c84d9b73ca3a5afc7309ae03f783151b6b0976e4d68cd990f97ad0d65ca640d35a407199d6d7510f1dff5477b8cfce1531475', 0, 0, 0, '2018-02-11 06:07:22', '2018-02-10 21:03:57', '::1', 'no'),
(13, 'clerk', 'sdflkfj', 'sdfjlk', 'sdflskfj', 'Male', '', 'gone', '43192475f95e3820fe441daaff7c84d9b73ca3a5afc7309ae03f783151b6b0976e4d68cd990f97ad0d65ca640d35a407199d6d7510f1dff5477b8cfce1531475', 0, 0, 0, '2018-02-11 06:11:19', '2018-02-10 21:08:14', '::1', 'yes');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`at_id`);

--
-- Indexes for table `tbl_books`
--
ALTER TABLE `tbl_books`
  ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `tbl_book_purchases`
--
ALTER TABLE `tbl_book_purchases`
  ADD PRIMARY KEY (`purchase_id`);

--
-- Indexes for table `tbl_delivery`
--
ALTER TABLE `tbl_delivery`
  ADD PRIMARY KEY (`delivery_id`);

--
-- Indexes for table `tbl_logs`
--
ALTER TABLE `tbl_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_po`
--
ALTER TABLE `tbl_po`
  ADD PRIMARY KEY (`po_id`);

--
-- Indexes for table `tbl_po_books`
--
ALTER TABLE `tbl_po_books`
  ADD PRIMARY KEY (`pob_id`);

--
-- Indexes for table `tbl_students`
--
ALTER TABLE `tbl_students`
  ADD PRIMARY KEY (`stud_id`);

--
-- Indexes for table `tbl_suppliers`
--
ALTER TABLE `tbl_suppliers`
  ADD PRIMARY KEY (`sup_id`);

--
-- Indexes for table `tbl_transactions`
--
ALTER TABLE `tbl_transactions`
  ADD PRIMARY KEY (`trans_id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `at_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_books`
--
ALTER TABLE `tbl_books`
  MODIFY `book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `tbl_book_purchases`
--
ALTER TABLE `tbl_book_purchases`
  MODIFY `purchase_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;
--
-- AUTO_INCREMENT for table `tbl_delivery`
--
ALTER TABLE `tbl_delivery`
  MODIFY `delivery_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT for table `tbl_logs`
--
ALTER TABLE `tbl_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;
--
-- AUTO_INCREMENT for table `tbl_po`
--
ALTER TABLE `tbl_po`
  MODIFY `po_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT for table `tbl_po_books`
--
ALTER TABLE `tbl_po_books`
  MODIFY `pob_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;
--
-- AUTO_INCREMENT for table `tbl_students`
--
ALTER TABLE `tbl_students`
  MODIFY `stud_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tbl_suppliers`
--
ALTER TABLE `tbl_suppliers`
  MODIFY `sup_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `tbl_transactions`
--
ALTER TABLE `tbl_transactions`
  MODIFY `trans_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;
--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
