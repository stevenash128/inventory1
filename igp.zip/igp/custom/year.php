<?php
	//get current server year
	$yr = strftime("%Y",$_SERVER['REQUEST_TIME']);
	$cur = $yr;

	$b_yr=$yr-4;
	$ad_yr=$yr+1;
	$ad_yr2=$ad_yr+1;
	
	echo "<option value=''>--YEAR--</option>";
	//echo "<option value='".$ad_yr."'>".$ad_yr."</option>";
	while($yr>$b_yr)
	{
		$yr_2=$yr+1;
		if($yr==$cur){
			$sel = 'selected';
		}else
		{
			$sel = '';
		}
		echo "<option value='".$yr."' ".$sel.">".$yr."</option>";
		$yr--;

	}

?>